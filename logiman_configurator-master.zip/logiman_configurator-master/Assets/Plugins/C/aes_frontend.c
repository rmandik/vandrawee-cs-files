#include "aes.h"

void aes_decrypt(uint8_t * data, uint32_t len, const uint8_t * key, const uint8_t * iv)
{
    struct AES_ctx aes_context;

    AES_init_ctx_iv(&aes_context, key, iv);
    AES_CBC_decrypt_buffer(&aes_context, data, len);
}
