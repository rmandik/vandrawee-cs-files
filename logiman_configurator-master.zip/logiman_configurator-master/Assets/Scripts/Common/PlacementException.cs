﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assets.Scripts.Common
{
    public class PlacementException : Exception
    {
        public PlacementException() { }

        public PlacementException(string message) : base(message) { }

        public PlacementException(string message, Exception inner) : base(message, inner) { }
    }
}
