﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Assets.Scripts.Common.Utility
{
    public static class GameObjectUtility
    {
        public static Bounds GetRenderersBoundingBox(GameObject gameObject)
        {
            Renderer[] renderers = gameObject.GetComponentsInChildren<Renderer>();

            if (renderers.Length == 0)
                throw new ArgumentException("GameObject does not have renderer component");

            Bounds ret = renderers[0].bounds;

            foreach (Renderer renderer in renderers)
                ret.Encapsulate(renderer.bounds);

            return ret;
        }
    }
}
