﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Assets.Scripts.Common.Utility
{
    public abstract class OnHoverChangeCursorScript : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
    {
        protected Texture2D cursor;

        protected Vector2 hotspot;

        private bool hover = false;

        private static uint hoverCount = 0;

        public void OnPointerEnter(PointerEventData eventData)
        {
            Selectable selectableUI = this.transform.GetComponent<Selectable>();

            if (!this.hover && (selectableUI == null || selectableUI.interactable))
            {
                Cursor.SetCursor(this.cursor, this.hotspot, CursorMode.Auto);
                this.hover = true;
                hoverCount++;
            }
        }

        public void OnPointerExit(PointerEventData eventData)
        {
            if (this.hover)
            {
                this.hover = false;
                hoverCount--;

                if (hoverCount == 0)
                    Cursor.SetCursor(null, Vector2.zero, CursorMode.Auto);
            }
        }

        void OnDisable()
        {
            if (this.hover)
            {
                this.hover = false;
                hoverCount--;
                if (hoverCount == 0)
                    Cursor.SetCursor(null, Vector2.zero, CursorMode.Auto);
            }
        }

        void OnDestroy()
        {
            if (this.hover)
            {
                this.hover = false;
                hoverCount--;
                if (hoverCount == 0)
                    Cursor.SetCursor(null, Vector2.zero, CursorMode.Auto);
            }
        }
    }
}
