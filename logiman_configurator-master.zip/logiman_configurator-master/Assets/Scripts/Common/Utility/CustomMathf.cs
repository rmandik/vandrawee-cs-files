﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Assets.Scripts.Common.Utility
{
    public struct CustomMathf
    {
        public static bool Approximately(float a, float b, float eps = 0.0001f)
        {
            return Mathf.Abs(a - b) < eps;
        }
    }
}
