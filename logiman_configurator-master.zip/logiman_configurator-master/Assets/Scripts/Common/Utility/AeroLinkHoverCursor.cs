﻿using Cysharp.Threading.Tasks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Assets.Scripts.Common.Utility
{
    public class AeroLinkHoverCursor : OnHoverChangeCursorScript
    {
        async UniTaskVoid Start()
        {
            this.cursor = (await Resources.LoadAsync<Texture2D>("Cursors/aero_link")) as Texture2D;
            this.hotspot = new Vector2(4, 0);
        }
    }
}
