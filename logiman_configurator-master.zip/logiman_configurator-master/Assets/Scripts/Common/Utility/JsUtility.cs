﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Assets.Scripts.Common.Utility
{
    public static class JsUtility
    {
        [DllImport("__Internal")]
        public static extern string GetLocationPathname();

        [DllImport("__Internal")]
        public static extern string GetLocationProtocol();

        [DllImport("__Internal")]
        public static extern string GetLocationHostname();

        [DllImport("__Internal")]
        public static extern void SetHrefGuid(string guid);

        [DllImport("__Internal")]
        public static extern void CopyHrefToClipboard();
    }
}
