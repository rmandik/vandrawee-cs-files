﻿using Assets.Scripts.Common.Model;
using Assets.Scripts.Common.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Assets.Scripts.Common
{
    public abstract class PlacedObjectScript : MonoBehaviour
    {
        public PlacedObject PlacedObj;

        private Dictionary<Renderer, Color> originalColors = new Dictionary<Renderer, Color>();

        private const float SEMITRANSPARENT_ALPHA = 0.55f;

        private static readonly Color HIGHLIGHT_COLOR = new Color(0.298f, 1, 0.298f);

        public bool IsHighlighted
        {
            get;
            private set;
        } = false;

        public bool IsRed
        {
            get;
            private set;
        } = false;

        public bool IsSemitransparent
        {
            get;
            private set;
        } = false;

        private enum blendMode
        {
            Opaque,
            Cutout,
            Fade,   // Old school alpha-blending mode, fresnel does not affect amount of transparency
            Transparent // Physically plausible transparency mode, implemented as alpha pre-multiply
        }

        public virtual void prepareForDestroy() { }

        public virtual void Highlight()
        {
            Renderer[] renderers = this.GetComponentsInChildren<Renderer>();
            foreach (Renderer renderer in renderers)
            {
                if (renderer.gameObject.tag == "doNotHighlight")
                    continue;

                Color color = HIGHLIGHT_COLOR;
                if (this.IsSemitransparent)
                    color.a = SEMITRANSPARENT_ALPHA;
                renderer.material.shader = Shader.Find("Standard (Outlined)");
                renderer.material.SetColor("_OutlineColor", color);
                renderer.material.SetFloat("_Outline", 0.01f);

            }
            this.IsHighlighted = true;
        }

        public virtual void Unhighlight()
        {
            Renderer[] renderers = this.GetComponentsInChildren<Renderer>();
            foreach (Renderer renderer in renderers)
            {
                if (renderer.gameObject.tag == "doNotHighlight")
                    continue;

                renderer.material.shader = Shader.Find("Standard");
            }
            if (this.IsSemitransparent)
                this.MakeSemitransparent();
            this.IsHighlighted = false;
        }

        public virtual void MakeRed()
        {
            foreach (Renderer renderer in this.originalColors.Keys)
            {
                Color color = Color.red;
                if (this.IsSemitransparent)
                    color.a = SEMITRANSPARENT_ALPHA;
                renderer.material.color = color;
            }
            this.IsRed = true;
        }

        public virtual void UnmakeRed()
        {
            foreach (Renderer renderer in this.originalColors.Keys)
            {
                Color color = this.originalColors[renderer];
                if (this.IsSemitransparent)
                    color.a = SEMITRANSPARENT_ALPHA;
                renderer.material.color = color;
            }
            this.IsRed = false;
        }

        public virtual void MakeSemitransparent()
        {
            foreach (Renderer renderer in this.originalColors.Keys)
            {
                Color color = renderer.material.color;
                color.a = SEMITRANSPARENT_ALPHA;
                renderer.material.color = color;

                if (this.IsHighlighted)
                {
                    color = HIGHLIGHT_COLOR;
                    color.a = SEMITRANSPARENT_ALPHA;
                    renderer.material.SetColor("_OutlineColor", color);
                }
                // set rendering mode to fade
                renderer.material.SetOverrideTag("RenderType", "Transparent");
                renderer.material.SetFloat("_Mode", (float)blendMode.Fade);
                renderer.material.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.SrcAlpha);
                renderer.material.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
                renderer.material.SetInt("_ZWrite", 0);
                renderer.material.DisableKeyword("_ALPHATEST_ON");
                renderer.material.EnableKeyword("_ALPHABLEND_ON");
                renderer.material.DisableKeyword("_ALPHAPREMULTIPLY_ON");
                renderer.material.renderQueue = (int)UnityEngine.Rendering.RenderQueue.Transparent;
            }
            this.IsSemitransparent = true;
        }

        public virtual void UnmakeSemitransparent()
        {
            foreach (Renderer renderer in this.originalColors.Keys)
            {
                Color color;
                if (this.IsRed)
                    color = Color.red;
                else
                    color = this.originalColors[renderer];
                renderer.material.color = color;

                if (this.IsHighlighted)
                    renderer.material.SetColor("_OutlineColor", HIGHLIGHT_COLOR);

                // set rendering mode to opaque
                renderer.material.SetOverrideTag("RenderType", "");
                renderer.material.SetFloat("_Mode", (float)blendMode.Opaque);
                renderer.material.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.One);
                renderer.material.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.Zero);
                renderer.material.SetInt("_ZWrite", 1);
                renderer.material.DisableKeyword("_ALPHATEST_ON");
                renderer.material.DisableKeyword("_ALPHABLEND_ON");
                renderer.material.DisableKeyword("_ALPHAPREMULTIPLY_ON");
                renderer.material.renderQueue = -1;
            }
            this.IsSemitransparent = false;
        }

        protected virtual void Start()
        {
            Renderer[] renderers = this.GetComponentsInChildren<Renderer>()
                .OrderBy(r => r.GetHashCode()).ToArray();

            foreach (Renderer renderer in this.GetComponentsInChildren<Renderer>())
            {
                this.originalColors.Add(renderer, renderer.material.color);
                if (!this.IsHighlighted)
                    renderer.material.shader = Shader.Find("Standard");
                else
                    renderer.material.shader = Shader.Find("Standard (Outlined)");
            }
        }

        public virtual Tuple<decimal, decimal> GetPrice()
        {
            return new Tuple<decimal, decimal>(this.PlacedObj.Obj.price,
                this.PlacedObj.Obj.price_EUR);
        }
    }
}
