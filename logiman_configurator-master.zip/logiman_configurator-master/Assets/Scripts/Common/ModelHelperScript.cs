﻿using Assets.Scripts.Common;
using Assets.Scripts.Common.Model;
using Assets.Scripts.Common.Utility;
using Assets.Scripts.vandrawee;
using Cysharp.Threading.Tasks;
using Lean.Localization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Assets.Scripts.Common
{
    public class ComponentHighlightedArgs : EventArgs
    {
        public ComponentHighlightedArgs(PlacedObject component)
        {
            this.highlightedComponent = component;
        }

        public PlacedObject highlightedComponent { get; private set; }
    }

    public abstract class ModelHelperScript : MonoBehaviour
    {
        public GameObject downloadHelper;

        public Transform origin = null;

        public LeanToken totalPriceCZKToken;

        public LeanToken totalPriceEURToken;

        protected decimal totalPriceCZK = 0;

        protected decimal totalPriceEUR = 0;

        public Dictionary<GameObject, PlacedObject> placedComponentsMapping =
            new Dictionary<GameObject, PlacedObject>();

        private PlacedObject highlightedComp = null;

        public PlacedObject highlightedComponent
        {
            get
            {
                return this.highlightedComp;
            }
            set
            {
                PlacedObject old = this.highlightedComp;
                this.highlightedComp = value;

                if (old != value)
                    this.highlightedComponentChanged?.Invoke(this, new ComponentHighlightedArgs(value));
            }
        }

        public event EventHandler<ComponentHighlightedArgs> highlightedComponentChanged;

        protected virtual async UniTaskVoid Update()
        {
            if (Input.GetMouseButtonDown(0) && !UIUtility.IsPointerOverUI())
            {
                RaycastHit hit;
                Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);

                if (Physics.Raycast(ray, out hit))
                {
                    Transform objectHit = hit.transform;
                    bool found = false;

                    while (objectHit != null)
                    {
                        if (this.placedComponentsMapping.ContainsKey(objectHit.gameObject))
                        {
                            if (this.highlightedComponent != null)
                                this.highlightedComponent.PlacedObjScript.Highlight();
                            this.highlightComponent(this.placedComponentsMapping[objectHit.gameObject]);
                            found = true;
                            break;
                        }

                        objectHit = objectHit.parent;
                    }

                    if (!found)
                        this.unhighlightComponent();
                }
                else
                    this.unhighlightComponent();
            }
            if (Input.GetKeyDown(KeyCode.Delete))
            {
                if (this.highlightedComponent != null)
                    this.RemoveComponent(this.highlightedComponent);
            }
            if (Input.GetKeyDown(KeyCode.Space) && this.highlightedComponent != null)
            {
                Camera.main.GetComponent<CameraOrbitScript>().FocusOnTarget(this.highlightedComponent.PlacedObjScript.transform);
            }
            if (Input.GetKeyDown(KeyCode.Escape))
            {
                Camera.main.GetComponent<CameraOrbitScript>().FocusOnTarget(this.origin);
                this.unhighlightComponent();
            }
            if (Input.GetKeyDown(KeyCode.U))
            {
                string fbxString = UnityFBXExporter.FBXExporter.MeshToString(this.origin.gameObject, "");
                (StaticData.api as VanDraweeAPI).UploadFBX(Guid.NewGuid().ToString(), fbxString, "").ToUniTask().Forget();
            }
            await UniTask.Yield();
        }

        public virtual void RemoveComponent(PlacedObject component)
        {
            Queue<PlacedObject> queue = new Queue<PlacedObject>();

            queue.Enqueue(component);

            while (queue.Count > 0)
            {
                PlacedObject placedComponent = queue.Dequeue();
                this.placedComponentsMapping.Remove(placedComponent.PlacedObjScript.gameObject);

                if (this.highlightedComponent == placedComponent)
                    this.unhighlightComponent();

                if (placedComponent.Parent != null)
                    placedComponent.Parent.Children.Remove(placedComponent);

                // "bug" workaround - OnTriggerExit does not get called when colliding object is being destroyed
                placedComponent.PlacedObjScript.prepareForDestroy();
                placedComponent.PlacedObjScript.transform.parent = null;
                placedComponent.PlacedObjScript.transform.position = new Vector3(0, -10, 0);
                Destroy(placedComponent.PlacedObjScript.gameObject, Time.deltaTime * 5);
                this.SubstractFromPrice(placedComponent.PlacedObjScript.GetPrice());

                foreach (PlacedObject c in placedComponent.Children)
                    queue.Enqueue(c);
            }
        }

        protected void updateGUIPrice()
        {
            this.totalPriceCZKToken.SetValue(this.totalPriceCZK.ToString());
            this.totalPriceEURToken.SetValue(this.totalPriceEUR.ToString());
        }

        protected void highlightComponent(PlacedObject component)
        {
            component.PlacedObjScript.Highlight();
            this.highlightedComponent = component;
        }

        protected void unhighlightComponent()
        {
            if (this.highlightedComponent != null)
            {
                this.highlightedComponent.PlacedObjScript.Unhighlight();
                this.highlightedComponent = null;
            }
        }

        public abstract List<PlacedObject> PlaceComponent(string id);

        public virtual async UniTask LoadModel(IEnumerable<StoredObject> components)
        {
            while (this.placedComponentsMapping.Count > 0)
                this.RemoveComponent(this.placedComponentsMapping.First().Value);

            foreach (StoredObject storedComponent in components)
            {
                Queue<PlacedObject> queue = new Queue<PlacedObject>();
                queue.Enqueue(new PlacedObject(storedComponent, null));

                while (queue.Count > 0)
                {
                    PlacedObject placedComponent = queue.Dequeue();
                    this.placedComponentsMapping[placedComponent.PlacedObjScript.gameObject] = placedComponent;
                    this.AddToPrice(placedComponent.PlacedObjScript.GetPrice());

                    foreach (PlacedObject child in placedComponent.Children)
                        queue.Enqueue(child);
                }
            }

            await UniTask.Yield();
        }

        public void AddToPrice(Tuple<decimal, decimal> prices)
        {
            this.totalPriceCZK += prices.Item1;
            this.totalPriceEUR += prices.Item2;
            this.updateGUIPrice();
        }

        public void SubstractFromPrice(Tuple<decimal, decimal> prices)
        {
            this.totalPriceCZK -= prices.Item1;
            this.totalPriceEUR -= prices.Item2;
            this.updateGUIPrice();
        }
    }
}
