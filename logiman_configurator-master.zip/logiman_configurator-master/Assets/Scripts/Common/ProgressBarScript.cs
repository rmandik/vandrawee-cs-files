﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Assets.Scripts.Common
{
    public class ProgressBarScript : MonoBehaviour
    {
        [SerializeField]
        private Slider slider;

        [SerializeField]
        private TMP_Text text;

        float progress;

        public float Progress
        {
            get { return this.progress; }
            set
            {
                this.progress = value;
                this.slider.value = value;
                this.text.text = (value * 100).ToString("0.00") + " %";
            }
        }

        private void OnEnable()
        {
            this.progress = 0;
            this.text.text = "0 %";
        }
    }
}
