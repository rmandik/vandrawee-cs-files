﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Assets.Scripts.Common
{
    public class ScrollViewMenuItemScript : MonoBehaviour
    {
        public string id;

        public void OnMenuItemClick()
        {
            GameObject.Find("modelHelper").GetComponent<ModelHelperScript>().PlaceComponent(id);
        }
    }
}
