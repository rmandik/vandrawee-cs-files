﻿using Assets.Scripts.Common.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Assets.Scripts.Common
{
    public class PlaceScript : MonoBehaviour
    {
        public virtual PlacedObject Place(Model.Object component, IEnumerable<PlacedObject> placedComponents, Transform origin)
        {
            if (origin != null)
                return new PlacedObject(Instantiate(this.gameObject, origin).GetComponent<PlacedObjectScript>(), component);
            else
                return new PlacedObject(Instantiate(this.gameObject).GetComponent<PlacedObjectScript>(), component);
        }
    }
}
