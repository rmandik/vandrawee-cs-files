﻿using Lean.Localization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.UI;

namespace Assets.Scripts.Common
{
    public class LanguageDropdownScript : MonoBehaviour
    {
        public LeanLocalization localization;

        public Dropdown dropdown;

        void Start()
        {
            List<Dropdown.OptionData> options = new List<Dropdown.OptionData>();
            int selected = 0;

            for (int i = 0; i < this.localization.Languages.Count; i++)
            {
                string language = this.localization.Languages[i].Name;
                options.Add(new Dropdown.OptionData(language));

                if (LeanLocalization.CurrentLanguage == language)
                    selected = i;
            }

            this.dropdown.options = options;
            this.dropdown.value = selected;

            this.dropdown.onValueChanged.AddListener((index) =>
            {
                this.localization.SetCurrentLanguage(index);
            });
        }
    }
}
