﻿using Assets.Scripts.Common.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Assets.Scripts.Common
{
    public class PlaceOnceScript : PlaceScript
    {
        public string parentName = String.Empty;

        public List<string> collisions = new List<string>();

        public override PlacedObject Place(Model.Object component, IEnumerable<PlacedObject> placedComponents, Transform origin)
        {
            foreach (string collision in this.collisions)
                if (placedComponents.FirstOrDefault(c => c.Id == collision) != null)
                    return null;

            PlacedObject parent = null;

            foreach (PlacedObject c in placedComponents) {
                if (c.Id == component.unityId)
                    return null;
                if (c.Id == this.parentName)
                    parent = c;
            }

            if (this.parentName != String.Empty && parent == null)
                return null;

            GameObject instance = null;

            if (parent != null)
                instance = Instantiate(this.gameObject, parent.PlacedObjScript.transform);
            else if (origin != null)
                instance = Instantiate(this.gameObject, origin);
            else
                instance = Instantiate(this.gameObject);

            instance.name = this.name;
            return new PlacedObject(instance.GetComponent<PlacedObjectScript>(), component);
        }
    }
}
