﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Assets.Scripts.Common.Model
{
    public class PlacedObject
    {
        public PlacedObject(PlacedObjectScript placedObject, Object obj)
        {
            this.PlacedObjScript = placedObject;
            this.PlacedObjScript.PlacedObj = this;
            this.Obj = obj;
        }

        public PlacedObject(StoredObject storedComponent, PlacedObject parent)
        {
            this.Parent = parent;
            this.Obj = StaticData.components.First(c => c.unityId == storedComponent.Id);
            GameObject model = StaticData.assets.First(a => a.name == storedComponent.Id) as GameObject;

            if (this.Parent != null)
                this.PlacedObjScript = UnityEngine.Object.Instantiate(model, storedComponent.Position,
                    Quaternion.Euler(storedComponent.Rotation), parent.PlacedObjScript.transform)
                    .GetComponent<PlacedObjectScript>();
            else
                this.PlacedObjScript = UnityEngine.Object.Instantiate(model, storedComponent.Position,
                    Quaternion.Euler(storedComponent.Rotation)).GetComponent<PlacedObjectScript>();

            this.PlacedObjScript.PlacedObj = this;

            foreach (StoredObject child in storedComponent.Children)
            {
                PlacedObject placedChild = new PlacedObject(child, this);
                this.Children.Add(placedChild);
            }
        }

        public bool IsParentOf(PlacedObject component)
        {
            foreach (PlacedObject child in this.Children)
                if (child == component || child.IsParentOf(component))
                    return true;
            return false;
        }

        [JsonIgnore]
        public PlacedObject Parent = null;

        [JsonIgnore]
        public PlacedObjectScript PlacedObjScript;

        [JsonIgnore]
        public Object Obj;

        public List<PlacedObject> Children = new List<PlacedObject>();

        public string Id
        {
            get
            {
                return this.Obj.unityId;
            }
        }

        public Vector3 Position
        {
            get
            {
                return this.PlacedObjScript.transform.position;
            }
        }

        public Vector3 Rotation
        {
            get
            {
                return this.PlacedObjScript.transform.eulerAngles;
            }
        }

        public Vector3 Scale
        {
            get
            {
                return this.PlacedObjScript.transform.localScale;
            }
        }
    }
}
