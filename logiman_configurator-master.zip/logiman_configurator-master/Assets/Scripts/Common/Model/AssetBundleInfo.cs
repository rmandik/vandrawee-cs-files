﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assets.Scripts.Common.Model
{
    public class AssetBundleInfo
    {
        public string name;

        public string iv;

        public uint crc;

        public static AssetBundleInfo LoadFromFile(string path)
        {
            if (!File.Exists(path))
                return null;

            AssetBundleInfo info = new AssetBundleInfo();
            info.name = Path.GetFileNameWithoutExtension(path);
            info.iv = String.Empty;
            info.crc = 0;

            string[] lines = File.ReadAllLines(path);

            string ivLine = lines.FirstOrDefault(l => l.StartsWith("IV: "));
            if (ivLine != null)
                info.iv = ivLine.Split(' ')[1];

            string crcLine = lines.FirstOrDefault(l => l.StartsWith("CRC: "));
            if (crcLine != null)
                info.crc = uint.Parse(crcLine.Split(' ')[1]);

            return info;
        }
    }
}
