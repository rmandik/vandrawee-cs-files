﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assets.Scripts.Common.Model
{
    public class Object
    {
        public string name;

        public string name_EN;

        public string unityId;

        public decimal price;

        public decimal price_EUR;

        public string category;

        public int orderBy;

        public bool enabled;
    }
}
