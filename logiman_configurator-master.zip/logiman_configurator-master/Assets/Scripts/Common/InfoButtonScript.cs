﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Assets.Scripts.Common
{
    public class InfoButtonScript : MonoBehaviour
    {
        public string fileName;

        public void OnInfoButtonClick()
        {
            string path = Path.Combine(Application.streamingAssetsPath, this.fileName);

            if (Application.platform == RuntimePlatform.WebGLPlayer)
                Application.ExternalEval("window.open(\" " + path + "\")");
            else
                Application.OpenURL("file:///" + path);

        }
    }
}
