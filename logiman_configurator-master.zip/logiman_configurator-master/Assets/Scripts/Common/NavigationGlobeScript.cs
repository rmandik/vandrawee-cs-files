﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.EventSystems;

namespace Assets.Scripts.Common
{
    public class NavigationGlobeScript : MonoBehaviour, IDragHandler
    {
        public void OnDrag(PointerEventData eventData)
        {
            float rotationX = eventData.delta.y;
            float rotationY = eventData.delta.x;

            this.transform.Rotate(new Vector3(rotationX, rotationY, 0), Space.World);

            Camera.main.GetComponent<CameraOrbitScript>().GlobeRotate(rotationY, rotationX);
        }
    }
}
