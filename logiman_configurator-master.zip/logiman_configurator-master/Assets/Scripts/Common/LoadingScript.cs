﻿using Assets.Scripts.Common;
using Assets.Scripts.Common.Model;
using Assets.Scripts.vandrawee;
using Cysharp.Threading.Tasks;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using UnityEditor;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;
using UnityEngine.UIElements;

namespace Assets.Scripts
{
    public abstract class LoadingScript : MonoBehaviour
    {
        public GameObject ScrollViewItemPrefab;

        public GameObject LoadingScreen;

        protected byte[] key = Convert.FromBase64String("utheQblwP2hYsTe06IkORwRZrwZZ+XYPGGdOEfM2vs0=");

        #if UNITY_EDITOR
        [DllImport("logiman_aes")]
        #else
        [DllImport("__Internal")]
        #endif
        private static extern void aes_decrypt(byte[] data, uint len, byte[] key, byte[] iv);

        protected abstract UniTask loadAssets();

        protected abstract API CreateAPI();

        // returns camera target
        protected abstract Transform instantiatePrerequisities();

        private async UniTask downloadFileIntoPersistent(string url, string path, bool withoutCache = false)
        {
            using (UnityWebRequest request = new UnityWebRequest(url))
            {
                request.downloadHandler = new DownloadHandlerFile(path);
                request.method = UnityWebRequest.kHttpVerbGET;

                if (withoutCache)
                    request.SetRequestHeader("Cache-Control", "max-age=0");

                await request.SendWebRequest();

                if (request.isHttpError || request.isNetworkError)
                    Debug.LogError(request.error);
            }
        }

        protected async UniTask<UnityEngine.Object[]> loadAssetsFromBundle(string assetBundleName)
        {
            string bundleStreamingPath = Application.streamingAssetsPath + "/" + assetBundleName + ".assetbundle";
            string bundlePersistentPath = Application.persistentDataPath + "/" + assetBundleName + ".assetbundle";
            string manifestStreamingPath = Application.streamingAssetsPath + "/" + assetBundleName + ".manifest";
            string manifestPersistentPath = Application.persistentDataPath + "/" + assetBundleName + ".manifest";

            UnityEngine.Object[] assets = new UnityEngine.Object[0];

            if (Application.platform == RuntimePlatform.WebGLPlayer)
            {
                await downloadFileIntoPersistent(manifestStreamingPath, manifestPersistentPath);
                AssetBundleInfo info = AssetBundleInfo.LoadFromFile(manifestPersistentPath);

                if (!File.Exists(bundlePersistentPath))
                {
                    await downloadFileIntoPersistent(bundleStreamingPath, bundlePersistentPath);
                }
                try
                {
                    assets = await decryptAndLoadAssetBundle(bundlePersistentPath, key, Convert.FromBase64String(info.iv), info.crc);
                }
                catch (Exception ex)
                {
                    await downloadFileIntoPersistent(manifestStreamingPath, manifestPersistentPath, true);
                    info = AssetBundleInfo.LoadFromFile(manifestPersistentPath);
                    await downloadFileIntoPersistent(bundleStreamingPath, bundlePersistentPath, true);
                    assets = await decryptAndLoadAssetBundle(bundlePersistentPath, key, Convert.FromBase64String(info.iv), info.crc);
                }
            }
            else if (Application.platform == RuntimePlatform.WindowsEditor)
            {
                AssetBundleInfo info = AssetBundleInfo.LoadFromFile(manifestStreamingPath);
                assets = await decryptAndLoadAssetBundle(bundleStreamingPath, key, Convert.FromBase64String(info.iv), info.crc);
            }

            return assets;
        }

        private async UniTask<UnityEngine.Object[]> decryptAndLoadAssetBundle(string path, byte[] key, byte[] IV, uint crc)
        {
            UnityEngine.Object[] assets = null;

            byte[] bytes = File.ReadAllBytes(path);
            aes_decrypt(bytes, (uint)bytes.Length, key, IV);

            using (MemoryStream memoryStream = new MemoryStream(bytes, 0, bytes.Length - bytes.Last()))
            {
                var assetBundle = await AssetBundle.LoadFromStreamAsync(memoryStream, crc);

                // load all assets from the bundle
                assets = await assetBundle.LoadAllAssetsAsync().AwaitForAllAssets();
                assetBundle.Unload(false);
            }

            return assets;
        }
    }
} 