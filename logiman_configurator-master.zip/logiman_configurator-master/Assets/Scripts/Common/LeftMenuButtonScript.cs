﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Assets.Scripts.Common
{
    public class LeftMenuButtonScript : MonoBehaviour
    {
        public GameObject LeftMenu;
        public void OnClickExpandLeftMenuButton()
        {
            if (this.LeftMenu)
            {
                Animator animator = this.LeftMenu.GetComponent<Animator>();
                animator.SetTrigger("Click");
            }
        }
    }
}
