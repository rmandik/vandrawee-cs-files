﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Assets.Scripts.Common
{
    public class NavigationPanelScript : MonoBehaviour
    {
        public void OnUpClick()
        {
            Camera.main.GetComponent<CameraOrbitScript>().MoveDown();
        }

        public void OnDownClick()
        {
            Camera.main.GetComponent<CameraOrbitScript>().MoveUp();
        }

        public void OnLeftClick()
        {
            Camera.main.GetComponent<CameraOrbitScript>().MoveRight();
        }

        public void OnRightClick()
        {
            Camera.main.GetComponent<CameraOrbitScript>().MoveLeft();
        }
    }
}
