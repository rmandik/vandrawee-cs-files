﻿using Assets.Scripts.Common.Utility;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Assets.Scripts.Common
{
    public class CameraOrbitScript : MonoBehaviour
    {
        public Bounds targetBounds;
        public float distance = 5.0f;
        public float mouseXSpeed = 80.0f;
        public float mouseYSpeed = 80.0f;
        public float zoomSpeed = 5.0f;
        public float arrowSpeed = 3f;

        public float yMinLimit = -20f;
        public float yMaxLimit = 80f;

        public float distanceMin = 1.5f;
        public float distanceMax = 4;

        public float buttonYStep = 0.4f;
        public float buttonXStep = 0.4f;
        public float buttonAnimationTime = 0.5f;

        public float globeXSpeed = 60;
        public float globeYSpeed = 60;

        public bool rotationEnabled = true;
        public bool movementEnabled = true;
        public bool zoomEnabled = true;

        private Transform target = null;

        void Start()
        {
            this.target = new GameObject().transform;
        }

        void LateUpdate()
        {
            if (this.target)
            {
                Vector3 angles = transform.eulerAngles;
                float x = angles.y;
                float y = angles.x;

                if (this.movementEnabled)
                {
                    float horizontal = Input.GetAxis("Horizontal");
                    float vertical = Input.GetAxis("Vertical");
                    Vector3 movement = new Vector3(horizontal * this.arrowSpeed * Time.deltaTime, 0, 0);
                    Quaternion forwardRotation = Quaternion.LookRotation(this.transform.forward, this.transform.up);
                    movement = forwardRotation * -movement;
                    movement += new Vector3(0, -vertical * this.arrowSpeed * Time.deltaTime, 0);

                    this.target.transform.Translate(movement, Space.World);
                }

                // right or middle button is held
                if ((Input.GetMouseButton(1) || Input.GetMouseButton(2)) && this.rotationEnabled)
                {
                    x += Input.GetAxis("Mouse X") * mouseXSpeed * distance * 0.02f;
                    y -= Input.GetAxis("Mouse Y") * mouseYSpeed * 0.02f;
                    y = ClampAngle(y, this.yMinLimit, this.yMaxLimit);
                }

                Quaternion rotation = Quaternion.Euler(y, x, 0);
                if (!UIUtility.IsPointerOverUI() && this.zoomEnabled)
                {
                    distance -= Input.GetAxis("Mouse ScrollWheel") * this.zoomSpeed;
                    distance = Mathf.Clamp(distance, distanceMin, distanceMax);
                }

                Vector3 negDistance = new Vector3(0.0f, 0.0f, -distance);
                Vector3 position = rotation * negDistance + target.position;

                transform.rotation = rotation;
                transform.position = position;
            }
        }

        public void FocusOnTarget(Transform target)
        {
            Bounds bounds = GameObjectUtility.GetRenderersBoundingBox(target.gameObject);

            // zoom camera in distance so that whole target object will be visible
            float maxExtent = bounds.extents.magnitude;
            float margin = 0.8f;
            float distance = (maxExtent * margin) / Mathf.Sin(Mathf.Deg2Rad * Camera.main.fieldOfView / 2f);
            this.distanceMin = Mathf.Max(bounds.extents.x, bounds.extents.z) + 0.4f;

            if (this.distanceMin > distance)
                this.distanceMin = distance;

            StartCoroutine(this.focusOnTarget(bounds.center, target.up, distance, 0.4f));
        }

        public void FocusOnTarget(Transform target, float distance)
        {
            Bounds bounds = GameObjectUtility.GetRenderersBoundingBox(target.gameObject);
            this.distanceMin = 0.4f;

            StartCoroutine(this.focusOnTarget(bounds.center, target.up, distance + this.distanceMin, 0.4f));
        }

        private IEnumerator focusOnTarget(Vector3 center, Vector3 forward, float targetDistance, float time)
        {
            float rate = 1 / time;
            float i = 0;
            float startDistance = this.distance;
            Vector3 startPos = this.target.position;
            Quaternion startRot = this.transform.rotation;
            Quaternion endRot = Quaternion.LookRotation(forward);

            while (i < 1)
            {
                i += Time.deltaTime * rate;
                this.distance = Mathf.Lerp(startDistance, targetDistance, i);
                this.target.position = Vector3.Lerp(startPos, center, i);
                this.transform.rotation = Quaternion.Slerp(startRot, endRot, i);

                yield return null;
            }
        }

        public void GlobeRotate(float deltaX, float deltaY)
        {
            Vector3 angles = transform.eulerAngles;
            float x = angles.y;
            float y = angles.x;

            x += deltaX * globeXSpeed * distance * 0.02f;
            y -= deltaY * globeYSpeed * 0.02f;
            y = ClampAngle(y, this.yMinLimit, this.yMaxLimit);

            Quaternion rotation = Quaternion.Euler(y, x, 0);
            Vector3 negDistance = new Vector3(0.0f, 0.0f, -distance);
            Vector3 position = rotation * negDistance + target.position + Vector3.up;

            transform.rotation = rotation;
            transform.position = position;
        }

        public void MoveUp()
        {
            StartCoroutine(this.moveUpDown(this.buttonYStep));
        }

        public void MoveDown()
        {
            StartCoroutine(this.moveUpDown(-this.buttonYStep));
        }

        private IEnumerator moveUpDown(float yStep)
        {
            float startY = this.target.transform.position.y;
            float targetY = startY + yStep;
            float startTime = Time.time;

            while ((Time.time - startTime) / this.buttonAnimationTime < 1)
            {
                float t = (Time.time - startTime) / this.buttonAnimationTime;
                Vector3 currentPosition = this.target.transform.position;

                float newY = Mathf.SmoothStep(startY, targetY, t);
                this.target.transform.Translate(new Vector3(0, newY - currentPosition.y, 0), Space.World);

                yield return null;
            }
        }

        public void MoveLeft()
        {
            StartCoroutine(this.moveLeftRight(this.buttonXStep));
        }

        public void MoveRight()
        {
            StartCoroutine(this.moveLeftRight(-this.buttonXStep));
        }

        private IEnumerator moveLeftRight(float xStep)
        {
            Vector3 start = this.target.transform.position;
            Vector3 movement = new Vector3(xStep, 0, 0);
            Quaternion forwardRotation = Quaternion.LookRotation(this.transform.forward, this.transform.up);
            movement = forwardRotation * -movement;
            Vector3 target = start + movement;

            float startTime = Time.time;

            while ((Time.time - startTime) / this.buttonAnimationTime < 1)
            {
                float t = (Time.time - startTime) / this.buttonAnimationTime;
                Vector3 currentPosition = this.target.transform.position;
                Vector3 step = new Vector3(Mathf.SmoothStep(start.x, target.x, t),
                    Mathf.SmoothStep(start.y, target.y, t), Mathf.SmoothStep(start.z, target.z, t));

                this.target.transform.Translate(step - currentPosition, Space.World);

                yield return null;
            }
        }

        public static float ClampAngle(float angle, float min, float max)
        {
            if (angle < -360)
                angle += 360;
            else if (angle > 360)
                angle -= 360;

            if (((min < max) && (angle < min || angle > max)) ||
                ((min > max) && (angle < min && angle > max)))
            {
                if (Mathf.Abs(angle - min) < Mathf.Abs(angle - max))
                    return min;
                return max;
            }

            return angle;
        }
    }
}
