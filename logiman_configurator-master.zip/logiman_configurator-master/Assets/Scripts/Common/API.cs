﻿using Assets.Scripts.Common.Model;
using Cysharp.Threading.Tasks;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.Networking;

namespace Assets.Scripts.Common
{
    public class API
    {
        protected string url;

        public API(string url)
        {
            this.url = url;
        }

        public virtual async UniTask<Model.Object[]> GetComponents()
        {
            UnityWebRequest request = UnityWebRequest.Get(this.url + "getComponents.php");
            await request.SendWebRequest();

            if (request.isNetworkError || request.isHttpError)
                throw new Exception(request.error);

            return JsonConvert.DeserializeObject<Model.Object[]>(request.downloadHandler.text);
        }

        public virtual async UniTask<Guid> UploadModel(PlacedObject[] components)
        {
            Dictionary<string, string> postBody = new Dictionary<string, string>();
            postBody["data"] = JsonConvert.SerializeObject(components);

            UnityWebRequest request = UnityWebRequest.Post(this.url + "uploadModel.php", postBody);
            await request.SendWebRequest();

            if (request.isNetworkError || request.isHttpError)
                throw new Exception(request.error);

            string uuid = JsonConvert.DeserializeObject<string>(request.downloadHandler.text);
            return Guid.Parse(uuid);
        }

        public virtual async UniTask<StoredObject[]> GetModel(Guid uuid)
        {
            UnityWebRequest request = UnityWebRequest.Get(this.url + "getModel.php?uuid=" + uuid.ToString());
            await request.SendWebRequest();

            if (request.isNetworkError || request.isHttpError)
                throw new Exception(request.error);

            return JsonConvert.DeserializeObject<StoredObject[]>(request.downloadHandler.text);
        }
    }
}
