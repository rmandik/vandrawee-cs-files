﻿using Assets.Scripts.Common;
using Assets.Scripts.Common.Model;
using Assets.Scripts.Common.Utility;
using Cysharp.Threading.Tasks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.UI;

namespace Assets.Scripts.sse
{
    public class SSELoadingScript : LoadingScript
    {
        public Transform componentsMenu;

        protected async UniTaskVoid Awake()
        {
            StaticData.api = this.CreateAPI();

            await this.loadAssets();

            StaticData.components.AddRange(await StaticData.api.GetComponents());
            this.fillComponentsMenus();

            ModelHelperScript modelHelper = GameObject.Find("modelHelper").GetComponent<ModelHelperScript>();
            Transform cameraTarget = this.instantiatePrerequisities();
            modelHelper.origin = cameraTarget;

            if (cameraTarget != null)
                Camera.main.GetComponent<CameraOrbitScript>().FocusOnTarget(cameraTarget.transform, 2.1f);

            await this.loadFromURL();

            if (this.LoadingScreen != null)
                this.LoadingScreen.SetActive(false);
        }

        protected override API CreateAPI()
        {
            if (Application.platform == RuntimePlatform.WebGLPlayer)
                return new API(JsUtility.GetLocationProtocol() + "//" + JsUtility.GetLocationHostname() + "/api/");
            else if (Application.platform == RuntimePlatform.WindowsEditor)
                return new API("https://test.balici-stoly.cz/api/");
            return null;
        }

        protected override async UniTask loadAssets()
        {
            StaticData.assets.AddRange(await this.loadAssetsFromBundle("sse"));
        }

        protected void fillComponentsMenus()
        {
            if (this.componentsMenu != null)
            {
                Common.Model.Object[] components = StaticData.components.Where(c => c.category != "None")
                    .OrderBy(c => c.orderBy).ToArray();
                this.fillComponentsMenu(components, this.componentsMenu);
            }
        }

        protected override Transform instantiatePrerequisities()
        {
            ModelHelperScript modelHelper = GameObject.Find("modelHelper").GetComponent<ModelHelperScript>();
            PlacedObject table = modelHelper.PlaceComponent("SSE.2000.900").FirstOrDefault();

            if (table != null)
                return table.PlacedObjScript.transform;
            else
                return null;
        }

        protected async UniTask loadFromURL()
        {
            if (Application.platform == RuntimePlatform.WebGLPlayer)
            {
                ModelHelperScript modelHelper = GameObject.FindObjectOfType<ModelHelperScript>();
                string possibleGuid = JsUtility.GetLocationPathname().Trim('/');
                Guid guid;

                if (Guid.TryParse(possibleGuid, out guid))
                {
                    try
                    {
                        StoredObject[] model = await StaticData.api.GetModel(guid);
                        await modelHelper.LoadModel(model);
                    } catch (Exception) { }
                }
            }
        }

        protected void fillComponentsMenu(Common.Model.Object[] components, Transform content)
        {
            if ( this.ScrollViewItemPrefab != null)
            {
                foreach (Common.Model.Object component in components)
                {
                    GameObject scrollViewItem = Instantiate(this.ScrollViewItemPrefab, content);
                    scrollViewItem.transform.Find("Name").GetComponent<Text>().text = component.name;
                    if (StaticData.componentTextures.ContainsKey(component.unityId))
                    {
                        Texture2D texture = StaticData.componentTextures[component.unityId];

                        scrollViewItem.transform.Find("Image").GetComponent<UnityEngine.UI.Image>().sprite =
                            Sprite.Create(texture, new Rect(0, 0, texture.width, texture.height), new Vector2(0.5f, 0.5f));

                    }
                    else
                        Destroy(scrollViewItem.transform.Find("Image").gameObject);
                    scrollViewItem.transform.Find("Prices").Find("Price").GetComponent<Text>().text = String.Format("{0} Kč", component.price);
                    scrollViewItem.GetComponent<ScrollViewMenuItemScript>().id = component.unityId;
                }
            }
        }
    }
}
