﻿using Assets.Scripts.Common;
using Assets.Scripts.Common.Model;
using Assets.Scripts.Common.Utility;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Assets.Scripts
{
    public class SSEModelHelperScript : ModelHelperScript
    {
        public override List<PlacedObject> PlaceComponent(string id)
        {
            GameObject target = StaticData.assets.FirstOrDefault(a => a.name == id) as GameObject;
            Common.Model.Object component = StaticData.components.FirstOrDefault(c => c.unityId == id);

            if (target != null && component != null)
            {
                PlacedObject placedTarget = this.placedComponentsMapping.FirstOrDefault(o => o.Value.Id == id).Value;

                if (placedTarget == null)
                {
                    // component is not placed, place it
                    List<PlacedObject> placedObjects = this.placeComponent(target, component);

                    if (placedObjects.Count != 0)
                    {
                        this.updateGUIPrice();
                        this.unhighlightComponent();

                        if (component.category != "None")
                        {
                            foreach (PlacedObject placedObject in placedObjects)
                            {
                                List<PlacedObject> others = placedObjects
                                    .Except(new List<PlacedObject>() { placedObject }).ToList();

                                if (others.All(c => placedObject.IsParentOf(c)))
                                {
                                    this.highlightComponent(placedObject);
                                    return placedObjects;
                                }
                            }
                        }
                    }

                    return placedObjects;
                }
                else
                {
                    this.unhighlightComponent();
                    this.RemoveComponent(placedTarget);
                }
            }
            return new List<PlacedObject>();
        }

        private List<PlacedObject> placeComponent(GameObject componentObject, Common.Model.Object component)
        {
            PlaceScript placeable = componentObject.GetComponent<PlaceScript>();
            List<PlacedObject> ret = new List<PlacedObject>();

            if (placeable != null)
            {
                // list of placed game objects that were required because target component requires parent game object that was not placed
                List<PlacedObject> parentPlaced = new List<PlacedObject>();

                if (placeable is PlaceOnceScript)
                {
                    PlaceOnceScript placeableOnce = placeable as PlaceOnceScript;

                    // component requires parent and parent is not placed
                    if (placeableOnce.parentName != String.Empty &&
                        this.placedComponentsMapping.Values.FirstOrDefault(g => g.Id == placeableOnce.parentName) == null)
                    {
                        GameObject parent = StaticData.assets.FirstOrDefault(a => a.name == placeableOnce.parentName) as GameObject;
                        // parent game object not found in asset bundle, target component will not be placed
                        if (parent == null)
                            return ret;

                        Common.Model.Object parentComponent = StaticData.components.FirstOrDefault(c => c.unityId == placeableOnce.parentName);
                        // parent component not found, target component will not be placed
                        if (parentComponent == null)
                            return ret;

                        parentPlaced.AddRange(this.placeComponent(parent, parentComponent));
                    }
                }

                PlacedObject placedComponent = placeable.Place(component, this.placedComponentsMapping.Values, this.origin);
                if (placedComponent != null)
                {
                    if (placeable is PlaceOnceScript && (placeable as PlaceOnceScript).parentName != String.Empty)
                    {
                        placedComponent.Parent = this.placedComponentsMapping.Values.First(c => c.Id == (placeable as PlaceOnceScript).parentName);
                        placedComponent.Parent.Children.Add(placedComponent);
                    }
                    if (component.category != "None")
                        this.placedComponentsMapping.Add(placedComponent.PlacedObjScript.gameObject, placedComponent);

                    this.AddToPrice(placedComponent.PlacedObjScript.GetPrice());
                    ret.AddRange(parentPlaced);
                    ret.Add(placedComponent);
                }
                else
                    foreach (PlacedObject parentPlacedObject in parentPlaced)
                        this.RemoveComponent(parentPlacedObject);
            }
            return ret;
        }
    }
}
