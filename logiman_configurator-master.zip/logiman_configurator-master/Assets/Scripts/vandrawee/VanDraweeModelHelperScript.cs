﻿using Assets.Scripts.Common;
using Assets.Scripts.Common.Model;
using Assets.Scripts.Common.Utility;
using Assets.Scripts.vandrawee.ComponentScripts;
using Assets.Scripts.vandrawee.LegScripts;
using Assets.Scripts.vandrawee.Model;
using Cysharp.Threading.Tasks;
using Lean.Gui;
using Lean.Localization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Assets.Scripts.vandrawee
{
    public enum ConfiguratorMode { None, Legs, Components }

    public class VanDraweeModelHelperScript : ModelHelperScript
    {
        public PhysicsRaycaster physicsRaycaster;

        public LeanPulse notification;

        public ProgressBarScript progressBar;

        public ComponentsMenuListAdapter menuListAdapter;

        public Text notificationText;

        public RectTransform notificationLayout;

        public PlacedObject selectedLegs = null;

        public PlacedObject selectedComponent = null;

        public event EventHandler modeChanged;

        private ConfiguratorMode _mode = ConfiguratorMode.None;

        public ConfiguratorMode mode
        {
            get
            {
                return this._mode;
            }
            set
            {
                if (value != this._mode)
                {
                    this._mode = value;
                    this.modeChanged?.Invoke(this, new EventArgs());
                }
            }
        }

        private int clicks = 0;

        private PlacedObject lastClickedComponent;

        private const float MAX_CLICK_DELAY = 0.5f;

        private float lastClickTime;

        private void Start()
        {
            this.modeChanged += VanDraweeModelHelperScript_modeChanged;
        }

        private void VanDraweeModelHelperScript_modeChanged(object sender, EventArgs e)
        {
            if (this.mode == ConfiguratorMode.Components)
            {
                // enable components layer, disable legs layer
                this.physicsRaycaster.eventMask |= 1 << LayerMask.NameToLayer("Components");
                this.physicsRaycaster.eventMask &= ~(1 << LayerMask.NameToLayer("Legs"));

                if ((this.selectedLegs.Obj as VanDraweeObject).IsLegs())
                    this.menuListAdapter.ShowComponents(this.selectedLegs.Obj as VanDraweeLegs);

                LegsAreaScript targetArea = (this.selectedLegs.PlacedObjScript as LegsScript).LegsArea;
                foreach (LegsAreaScript area in VanDraweeStaticData.car.legsPlacingArea.Where(a => a != targetArea))
                    area.gameObject.SetActive(false);
            }
            else if (this.mode == ConfiguratorMode.Legs)
            {
                // disable components layer, enable legs layer
                this.physicsRaycaster.eventMask &= ~(1 << LayerMask.NameToLayer("Components"));
                this.physicsRaycaster.eventMask |= 1 << LayerMask.NameToLayer("Legs");

                this.menuListAdapter.ShowExtensionLegs(this.selectedLegs.Obj.unityId);
            }
            else if (this.mode == ConfiguratorMode.None)
            {
                // disable components layer, enable legs layer
                this.physicsRaycaster.eventMask &= ~(1 << LayerMask.NameToLayer("Components"));
                this.physicsRaycaster.eventMask |= 1 << LayerMask.NameToLayer("Legs");

                this.menuListAdapter.ShowLegs();

                foreach (LegsAreaScript area in VanDraweeStaticData.car.legsPlacingArea)
                    area.gameObject.SetActive(true);
            }
        }

        private PlacedObject raycastHitComponent()
        {
            RaycastHit hit;
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);

            int layerMask = Physics.AllLayers;
            layerMask &= ~(1 << LayerMask.NameToLayer("Ignore Raycast"));
            layerMask &= ~(1 << LayerMask.NameToLayer("Cars"));

            if (Physics.Raycast(ray, out hit, Mathf.Infinity, layerMask))
            {
                Transform objectHit = hit.transform;

                while (objectHit != null)
                {
                    if (this.placedComponentsMapping.ContainsKey(objectHit.gameObject))
                        return this.placedComponentsMapping[objectHit.gameObject];

                    objectHit = objectHit.parent;
                }
            }

            return null;
        }

        protected override async UniTaskVoid Update()
        {
            if (Input.GetMouseButtonDown(0) && !UIUtility.IsPointerOverUI())
            {
                if (this.clicks > 0)
                {
                    if (Time.time - this.lastClickTime > MAX_CLICK_DELAY)
                        this.clicks = 1;
                    else
                        this.clicks++;
                }
                else
                    this.clicks = 1;
                this.lastClickTime = Time.time;

                PlacedObject hitComponent = this.raycastHitComponent();
                bool lastClickedIsSame = this.lastClickedComponent == hitComponent;
                this.lastClickedComponent = hitComponent;

                // single click
                if (this.clicks == 1 || (this.clicks >= 2 && !lastClickedIsSame))
                {
                    if (hitComponent != null)
                    {
                        VanDraweeObject component = hitComponent.Obj as VanDraweeObject;

                        if ((this.mode == ConfiguratorMode.Components && !component.IsLegs())
                            || (this.mode != ConfiguratorMode.Components && component.IsLegs()))
                        {
                            if (this.highlightedComponent != null)
                                this.highlightedComponent.PlacedObjScript.Unhighlight();
                            this.highlightComponent(hitComponent);
                        }

                        if (this.mode == ConfiguratorMode.Components && component.IsComponent())
                        {
                            this.selectedComponent = hitComponent;
                            this.menuListAdapter.ShowComponentExtensions(this.selectedComponent.Obj.unityId);
                        }

                        if (this.mode != ConfiguratorMode.Components && component.IsLegs())
                        {
                            this.selectedLegs = hitComponent;
                            if (this.mode != ConfiguratorMode.Legs)
                                this.mode = ConfiguratorMode.Legs;
                            else
                                this.menuListAdapter.ShowExtensionLegs(this.selectedLegs.Obj.unityId);
                        }
                    }
                }
                // double click
                else if (this.clicks >= 2 && lastClickedIsSame)
                {
                    if (hitComponent == null && this.mode == ConfiguratorMode.Components)
                    {
                        this.ExitComponentsMode();
                    }
                    else if (hitComponent != null && this.mode != ConfiguratorMode.Components)
                    {
                        // enter components mode
                        Camera.main.GetComponent<CameraOrbitScript>().FocusOnTarget(hitComponent.PlacedObjScript.transform);
                        this.selectedLegs = hitComponent;
                        (this.selectedLegs.PlacedObjScript as LegsScript).SelectLegs();
                        this.mode = ConfiguratorMode.Components;
                        this.unhighlightComponent();
                    }
                    else if (hitComponent != null && this.mode == ConfiguratorMode.Components)
                        if ((hitComponent.Obj as VanDraweeObject).IsComponent())
                        {
                            this.selectedComponent = hitComponent;
                            this.menuListAdapter.ShowComponentExtensions(this.selectedComponent.Obj.unityId);
                        }
                }

                if (hitComponent == null)
                {
                    this.unhighlightComponent();

                    if (this.mode == ConfiguratorMode.Legs)
                        this.mode = ConfiguratorMode.None;
                    else if (this.mode == ConfiguratorMode.Components)
                        this.menuListAdapter.ShowComponents(this.selectedLegs.Obj as VanDraweeLegs);
                }
            }
            if (Input.GetKeyDown(KeyCode.Delete))
            {
                if (this.highlightedComponent != null)
                    this.RemoveComponent(this.highlightedComponent);
            }
            if (Input.GetKeyDown(KeyCode.Space) && this.highlightedComponent != null)
            {
                Camera.main.GetComponent<CameraOrbitScript>().FocusOnTarget(this.highlightedComponent.PlacedObjScript.transform);
            }
            if (Input.GetKeyDown(KeyCode.Escape))
            {
                this.ExitComponentsMode();
            }
            if (Input.GetKeyDown(KeyCode.U))
            {
                // in case that model is not shared yet share it now
                if (VanDraweeStaticData.modelId == String.Empty)
                {
                    PlacedObject[] placedComponents = this.placedComponentsMapping.Values.Where(
                            c => c.Parent == null).ToArray();

                    Guid guid = await StaticData.api.UploadModel(placedComponents);
                    VanDraweeStaticData.modelId = guid.ToString();

                    if (Application.platform == RuntimePlatform.WebGLPlayer)
                        JsUtility.SetHrefGuid(guid.ToString());
                }
                this.exportModel().Forget();
            }
        }

        public void ExitComponentsMode()
        {
            if (this.selectedLegs != null)
            {
                (this.selectedLegs.PlacedObjScript as LegsScript).UnselectLegs();
                this.selectedLegs = null;
                this.selectedComponent = null;
                this.mode = ConfiguratorMode.None;
                this.unhighlightComponent();
            }
        }

        public override List<PlacedObject> PlaceComponent(string id)
        {
            GameObject target = StaticData.assets.FirstOrDefault(a => a.name == id) as GameObject;
            Common.Model.Object component = StaticData.components.FirstOrDefault(c => c.unityId == id);
            if (target == null || component == null)
                return new List<PlacedObject>();

            PlaceScript placeable = target.GetComponent<PlaceScript>();
            if (placeable == null)
                return new List<PlacedObject>();

            PlacedObject placedComponent = null;

            try
            {
                placedComponent = placeable.Place(component, this.placedComponentsMapping.Values, this.origin);
                GameObject.FindObjectOfType<StatisticsScript>().AddData(
                    placedComponent.Obj.unityId, placedComponent.Obj.category);
            }
            catch (PlacementException ex)
            {
                this.notificationText.text = ex.Message;
                LayoutRebuilder.ForceRebuildLayoutImmediate(this.notificationLayout);
                this.notification.Pulse();
            }

            if (placedComponent == null)
                return new List<PlacedObject>();

            this.placedComponentsMapping.Add(placedComponent.PlacedObjScript.gameObject, placedComponent);
            this.AddToPrice(placedComponent.PlacedObjScript.GetPrice());

            if ((placedComponent.Obj as VanDraweeObject).IsLegs())
            {
                if (this.highlightedComponent != null)
                    this.highlightedComponent.PlacedObjScript.Unhighlight();
                this.highlightComponent(placedComponent);

                this.selectedLegs = placedComponent;
                this.mode = ConfiguratorMode.Legs;
            }
            else if ((placedComponent.Obj as VanDraweeObject).IsComponentExtension())
            {
                placedComponent.PlacedObjScript.Highlight();
            }

            List<PlacedObject> ret = new List<PlacedObject>();
            ret.Add(placedComponent);
            return ret;
        }

        public override void RemoveComponent(PlacedObject component)
        {
            if (component == this.selectedLegs)
            {
                this.selectedLegs = null;
                this.mode = ConfiguratorMode.None;
            }
            else if (component == this.selectedComponent)
            {
                this.selectedComponent = null;
                this.menuListAdapter.ShowComponents(this.selectedLegs.Obj as VanDraweeLegs);
            }
            else if ((component.Obj as VanDraweeObject).IsComponentExtension())
            {
                this.menuListAdapter.ShowComponents(this.selectedLegs.Obj as VanDraweeLegs);
            }

            base.RemoveComponent(component);
        }

        private async UniTask loadLegs(LegsScript legsScript, LegsAreaScript areaScript, VanDraweeLegs legsInfo,
            StoredObject storedLegs)
        {
            if (legsScript == null || areaScript == null || legsInfo == null || storedLegs == null)
                return;

            PlacedObject placedLegs = areaScript.TryPlace(legsScript, storedLegs.Position.z, legsInfo);

            if (placedLegs == null)
                return;

            this.placedComponentsMapping[placedLegs.PlacedObjScript.gameObject] = placedLegs;
            this.AddToPrice(placedLegs.PlacedObjScript.GetPrice());

            // give it time to merge legs, compute bounding boxes, etc.
            await UniTask.Yield();

            foreach (StoredObject storedComponent in storedLegs.Children.OrderByDescending(c => c.Position.y))
            {
                GameObject target = StaticData.assets.FirstOrDefault(a => a.name == storedComponent.Id) as GameObject;
                VanDraweeObject componentInfo = StaticData.components
                    .FirstOrDefault(c => c.unityId == storedComponent.Id) as VanDraweeObject;
                if (target == null || componentInfo == null)
                    continue;

                await this.loadComponent(target.GetComponent<ComponentScript>(), componentInfo, storedComponent,
                    placedLegs.PlacedObjScript.gameObject.GetComponent<LegsScript>());
            }
        }

        private async UniTask loadComponent(ComponentScript componentScript, VanDraweeObject componentInfo,
            StoredObject storedComponent, LegsScript legs)
        {
            if (componentScript == null || componentInfo == null || storedComponent == null || legs == null)
                return;

            try
            {

                PlacedObject placedComponent = componentScript.TryPlace(legs, storedComponent.Position.y, componentInfo);
                if (placedComponent == null)
                    return;

                this.placedComponentsMapping[placedComponent.PlacedObjScript.gameObject] = placedComponent;
                this.AddToPrice(placedComponent.PlacedObjScript.GetPrice());

                // give it time to merge components, compute offsets, etc.
                await UniTask.Yield();

                // there should be at max just one child
                foreach (StoredObject storedExtension in storedComponent.Children.OrderByDescending(c => c.Position.y))
                {
                    GameObject target = StaticData.assets.FirstOrDefault(a => a.name == storedExtension.Id) as GameObject;
                    VanDraweeObject extensionInfo = StaticData.components
                        .FirstOrDefault(c => c.unityId == storedExtension.Id) as VanDraweeObject;
                    if (target == null || componentInfo == null)
                        continue;

                    this.loadComponentExtension(target.GetComponent<ComponentExtensionScript>(),
                        placedComponent.PlacedObjScript as ComponentScript, extensionInfo);
                }
            } catch (PlacementException) { }
        }

        private void loadComponentExtension(ComponentExtensionScript extensionScript, ComponentScript componentScript,
            VanDraweeObject extensionInfo)
        {
            if (extensionScript == null || componentScript == null || extensionInfo == null)
                return;

            try
            {
                PlacedObject placedExtension = extensionScript.TryPlace(componentScript, extensionInfo);
                if (placedExtension == null)
                    return;

                this.placedComponentsMapping[placedExtension.PlacedObjScript.gameObject] = placedExtension;
                this.AddToPrice(placedExtension.PlacedObjScript.GetPrice());
            } catch (PlacementException) { }
        }

        public override async UniTask LoadModel(IEnumerable<StoredObject> objects)
        {
            while (this.placedComponentsMapping.Count > 0)
                this.RemoveComponent(this.placedComponentsMapping.First().Value);

            LegsAreaScript[] legsAreas = VanDraweeStaticData.car.legsPlacingArea;
            LegsAreaScript leftArea = legsAreas.FirstOrDefault(a => a.areaOnLeft);
            LegsAreaScript rightArea = legsAreas.FirstOrDefault(a => !a.areaOnLeft);

            foreach (StoredObject storedLegs in objects.OrderByDescending(o => o.Position.z))
            {
                GameObject target = StaticData.assets.FirstOrDefault(a => a.name == storedLegs.Id) as GameObject;
                VanDraweeLegs legsInfo = StaticData.components
                    .FirstOrDefault(c => c.unityId == storedLegs.Id) as VanDraweeLegs;
                if (target == null || legsInfo == null)
                    continue;

                await this.loadLegs(target.GetComponent<LegsScript>(), storedLegs.Position.x < 0 ? leftArea : rightArea,
                    legsInfo, storedLegs);
            }
        }

        private async UniTaskVoid exportModel()
        {
            string fbxString = UnityFBXExporter.FBXExporter.MeshToString(this.origin.gameObject, "");
            string csvString = ModelExporter.GetString();

            bool ok = true;
            for (int i = 0; i < 3; i++)
            {
                try
                {
                    this.progressBar.gameObject.SetActive(true);
                    var progress = Progress.Create<float>(p => this.progressBar.Progress = p);
                    await (StaticData.api as VanDraweeAPI)
                        .UploadFBX(VanDraweeStaticData.modelId, fbxString, csvString, progress);
                }
                catch (Exception ex)
                {
                    ok = false;
                    this.notificationText.text = ex.Message;
                    LayoutRebuilder.ForceRebuildLayoutImmediate(this.notificationLayout);
                    this.notification.Pulse();
                }
                this.progressBar.gameObject.SetActive(false);
                if (ok)
                    break;
                ok = true;
            }
            if (ok)
                this.notificationText.text = LeanLocalization.GetTranslationText("EXPORT_DONE");
            else
                this.notificationText.text = LeanLocalization.GetTranslationText("EXPORT_ERROR");

            LayoutRebuilder.ForceRebuildLayoutImmediate(this.notificationLayout);
            this.notification.Pulse();
        }
    }
}
