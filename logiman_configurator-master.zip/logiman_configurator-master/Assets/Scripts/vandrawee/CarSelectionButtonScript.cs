﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Assets.Scripts.vandrawee
{
    public class CarSelectionButtonScript : MonoBehaviour
    {
        public string carId;

        public string carModelName;

        public string legsBundle;

        public void OnClick()
        {
            VanDraweeStaticData.carId = this.carId;
            VanDraweeStaticData.carModelName = this.carModelName;
            VanDraweeStaticData.legsBundle = this.legsBundle;
            SceneManager.LoadScene("VanDraweeCarsScene");
        }
    }
}
