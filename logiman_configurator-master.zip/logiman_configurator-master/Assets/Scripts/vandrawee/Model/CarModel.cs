﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assets.Scripts.vandrawee.Model
{
    public class CarModel
    {
        public string name;

        public int orderBy;

        public string unityId;

        public string legsBundle;

        public bool enabled;
    }
}
