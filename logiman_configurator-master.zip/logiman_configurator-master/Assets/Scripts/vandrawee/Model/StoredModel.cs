﻿using Assets.Scripts.Common.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assets.Scripts.vandrawee.Model
{
    public class StoredModel
    {
        public string carId;

        public string data;
    }
}
