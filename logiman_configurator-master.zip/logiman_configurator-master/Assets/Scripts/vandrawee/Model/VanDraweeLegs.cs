﻿using Assets.Scripts.Common.Model;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Assets.Scripts.vandrawee.Model
{
    public class VanDraweeLeg : VanDraweeObject
    {
        public Part[] parts;
    }

    public class VanDraweeExtensionLegs : VanDraweeObject
    {
        public string legsUnityId;
    }

    public class VanDraweeLegs : VanDraweeObject
    {
        public uint size;

        public VanDraweeLeg singleLeg;

        public VanDraweeLeg replacementLeg;

        public string[] components;

        public VanDraweeExtensionLegs[] extensions;
    }
}
