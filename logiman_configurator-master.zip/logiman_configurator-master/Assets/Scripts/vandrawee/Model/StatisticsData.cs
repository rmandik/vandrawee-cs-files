﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Assets.Scripts.vandrawee.Model
{
    [Serializable]
    public class StatisticsData
    {
        [SerializeField]
        public string type;

        [SerializeField]
        public string name;

        [SerializeField]
        public int count;
    }
}
