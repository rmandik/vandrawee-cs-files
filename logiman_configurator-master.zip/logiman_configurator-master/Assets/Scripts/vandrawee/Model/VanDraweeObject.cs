﻿using Assets.Scripts.Common.Model;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Assets.Scripts.vandrawee.Model
{
    public class VanDraweeObject : Common.Model.Object
    {
        public bool IsLegs()
        {
            return this.category == "Legs_1057" || this.category == "Legs_1357";
        }

        public bool IsExtensionLegs()
        {
            return this.category == "Extension_legs";
        }

        public bool IsComponentExtension()
        {
            return this.category == "Component_extension";
        }

        public bool IsComponent()
        {
            return this.category == "Components_1057" || this.category == "Components_1357";
        }
    }
}
