﻿using Assets.Scripts.vandrawee.LegScripts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Assets.Scripts.vandrawee
{
    public class CarScript : MonoBehaviour
    {
        public LegsAreaScript[] legsPlacingArea;

        public Renderer[] body;

        public void SetBodyRendererEnabled(bool set)
        {
            foreach (Renderer renderer in this.body)
                renderer.enabled = set;
        }
    }
}
