using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using frame8.Logic.Misc.Other.Extensions;
using Com.TheFallenGames.OSA.Core;
using Com.TheFallenGames.OSA.CustomParams;
using Com.TheFallenGames.OSA.DataHelpers;
using System.Linq;
using Cysharp.Threading.Tasks;
using UnityEngine.Networking;
using Assets.Scripts.Common;
using Lean.Localization;
using Assets.Scripts.vandrawee.Model;

namespace Assets.Scripts.vandrawee
{
	public class ComponentsMenuListAdapter : OSA<BaseParamsWithPrefab, ComponentsMenuListItemViewsHolder>
	{
		private enum showContent { NONE, LEGS, EXTENSION_LEGS, COMPONENTS, COMPONENT_EXTENSIONS };

		private showContent currentContent = showContent.NONE;

		private string currentLegsExtensionsId = "";

		private string currentComponentExtensionsId = "";

		private List<ComponentsMenuItemModel> components = new List<ComponentsMenuItemModel>();

		private Dictionary<string, List<ComponentsMenuItemModel>> extensionLegs = new Dictionary<string, List<ComponentsMenuItemModel>>();

		private Dictionary<string, List<ComponentsMenuItemModel>> componentExtensions = new Dictionary<string, List<ComponentsMenuItemModel>>();

		public SimpleDataHelper<ComponentsMenuItemModel> Data { get; private set; }

		public void DisableLegs()
        {
			for (int i = 0; i < this.Data.Count; i++)
            {
				if ((this.Data[i].component as VanDraweeObject).IsLegs())
                {
					this.Data[i].enabled = false;

					ComponentsMenuListItemViewsHolder holder = this.GetItemViewsHolderIfVisible(i);
					if (holder != null)
						this.UpdateViewsHolder(holder);
                }
            }
        }

		public void EnableLegs()
        {
			for (int i = 0; i < this.Data.Count; i++)
            {
				if ((this.Data[i].component as VanDraweeObject).IsLegs())
                {
					this.Data[i].enabled = true;

					ComponentsMenuListItemViewsHolder holder = this.GetItemViewsHolderIfVisible(i);
					if (holder != null)
						this.UpdateViewsHolder(holder);
                }
            }
        }

		public void ShowLegs()
        {
			if (this.currentContent != showContent.LEGS)
			{
				List<ComponentsMenuItemModel> components = this.components
					.Where(c => c.component.enabled)
					.Where(c => (c.component as VanDraweeObject).IsLegs())
					.OrderBy(c => c.component.orderBy).ToList();
				components.ForEach(c => c.sizeChanged = true);

				this.Data.ResetItems(components);
				this.currentContent = showContent.LEGS;
				this.currentLegsExtensionsId = "";
			}
        }

		public void ShowExtensionLegs(string legsUnityId)
        {
			if (this.currentContent != showContent.EXTENSION_LEGS ||
				this.currentLegsExtensionsId != legsUnityId)
			{
				List<ComponentsMenuItemModel> components = this.extensionLegs[legsUnityId]
					.Where(c => c.component.enabled)
					.OrderBy(c => c.component.orderBy).ToList();
				components.ForEach(c => c.sizeChanged = true);

				this.Data.ResetItems(components);
				this.currentContent = showContent.EXTENSION_LEGS;
				this.currentLegsExtensionsId = legsUnityId;
			}
        }

		public void ShowComponentExtensions(string componentUnityId)
        {
			if (this.currentContent != showContent.COMPONENT_EXTENSIONS ||
				this.currentComponentExtensionsId != componentUnityId)
			{
				List<ComponentsMenuItemModel> components = this.componentExtensions[componentUnityId]
					.Where(c => c.component.enabled)
					.OrderBy(c => c.component.orderBy).ToList();
				components.ForEach(c => c.sizeChanged = true);

				this.Data.ResetItems(components);
				this.currentContent = showContent.COMPONENT_EXTENSIONS;
				this.currentLegsExtensionsId = componentUnityId;
			}
        }

		public void ShowComponents(VanDraweeLegs legs)
        {
			if (this.currentContent != showContent.COMPONENTS)
            {
				List<ComponentsMenuItemModel> components = this.components
					.Where(c => c.component.enabled)
					.Where(c => legs.components.Contains(c.component.unityId))
					.OrderBy(c => c.component.orderBy).ToList();
				components.ForEach(c => c.sizeChanged = true);

				this.Data.ResetItems(components);
				this.currentContent = showContent.COMPONENTS;
				this.currentLegsExtensionsId = "";
            }
        }

		protected override void Start()
		{
			Data = new SimpleDataHelper<ComponentsMenuItemModel>(this);

			base.Start();
			this.retrieveDataAndUpdate().Forget();
            LeanLocalization.OnLocalizationChanged += LeanLocalization_OnLocalizationChanged;
		}

        private void LeanLocalization_OnLocalizationChanged()
        {
			for (int i = 0; i < this.Data.Count; i++)
            {
				this.Data[i].sizeChanged = true;

                ComponentsMenuListItemViewsHolder holder = this.GetItemViewsHolderIfVisible(i);

				if (holder != null)
                {
					if (LeanLocalization.CurrentLanguage == "Czech")
					{
						holder.name.text = this.Data[i].component.name;
                        holder.price.text = String.Format("{0} K�", this.Data[i].component.price);
					}
					else
					{
						holder.name.text = this.Data[i].component.name_EN;
                        holder.price.text = String.Format("{0} CZK", this.Data[i].component.price);
					}

					this.ForceRebuildViewsHolderAndUpdateSize(holder);
                }
            }
        }

        protected override ComponentsMenuListItemViewsHolder CreateViewsHolder(int itemIndex)
		{
			var instance = new ComponentsMenuListItemViewsHolder();
			instance.Init(_Params.ItemPrefab, _Params.Content, itemIndex);

			return instance;
		}

		protected override void UpdateViewsHolder(ComponentsMenuListItemViewsHolder newOrRecycled)
		{
			ComponentsMenuItemModel model = this.Data[newOrRecycled.ItemIndex];

			if (LeanLocalization.CurrentLanguage == "Czech")
			{
				newOrRecycled.name.text = model.component.name;
                newOrRecycled.price.text = String.Format("{0} K�", model.component.price);
			}
			else
			{
				newOrRecycled.name.text = model.component.name_EN;
                newOrRecycled.price.text = String.Format("{0} CZK", model.component.price);
			}

			if (model.image != null)
			{
				newOrRecycled.image.gameObject.SetActive(true);
				newOrRecycled.image.overrideSprite = Sprite.Create(model.image,
					new Rect(0, 0, model.image.width, model.image.height), new Vector2(0.5f, 0.5f));

				Canvas.ForceUpdateCanvases();
				newOrRecycled.image.GetComponent<LayoutElement>().preferredHeight = model.image.height * newOrRecycled.image.rectTransform.rect.width / model.image.width;
			}
			else
				newOrRecycled.image.gameObject.SetActive(false);

			newOrRecycled.price_EUR.text = String.Format("{0} EUR", model.component.price_EUR);
			newOrRecycled.scrollViewMenuItemScript.id = model.component.unityId;
			newOrRecycled.button.interactable = model.enabled;

			if (model.sizeChanged)
                ScheduleComputeVisibilityTwinPass();
		}

        protected override void OnItemHeightChangedPreTwinPass(ComponentsMenuListItemViewsHolder viewsHolder)
        {
            base.OnItemHeightChangedPreTwinPass(viewsHolder);
			this.Data[viewsHolder.ItemIndex].sizeChanged = false;
        }

        protected override void RebuildLayoutDueToScrollViewSizeChange()
        {
			foreach (var model in this.Data)
				model.sizeChanged = true;
            base.RebuildLayoutDueToScrollViewSizeChange();
        }

        private async UniTaskVoid downloadPreviewImage(string unityId, ComponentsMenuItemModel item)
        {
			await UniTask.Delay(1000);
            using (UnityWebRequest request = UnityWebRequestTexture.GetTexture(
                Application.streamingAssetsPath + "/previews/" + unityId + ".png"))
            {
                try
                {
                    await request.SendWebRequest();
					item.image = DownloadHandlerTexture.GetContent(request);
					item.sizeChanged = true;

					for (int i = 0; i < this.Data.Count; i++)
						if (this.Data[i] == item)
                        {
                            ComponentsMenuListItemViewsHolder holder = this.GetItemViewsHolderIfVisible(i);
                            holder.image.gameObject.SetActive(true);
                            holder.image.overrideSprite = Sprite.Create(item.image,
                                new Rect(0, 0, item.image.width, item.image.height), new Vector2(0.5f, 0.5f));

                            Canvas.ForceUpdateCanvases();
                            holder.image.GetComponent<LayoutElement>().preferredHeight = item.image.height * holder.image.rectTransform.rect.width / item.image.width;
							if (holder != null)
								this.ForceRebuildViewsHolderAndUpdateSize(holder);
							break;
                        }
                }
                catch (Exception) { }
            }
        }

		private async UniTaskVoid retrieveDataAndUpdate()
		{
			Common.Model.Object[] components = (await (StaticData.api as VanDraweeAPI).GetComponents())
				.OrderBy(c => c.orderBy).ToArray();

			foreach (Common.Model.Object obj in components)
            {
				ComponentsMenuItemModel item = new ComponentsMenuItemModel();
				item.component = obj;
				this.downloadPreviewImage(obj.unityId, item).Forget();
				this.components.Add(item);

				if ((obj as VanDraweeObject).IsLegs())
                {
					VanDraweeLegs legs = obj as VanDraweeLegs;
					this.extensionLegs.Add(legs.unityId, new List<ComponentsMenuItemModel>());

					foreach (VanDraweeExtensionLegs ext in legs.extensions)
                    {
                        ComponentsMenuItemModel extension = new ComponentsMenuItemModel();
						this.downloadPreviewImage(ext.unityId, extension).Forget();
						ext.unityId = ext.legsUnityId;
						extension.component = ext;
						this.extensionLegs[legs.unityId].Add(extension);
                    }
                }
				else if ((obj as VanDraweeObject).IsComponent())
                {
					VanDraweeComponent component = obj as VanDraweeComponent;
					this.componentExtensions.Add(component.unityId, new List<ComponentsMenuItemModel>());

					foreach (VanDraweeComponentExtension ext in component.extensions)
                    {
						ComponentsMenuItemModel extension = new ComponentsMenuItemModel();
						this.downloadPreviewImage(ext.unityId, extension).Forget();
						extension.component = ext;
						this.componentExtensions[component.unityId].Add(extension);
                    }
                }
            }

			this.ShowLegs();
		}
	}

	public class ComponentsMenuItemModel
	{
		public Common.Model.Object component;

		public Texture2D image;

		public bool enabled;

		public bool sizeChanged;

		public ComponentsMenuItemModel()
        {
			this.enabled = true;
			this.sizeChanged = true;
        }
	}

	public class ComponentsMenuListItemViewsHolder : BaseItemViewsHolder
	{
		public Button button;

		public Text name;

		public Image image;

		public Text price;

		public Text price_EUR;

		public ScrollViewMenuItemScript scrollViewMenuItemScript;

		public ContentSizeFitter contentSizeFitter;

		public override void CollectViews()
		{
			base.CollectViews();

			root.GetComponentAtPath("", out this.button);
			root.GetComponentAtPath("Name", out this.name);
			root.GetComponentAtPath("Image", out this.image);
			root.GetComponentAtPath("Prices/Price", out this.price);
			root.GetComponentAtPath("Prices/Price EUR", out this.price_EUR);
			this.scrollViewMenuItemScript = root.GetComponent<ScrollViewMenuItemScript>();
			this.contentSizeFitter = root.GetComponent<ContentSizeFitter>();

			this.contentSizeFitter.enabled = false;
		}

		public override void MarkForRebuild()
		{
			base.MarkForRebuild();

			LayoutRebuilder.MarkLayoutForRebuild(this.root);
			this.contentSizeFitter.enabled = true;
		}

		public override void UnmarkForRebuild()
		{
			this.contentSizeFitter.enabled = false;

			base.UnmarkForRebuild();
		}
	}
}
