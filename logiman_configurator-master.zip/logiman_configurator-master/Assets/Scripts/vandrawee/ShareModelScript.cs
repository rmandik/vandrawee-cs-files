﻿using Assets.Scripts.Common;
using Assets.Scripts.Common.Model;
using Assets.Scripts.Common.Utility;
using Assets.Scripts.vandrawee.LegScripts;
using Cysharp.Threading.Tasks;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.UI;

namespace Assets.Scripts.vandrawee
{
    public class ShareModelScript : MonoBehaviour
    {


        private async UniTaskVoid shareAsync()
        {
            ModelHelperScript modelHelperScript = GameObject.Find("modelHelper").GetComponent<ModelHelperScript>();

            PlacedObject[] placedComponents = modelHelperScript.placedComponentsMapping.Values.Where(
                    c => c.Parent == null).ToArray();

            Guid guid = await StaticData.api.UploadModel(placedComponents);
            VanDraweeStaticData.modelId = guid.ToString();

            if (Application.platform == RuntimePlatform.WebGLPlayer)
            {
                JsUtility.SetHrefGuid(guid.ToString());
                JsUtility.CopyHrefToClipboard();
            }
        }

        public void OnShareButtonClick()
        {
            this.shareAsync().Forget();
        }
    }
}
