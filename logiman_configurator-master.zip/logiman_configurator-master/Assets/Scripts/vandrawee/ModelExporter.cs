﻿using Assets.Scripts.vandrawee.ComponentScripts;
using Assets.Scripts.vandrawee.LegScripts;
using Assets.Scripts.vandrawee.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assets.Scripts.vandrawee
{
    public static class ModelExporter
    {
        private static void addParts(Part[] parts, Dictionary<string, uint> dict)
        {
            foreach (Part part in parts)
                if (!dict.ContainsKey(part.unityId))
                    dict.Add(part.unityId, part.count);
                else
                    dict[part.unityId] += part.count;
        }

        private static void addComponents(VanDraweeComponent[] components, Dictionary<string, uint> dict)
        {
            foreach (VanDraweeComponent component in components)
                if (!dict.ContainsKey(component.unityId))
                    dict.Add(component.unityId, 1);
                else
                    dict[component.unityId]++;
        }

        private static void addComponentExtension(VanDraweeComponentExtension extension, Dictionary<string, uint> dict)
        {
            if (!dict.ContainsKey(extension.unityId))
                dict.Add(extension.unityId, 1);
            else
                dict[extension.unityId]++;
        }

        private static void addToDictionary(Dictionary<string, uint> destination,
            Dictionary<string, uint> source)
        {
            foreach (var part in source)
                if (!destination.ContainsKey(part.Key))
                    destination.Add(part.Key, part.Value);
                else
                    destination[part.Key] += part.Value;
        }

        public static string GetString()
        {
            Dictionary<string, uint> totalComponents = new Dictionary<string, uint>();
            Dictionary<string, uint> totalParts = new Dictionary<string, uint>();
            uint singleLegsNum = 1;
            StringBuilder perLegsSb = new StringBuilder();
            StringBuilder drillingSb = new StringBuilder();

            foreach (LegsAreaScript area in VanDraweeStaticData.car.legsPlacingArea)
            {
                bool skipLeftLeg = false;
                Dictionary<string, uint> componentsInArea = new Dictionary<string, uint>();
                Dictionary<string, uint> partsInArea = new Dictionary<string, uint>();
                int mergedComponentsCount = 0;

                foreach (LegsScript legs in area.Legs)
                {
                    ComponentScript[] componentScripts = legs.GetComponents();
                    foreach (ComponentScript component in componentScripts)
                    {
                        MoveableComponentScript moveableComponent = component as MoveableComponentScript;
                        if (moveableComponent != null)
                        {
                            if (moveableComponent.IsMerged)
                                mergedComponentsCount++;
                            if (moveableComponent.Extension != null)
                            {
                                VanDraweeComponentExtension extension = moveableComponent.Extension
                                    .PlacedObj.Obj as VanDraweeComponentExtension;
                                addComponentExtension(extension, componentsInArea);
                                addParts(extension.parts, partsInArea);
                            }
                        }
                    }

                    VanDraweeComponent[] components = componentScripts
                        .Select(c => c.PlacedObj.Obj as VanDraweeComponent).ToArray();

                    VanDraweeLeg leftLeg = legs.leftLeg.PlacedObj.Obj as VanDraweeLeg;
                    VanDraweeLeg rightLeg = legs.rightLeg.PlacedObj.Obj as VanDraweeLeg;

                    if (!skipLeftLeg)
                    {
                        legs.leftLeg.ExportDrillingDimensions(drillingSb, singleLegsNum);
                        singleLegsNum += 2;
                        skipLeftLeg = true;
                        addParts(leftLeg.parts, partsInArea);
                    }
                    legs.rightLeg.ExportDrillingDimensions(drillingSb, singleLegsNum);
                    singleLegsNum += 2;
                    addParts(rightLeg.parts, partsInArea);

                    addComponents(components, componentsInArea);

                    foreach (VanDraweeComponent component in components)
                        addParts(component.parts, partsInArea);
                }

                addToDictionary(totalComponents, componentsInArea);
                addToDictionary(totalParts, partsInArea);

                if (area.areaOnLeft)
                    perLegsSb.Append("Levy regal\n");
                else
                    perLegsSb.Append("Pravy regal\n");
                perLegsSb.Append(String.Format(";Pocet spojenych komponent; {0}\n", mergedComponentsCount));

                foreach (var component in componentsInArea.OrderBy(c => c.Key))
                    perLegsSb.Append(String.Format(";{0};{1}\n", component.Key, component.Value));
                perLegsSb.Append("\n");

                foreach (var part in partsInArea.OrderBy(p => p.Key))
                    perLegsSb.Append(String.Format(";{0};{1}\n", part.Key, part.Value));
                perLegsSb.Append("\n\n");
            }

            StringBuilder ret = new StringBuilder();
            ret.Append("Vrtani\n");
            ret.Append(drillingSb.ToString());
            ret.Append("\n");

            ret.Append("Seznam vsech dilu (vcetne nohou)\n");
            foreach (var part in totalParts.OrderBy(p => p.Key))
                ret.Append(String.Format(";{0};{1}\n", part.Key, part.Value));
            ret.Append("\n\n");

            ret.Append("Seznam vsech komponent\n");
            foreach (var component in totalComponents.OrderBy(c => c.Key))
                ret.Append(String.Format(";{0};{1}\n", component.Key, component.Value));
            ret.Append("\n\n");

            ret.Append(perLegsSb.ToString());

            return ret.ToString();
        }
    }
}
