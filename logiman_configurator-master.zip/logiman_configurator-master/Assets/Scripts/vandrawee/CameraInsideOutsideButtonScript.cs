﻿using Assets.Scripts.Common;
using Lean.Localization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.UI;

namespace Assets.Scripts.vandrawee
{
    public class CameraInsideOutsideButtonScript : MonoBehaviour
    {
        public LeanLocalizedText localizedText;

        private bool cameraInside = true;

        public void OnClick()
        {
            Transform car = VanDraweeStaticData.car.transform;

            if (this.cameraInside)
            {
                this.localizedText.TranslationName = "CAMERA_OUTSIDE_BUTTON";
                Camera.main.GetComponent<CameraOrbitScript>().FocusOnTarget(car, 0);
            }
            else
            {
                this.localizedText.TranslationName = "CAMERA_INSIDE_BUTTON";
                Camera.main.GetComponent<CameraOrbitScript>().FocusOnTarget(car, 2.1f);
            }

            this.cameraInside = !this.cameraInside;
        }
    }
}
