﻿using Assets.Scripts.Common.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assets.Scripts.vandrawee
{
    public static class VanDraweeStaticData
    {
        public static string carId = "Ducato_Jumper_Boxer_L1H1";

        public static string carModelName = "Fiat Ducato L1H1 3000 mm";

        public static string legsBundle = "Ducato_H1_legs";

        public static string modelId = "";

        public static StoredObject[] model = new StoredObject[0];

        public static CarScript car = null;
    }
}
