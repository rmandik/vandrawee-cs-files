﻿using Assets.Scripts.Common;
using Assets.Scripts.Common.Model;
using Assets.Scripts.vandrawee.LegScripts;
using Assets.Scripts.vandrawee.Model;
using Lean.Localization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Assets.Scripts.vandrawee
{
    public class PlaceLegsScript : PlaceScript
    {
        public override PlacedObject Place(Common.Model.Object component, IEnumerable<PlacedObject> placedComponents, Transform origin)
        {
            VanDraweeModelHelperScript modelHelperScript = GameObject.FindObjectOfType<VanDraweeModelHelperScript>();

            if (modelHelperScript.mode == ConfiguratorMode.None)
            {
                List<LegsAreaScript> areas = VanDraweeStaticData.car.legsPlacingArea
                    .Where(a => a.Legs.Count == 0).OrderByDescending(a => a.length).ToList();

                if (areas.Count == 0)
                    throw new PlacementException(
                        LeanLocalization.GetTranslationText("UNABLE_TO_PLACE_LEGS_ERROR"));

                foreach (LegsAreaScript area in areas)
                {
                    PlacedObject c = area.TryPlace(this.GetComponent<LegsScript>(), float.MaxValue, component as VanDraweeLegs);
                    if (c != null)
                        return c;
                }
                throw new PlacementException(
                    LeanLocalization.GetTranslationText("NOT_ENOUGH_SPACE_TO_PLACE_LEGS_ERROR"));
            }
            else if (modelHelperScript.mode == ConfiguratorMode.Legs && modelHelperScript.selectedLegs != null)
            {
                LegsScript selectedLegs = modelHelperScript.selectedLegs.PlacedObjScript as LegsScript;

                if (selectedLegs != null)
                {
                    PlacedObject c = selectedLegs.LegsArea.TryPlaceNextTo(this.GetComponent<LegsScript>(), selectedLegs, origin, component as VanDraweeLegs);
                    if (c != null)
                        return c;
                }
                throw new PlacementException(LeanLocalization.GetTranslationText("NOT_ENOUGH_SPACE_TO_EXTEND_LEGS_ERROR"));
            }
            throw new PlacementException("");
        }
    }
}
