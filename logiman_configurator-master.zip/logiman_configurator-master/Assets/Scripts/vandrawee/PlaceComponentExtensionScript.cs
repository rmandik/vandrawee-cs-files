﻿using Assets.Scripts.Common;
using Assets.Scripts.Common.Model;
using Assets.Scripts.vandrawee.ComponentScripts;
using Assets.Scripts.vandrawee.Model;
using Lean.Localization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Assets.Scripts.vandrawee
{
    public class PlaceComponentExtensionScript : PlaceScript
    {
        public override PlacedObject Place(Common.Model.Object obj, IEnumerable<PlacedObject> placedComponents, Transform origin)
        {
            VanDraweeModelHelperScript modelHelperScript = GameObject.FindObjectOfType<VanDraweeModelHelperScript>();

            if (modelHelperScript.mode == ConfiguratorMode.Components && modelHelperScript.selectedLegs != null)
            {
                PlacedObject ret = this.GetComponent<ComponentExtensionScript>()
                    .TryPlace(modelHelperScript.selectedComponent.PlacedObjScript as ComponentScript,
                    obj as VanDraweeObject);

                if (ret != null)
                    return ret;
                throw new PlacementException(LeanLocalization.GetTranslationText("NOT_ENOUGH_SPACE_TO_PLACE_COMPONENT_EXTENSION_ERROR"));
            }
            throw new PlacementException("");
        }
    }
}
