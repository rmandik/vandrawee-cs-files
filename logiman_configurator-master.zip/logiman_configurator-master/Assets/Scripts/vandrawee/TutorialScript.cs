﻿using Assets.Scripts.Common;
using Assets.Scripts.vandrawee.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Assets.Scripts.vandrawee
{
    public class TutorialScript : MonoBehaviour
    {
        public CameraOrbitScript cameraScript;

        public Transform reparentedContainer;

        public Transform languageDropdown;

        public Transform leftMenu;

        public Transform leanPulse;

        public GameObject legsTutorial;

        public GameObject componentsTutorial;

        public VanDraweeModelHelperScript modelHelperScript;

        public ComponentsMenuListAdapter menuListAdapter;

        private Dictionary<Transform, Transform> reparentedOriginalParents = new Dictionary<Transform, Transform>();

        void Start()
        {
            this.cameraScript.rotationEnabled = false;
            this.cameraScript.movementEnabled = false;
            this.cameraScript.zoomEnabled = false;

            this.reparent(this.languageDropdown);
            this.reparent(this.leftMenu);
            this.reparent(this.leanPulse);
            this.modelHelperScript.highlightedComponentChanged += legsPlaced;
        }

        private void legsPlaced(object sender, ComponentHighlightedArgs e)
        {
            if ((e.highlightedComponent.Obj as VanDraweeObject).IsLegs())
            {
                Camera.main.GetComponent<CameraOrbitScript>().FocusOnTarget(e.highlightedComponent.PlacedObjScript.transform);
                this.menuListAdapter.DisableLegs();
                this.modelHelperScript.highlightedComponentChanged -= legsPlaced;
                this.modelHelperScript.highlightedComponentChanged += componentPlaced;
                this.componentsTutorial.SetActive(true);
                this.legsTutorial.SetActive(false);
            }
        }

        private void componentPlaced(object sender, ComponentHighlightedArgs e)
        {
            if ((e.highlightedComponent.Obj as VanDraweeObject).IsComponent())
            {
                this.modelHelperScript.highlightedComponentChanged -= componentPlaced;
                this.menuListAdapter.EnableLegs();

                this.returnReparented(this.leftMenu);
                this.returnReparented(this.languageDropdown);
                this.returnReparented(this.leanPulse);
                this.cameraScript.rotationEnabled = true;
                this.cameraScript.movementEnabled = true;
                this.cameraScript.zoomEnabled = true;
                this.componentsTutorial.SetActive(false);
            }
        }

        private void reparent(Transform target)
        {
            this.reparentedOriginalParents.Add(target, target.parent);
            target.parent = this.reparentedContainer;
        }

        private void returnReparented(Transform target)
        {
            if (this.reparentedOriginalParents.ContainsKey(target))
            {
                target.parent = this.reparentedOriginalParents[target];
                this.reparentedOriginalParents.Remove(target);
            }
        }
    }
}
