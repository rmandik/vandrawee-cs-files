﻿using Assets.Scripts.Common.Model;
using Assets.Scripts.Common.Utility;
using Assets.Scripts.vandrawee.Model;
using Cysharp.Threading.Tasks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace Assets.Scripts.vandrawee
{
    public class CarSelectionScript : MonoBehaviour
    {
        public Transform Content;

        public GameObject LoadingScreen;

        public GameObject ManufacturerItemPrefab;

        public GameObject CarTypeItemPrefab;

        public GameObject CarModelItemPrefab;

        async UniTaskVoid Awake()
        {
            VanDraweeAPI api = null;

            if (Application.platform == RuntimePlatform.WebGLPlayer)
                api = new VanDraweeAPI(JsUtility.GetLocationProtocol() + "//" + JsUtility.GetLocationHostname() + "/api/");
            else if (Application.platform == RuntimePlatform.WindowsEditor)
                api = new VanDraweeAPI("https://test.vandrawee.cz/api/");

            Manufacturer[] manufacturers = await api.GetCars();

            if (Application.platform == RuntimePlatform.WebGLPlayer)
            {
                string possibleGuid = JsUtility.GetLocationPathname().Trim('/');
                Guid guid;

                if (Guid.TryParse(possibleGuid, out guid))
                {
                    try
                    {
                        StoredObject[] model = await api.GetModel(guid);
                        VanDraweeStaticData.legsBundle = "";
                        VanDraweeStaticData.modelId = guid.ToString();

                        CarModel carModel = manufacturers.SelectMany(m => m.carTypes)
                            .SelectMany(t => t.carModels).First(m => m.unityId == VanDraweeStaticData.carId);
                        CarType carType = manufacturers.SelectMany(m => m.carTypes)
                            .First(t => t.carModels.Contains(carModel));
                        Manufacturer manufacturer = manufacturers.First(m => m.carTypes.Contains(carType));

                        VanDraweeStaticData.carModelName = manufacturer.name + " " + carType.name + " " + carModel.name;
                        VanDraweeStaticData.legsBundle = carModel.legsBundle;
                        VanDraweeStaticData.model = model;
                        SceneManager.LoadScene("VanDraweeCarsScene");
                    } catch (Exception) { }
                }
            }

            foreach (Manufacturer manufacturer in manufacturers.OrderBy(m => m.orderBy))
            {
                GameObject manufacturerItem = Instantiate(this.ManufacturerItemPrefab, this.Content);
                manufacturerItem.transform.Find("Text").GetComponent<Text>().text = manufacturer.name;
                // load logo
                Sprite sprite = Resources.Load<Sprite>("Textures/logos/" + manufacturer.name);

                if (sprite != null)
                    manufacturerItem.transform.Find("Image").GetComponent<Image>().sprite = sprite;
                else
                    Destroy(manufacturerItem.transform.Find("Image").gameObject);

                foreach (CarType type in manufacturer.carTypes.OrderBy(t => t.orderBy))
                {
                    Transform carTypes = manufacturerItem.transform;
                    GameObject carTypeItem = Instantiate(this.CarTypeItemPrefab, carTypes);

                    carTypeItem.transform.Find("Text").GetComponent<Text>().text = type.name;

                    foreach (CarModel model in type.carModels.OrderBy(m => m.orderBy))
                    {
                        GameObject carModelItem = Instantiate(this.CarModelItemPrefab, carTypeItem.transform);
                        Transform button = carModelItem.transform.Find("Button");

                        CarSelectionButtonScript carSelectionButtonScript =
                            button.GetComponent<CarSelectionButtonScript>();
                        carSelectionButtonScript.carId = model.unityId;
                        carSelectionButtonScript.carModelName = manufacturer.name + " " + type.name + " " + model.name;
                        carSelectionButtonScript.legsBundle = model.legsBundle;

                        if (!model.enabled || model.unityId == String.Empty)
                            button.GetComponent<Button>().interactable = false;

                        button.Find("Text").GetComponent<Text>().text = model.name;
                    }
                }
            }

            if (this.LoadingScreen != null)
                this.LoadingScreen.SetActive(false);
        }
    }
}
