﻿using Assets.Scripts.vandrawee.LegScripts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Assets.Scripts.vandrawee.ComponentScripts
{
    public class BottomComponentScript : MoveableComponentScript
    {
        public bool IsBottomLimitingAlu;

        public bool IsTopLimitingPlywood;

        public override float GetVsLegsMaxY(LegsScript legs)
        {
            float max = legs.GetBottomInnerMaxY() - this.topVsLegsOffset;

            if (this.IsTopLimitingPlywood && legs.HasTopArea())
                max += ALU_OFFSET;
            return max;
        }

        public override float GetVsLegsMinY(LegsScript legs)
        {
            float min = legs.GetBottomInnerMinY() - this.bottomVsLegsOffset;

            if (this.IsBottomLimitingAlu && legs.IsBottomLimitingPlywood())
                min -= ALU_OFFSET;
            return min;
        }
    }
}
