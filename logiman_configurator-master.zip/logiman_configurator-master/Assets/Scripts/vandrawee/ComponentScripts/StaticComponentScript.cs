﻿using Assets.Scripts.Common.Model;
using Assets.Scripts.Common.Utility;
using Assets.Scripts.vandrawee.LegScripts;
using Assets.Scripts.vandrawee.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Assets.Scripts.vandrawee.ComponentScripts
{
    public class StaticComponentScript : ComponentScript
    {
        public BoxCollider bottomColliderVsLegs;

        private float bottomVsLegsOffset;

        public override PlacedObject TryPlace(LegsScript legs, float preferredY, VanDraweeObject componentInfo)
        {
            this.topVsComponentsSameLegsOffset = this.topColliderVsComponents.center.z + this.topColliderVsComponents.size.z / 2;
            this.bottomVsComponentsSameLegsOffset = this.bottomColliderVsComponents.center.z - this.bottomColliderVsComponents.size.z / 2;
            this.bottomVsLegsOffset = this.bottomColliderVsLegs.center.z - this.bottomColliderVsLegs.size.z / 2;

            return base.TryPlace(legs, preferredY, componentInfo);
        }

        protected override void Start()
        {
            this.bottomVsLegsOffset = this.bottomColliderVsLegs.center.z - this.bottomColliderVsLegs.size.z / 2;
            base.Start();
        }

        protected override float moveInLegs(LegsScript legs, float prefferedY, bool movingUp)
        {
            return this.transform.position.y;
        }

        public override bool TryPlaceInLegs(LegsScript legs, float preferredY, out Vector3 position,
            bool searchDown = true)
        {
            // ignoring preferred Y
            // assuming this component does not collide with side components
            bool collides = false;
            float thisYPos = legs.GetFloorY() - bottomVsLegsOffset;
            float thisTopY = thisYPos + this.topVsComponentsSameLegsOffset;
            float thisBottomY = thisYPos + this.bottomVsComponentsSameLegsOffset;

            List<ComponentScript> components = legs.GetComponentsInChildren<ComponentScript>().ToList();
            components.Remove(this);

            // none of already placed components intersects with this one
            foreach (ComponentScript placedComponent in components)
            {
                float otherTopY = placedComponent.GetVsComponentsSameLegsTopY();
                float otherBottomY = placedComponent.GetVsComponentsSameLegsBottomY();

                // hitting other component
                if (thisBottomY < otherTopY &&
                    thisTopY > otherBottomY &&
                    !CustomMathf.Approximately(thisBottomY, otherTopY) &&
                    !CustomMathf.Approximately(thisTopY, otherBottomY))
                {
                    collides = true;
                    break;
                }
            }

            if (!collides)
            {
                position = new Vector3(legs.transform.position.x, thisYPos, legs.transform.position.z);
                return true;
            }

            position = Vector3.zero;
            return false;
        }
    }
}
