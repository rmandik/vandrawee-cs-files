﻿using Assets.Scripts.vandrawee.LegScripts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Assets.Scripts.vandrawee.ComponentScripts
{
    public class BottomComponentWithHigherFrontScript : BottomComponentScript
    {
        public BoxCollider topColliderVsLegsWithoutTop;

        protected override void computeLegsOffsets(LegsScript legs)
        {
            if (legs.HasTopArea())
                base.computeLegsOffsets(legs);
            else
            {
                this.topVsLegsOffset = this.topColliderVsLegsWithoutTop.center.z + this.topColliderVsLegsWithoutTop.size.z / 2;
                this.bottomVsLegsOffset = this.bottomColliderVsLegs.center.z - this.bottomColliderVsLegs.size.z / 2;
            }
        }
    }
}
