﻿using Assets.Scripts.Common;
using Assets.Scripts.Common.Model;
using Assets.Scripts.Common.Utility;
using Assets.Scripts.vandrawee.LegScripts;
using Assets.Scripts.vandrawee.Model;
using Lean.Localization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.EventSystems;

namespace Assets.Scripts.vandrawee.ComponentScripts
{
    public abstract class ComponentScript : PlacedObjectScript, IBeginDragHandler, IDragHandler,
        IComponentWithDimensions
    {
        public const float ALU_SIZE = 0.045f;

        public virtual bool IsMerged { get { return false; } }

        public BoxCollider topColliderVsComponents;

        public BoxCollider bottomColliderVsComponents;

        public BoxCollider topDimension;

        public BoxCollider bottomDimension;

        public BoxCollider frontDrillingDimension;

        public BoxCollider sideDrillingDimension;

        public bool sideCollides = true;

        protected Vector3 dragOffset;

        public LegsScript Legs { get; private set; }

        public ComponentExtensionScript Extension { get; set; }

        protected float topVsComponentsSameLegsOffset;

        protected float bottomVsComponentsSameLegsOffset;

        private float topDimensionOffset;

        private float bottomDimensionOffset;

        private Dictionary<GameObject, uint> collidingObjects = new Dictionary<GameObject, uint>();

        protected override void Start()
        {
            base.Start();
            this.Legs = this.transform.parent.GetComponent<LegsScript>();
            this.computeComponentsOffsets();

            this.topDimensionOffset = this.topDimension.bounds.max.y - this.transform.position.y;
            this.bottomDimensionOffset = this.bottomDimension.bounds.min.y - this.transform.position.y;

            this.Legs.RedrawDimensions();
        }

        public virtual void OnBeginDrag(PointerEventData eventData)
        {
            if (eventData.button != PointerEventData.InputButton.Left)
                return;
            this.dragOffset = this.transform.position - this.getMouseInWorldPosition(eventData.position);
        }

        public virtual void OnDrag(PointerEventData eventData)
        {
            if (eventData.button != PointerEventData.InputButton.Left)
                return;
            Vector3 dragPosition = this.getMouseInWorldPosition(eventData.position) + this.dragOffset;
            LegsScript[] placedLegs = VanDraweeStaticData.car.GetComponentsInChildren<LegsScript>();

            Vector3 newPosition;

            foreach (LegsScript legs in placedLegs.OrderBy(l => Vector3.Distance(l.transform.position, dragPosition)))
            {
                if (legs == this.Legs)
                    break;
                if (!(legs.PlacedObj.Obj as VanDraweeLegs).components
                    .Contains(this.PlacedObj.Obj.unityId))
                    continue;
                if (this.TryPlaceInLegs(legs, float.MaxValue, out newPosition))
                {
                    this.PlacedObj.Parent.Children.Remove(this.PlacedObj);
                    this.PlacedObj.Parent = legs.PlacedObj;
                    this.PlacedObj.Parent.Children.Add(this.PlacedObj);

                    this.transform.parent = legs.transform;
                    this.transform.rotation = legs.transform.rotation;
                    this.transform.position = newPosition;

                    this.Legs.RedrawDimensions();
                    this.Legs = legs;
                    break;
                }
            }

            float y = dragPosition.y;
            // do not move if movement is too small that it can not be properly detected
            if (!CustomMathf.Approximately(y, this.transform.position.y))
            {
                bool movingUp = y - this.transform.position.y > 0;
                y = this.moveInLegs(this.Legs, y, movingUp);
                this.transform.position = new Vector3(this.transform.position.x, y, this.transform.position.z);
            }
            this.Legs.RedrawDimensions();
        }

        public override void prepareForDestroy()
        {
            this.transform.parent = null;
            this.Legs.RedrawDimensions();
        }

        protected virtual void OnTriggerEnter(Collider collider)
        {
            GameObject collidingObject = collider.gameObject;
            PlacedObjectScript collidingObj = collidingObject.GetComponentInParent<PlacedObjectScript>();

            ComponentScript component = collidingObj as ComponentScript;
            if (component != null && this.Legs == component.Legs)
            {
                if (this.topColliderVsComponents.bounds.max.y < component.bottomColliderVsComponents.bounds.min.y ||
                    CustomMathf.Approximately(this.topColliderVsComponents.bounds.max.y, component.bottomColliderVsComponents.bounds.min.y))
                    return;
                if (this.bottomColliderVsComponents.bounds.min.y > component.topColliderVsComponents.bounds.max.y ||
                    CustomMathf.Approximately(this.bottomColliderVsComponents.bounds.min.y, component.topColliderVsComponents.bounds.max.y))
                    return;
            }

            ComponentExtensionScript extension = collidingObj as ComponentExtensionScript;
            if (extension != null && this.Extension == extension)
                return;

            if (this.collidingObjects.ContainsKey(collidingObject))
                this.collidingObjects[collidingObject]++;
            else
            {
                this.collidingObjects.Add(collidingObject, 1);

                if (this.collidingObjects.Count == 1)
                    this.MakeRed();
            }
        }

        protected virtual void OnTriggerExit(Collider collider)
        {
            GameObject collidingObject = collider.gameObject;

            if (this.collidingObjects.ContainsKey(collidingObject))
            {
                this.collidingObjects[collidingObject]--;

                if (this.collidingObjects[collidingObject] == 0)
                {
                    this.collidingObjects.Remove(collidingObject);

                    if (this.collidingObjects.Count == 0)
                        this.UnmakeRed();
                }
            }
        }

        protected virtual void computeComponentsOffsets()
        {
            this.topVsComponentsSameLegsOffset = this.topColliderVsComponents.center.z + this.topColliderVsComponents.size.z / 2;
            this.bottomVsComponentsSameLegsOffset = this.bottomColliderVsComponents.center.z - this.bottomColliderVsComponents.size.z / 2;
        }

        protected Vector3 getMouseInWorldPosition(Vector2 mousePosition)
        {
            Vector3 point = mousePosition;
            point.z = Camera.main.WorldToScreenPoint(this.transform.position).z;

            return Camera.main.ScreenToWorldPoint(point);
        }

        protected PlacedObject createInstance(Vector3 position, Quaternion rotation,
            Transform parent, VanDraweeObject componentInfo)
        {
            GameObject instance = Instantiate(this.gameObject, position, rotation, parent);
            PlacedObject ret = new PlacedObject(instance.GetComponent<PlacedObjectScript>(), componentInfo);
            PlacedObject legsPlacedComponent = parent.GetComponent<LegsScript>().PlacedObj;

            ret.Parent = legsPlacedComponent;
            legsPlacedComponent.Children.Add(ret);
            return ret;
        }

        public abstract bool TryPlaceInLegs(LegsScript legs, float preferredY, out Vector3 position, bool searchDown = true);

        protected abstract float moveInLegs(LegsScript legs, float prefferedY, bool movingUp);

        public virtual PlacedObject TryPlace(LegsScript legs, float preferredY, VanDraweeObject componentInfo)
        {
            Vector3 position;
            if (this.TryPlaceInLegs(legs, preferredY, out position))
                return this.createInstance(position, legs.transform.rotation, legs.transform, componentInfo);

            throw new PlacementException(LeanLocalization.GetTranslationText(
                "NOT_ENOUGH_SPACE_TO_PLACE_COMPONENT_ERROR"));
        }

        public float GetVsComponentsSameLegsTopY()
        {
            return this.topColliderVsComponents.bounds.max.y;
        }

        public float GetVsComponentsSameLegsBottomY()
        {
            if (this.Extension == null)
                return this.bottomColliderVsComponents.bounds.min.y;
            else
                return this.Extension.BottomVsComponentsSameLegsOffset + this.transform.position.y;
        }

        public float GetTopDimension()
        {
            return this.topDimensionOffset + this.transform.position.y;
        }

        public float GetBottomDimension()
        {
            return this.bottomDimensionOffset + this.transform.position.y;
        }

        public virtual bool ExportDrillingDimensions()
        {
            return true;
        }
    }
}
