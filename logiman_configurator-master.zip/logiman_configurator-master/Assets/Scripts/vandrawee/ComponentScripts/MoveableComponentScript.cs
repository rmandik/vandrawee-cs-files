﻿using Assets.Scripts.Common.Model;
using Assets.Scripts.Common.Utility;
using Assets.Scripts.vandrawee.LegScripts;
using Assets.Scripts.vandrawee.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.EventSystems;

namespace Assets.Scripts.vandrawee.ComponentScripts
{
    public abstract class MoveableComponentScript : ComponentScript
    {
        public MoveableComponentScript leftComponent;

        public MoveableComponentScript rightComponent;

        public override bool IsMerged
        {
            get
            {
                return this.leftComponent != null || this.rightComponent != null;
            }
        }

        public BoxCollider topColliderVsLegs;

        public BoxCollider bottomColliderVsLegs;

        public BoxCollider leftAluCollider;

        public BoxCollider rightAluCollider;

        public BoxCollider leftBoxCollider;

        public BoxCollider rightBoxCollider;

        public Renderer leftAluRenderer;

        public Renderer rightAluRenderer;

        public Renderer leftBoxRenderer;

        public Renderer rightBoxRenderer;

        public bool sideAluBlocksBox = true;

        protected float topVsLegsOffset;

        protected float bottomVsLegsOffset;

        protected float topVsComponentsLeftSideInclBoxOffset;

        protected float topVsComponentsLeftSideExclBoxOffset;

        protected float bottomVsComponentsLeftSideLegsOffset;

        protected float topVsComponentsRightSideInclBoxOffset;

        protected float topVsComponentsRightSideExclBoxOffset;

        protected float bottomVsComponentsRightSideLegsOffset;

        protected float aluCenterLeftOffset;

        protected float aluCenterRightOffset;

        // plywood can go 8 mm into ALU
        protected const float ALU_OFFSET = 0.008f;

        protected override void Start()
        {
            base.Start();
            this.computeLegsOffsets(this.Legs);
        }

        public abstract float GetVsLegsMaxY(LegsScript legs);

        public abstract float GetVsLegsMinY(LegsScript legs);

        public float GetVsComponentsLeftSideLegsTopY(MoveableComponentScript other)
        {
            /*
            if (this.leftBoxCollider != null && other.sideAluBlocksBox)
                return this.leftBoxCollider.bounds.max.y - ALU_OFFSET;
            else
            */
                return this.leftAluCollider.bounds.max.y;
        }

        public float GetVsComponentsRightSideLegsTopY(MoveableComponentScript other)
        {
            /*
            if (this.rightBoxCollider != null && other.sideAluBlocksBox)
                return this.rightBoxCollider.bounds.max.y - ALU_OFFSET;
            else
            */
                return this.rightAluCollider.bounds.max.y;
        }

        public float GetVsComponentsSideLegsTopY(MoveableComponentScript other, bool leftSide)
        {
            if (leftSide)
                return this.GetVsComponentsLeftSideLegsTopY(other);
            else
                return this.GetVsComponentsRightSideLegsTopY(other);
        }

        public float GetVsComponentsLeftSideLegsBottomY()
        {
            return this.leftAluCollider.bounds.min.y;
        }

        public float GetVsComponentsRightSideLegsBottomY()
        {
            return this.rightAluCollider.bounds.min.y;
        }

        public float GetVsComponentsSideLegsBottomY(bool leftSide)
        {
            if (leftSide)
                return this.GetVsComponentsLeftSideLegsBottomY();
            else
                return this.GetVsComponentsRightSideLegsBottomY();
        }

        public float GetLeftSideAluCenterY()
        {
            return this.leftAluCollider.bounds.center.y;
        }

        public float GetRightSideAluCenterY()
        {
            return this.rightAluCollider.bounds.center.y;
        }

        public float GetSideAluCenterY(bool leftSide)
        {
            if (leftSide)
                return this.GetLeftSideAluCenterY();
            else
                return this.GetRightSideAluCenterY();
        }

        private float getBottomVsComponentsSameLegsOffset()
        {
            if (this.Extension == null)
                return this.bottomVsComponentsSameLegsOffset;
            else
                return this.Extension.BottomVsComponentsSameLegsOffset;
        }

        private void setDoNotExportFlag(Renderer renderer, bool visible)
        {
            if (renderer == null)
                return;

            DoNotExportFlagScript doNotExportFlag = renderer.GetComponent<DoNotExportFlagScript>();

            if (visible && doNotExportFlag != null)
                Destroy(doNotExportFlag);
            else if (!visible && doNotExportFlag == null)
                renderer.gameObject.AddComponent<DoNotExportFlagScript>();
        }

        public void SetLeftBoxVisibility(bool visible)
        {
            if (this.leftBoxRenderer != null)
            {
                this.leftBoxRenderer.enabled = visible;
                this.setDoNotExportFlag(this.leftBoxRenderer, visible);
            }
        }

        public void SetRightBoxVisibility(bool visible)
        {
            if (this.rightBoxRenderer != null)
            {
                this.rightBoxRenderer.enabled = visible;
                this.setDoNotExportFlag(this.rightBoxRenderer, visible);
            }
        }

        public virtual void SetLeftAluVisibility(bool visible)
        {
            if (this.leftAluRenderer != null)
            {
                this.leftAluRenderer.enabled = visible;
                this.setDoNotExportFlag(this.leftAluRenderer, visible);
            }
        }

        public virtual void SetRightAluVisibility(bool visible)
        {
            if (this.rightAluRenderer != null)
            {
                this.rightAluRenderer.enabled = visible;
                this.setDoNotExportFlag(this.rightAluRenderer, visible);
            }
        }

        private float findPosVsSameLegs(float y, List<ComponentScript> componentsInParent, bool movingUp)
        {
            // assuming componentsInParent are sorted in the correct order
            float thisTopY = this.topVsComponentsSameLegsOffset + y;
            float thisBottomY = this.getBottomVsComponentsSameLegsOffset() + y;

            bool collision = false;
            while (!collision && componentsInParent.Count > 0)
            {
                float otherTopY = componentsInParent[0].GetVsComponentsSameLegsTopY();
                float otherBottomY = componentsInParent[0].GetVsComponentsSameLegsBottomY();

                // hitting other component
                if (thisBottomY < otherTopY &&
                    thisTopY > otherBottomY &&
                    !CustomMathf.Approximately(thisBottomY, otherTopY) &&
                    !CustomMathf.Approximately(thisTopY, otherBottomY))
                    collision = true;
                // remove components that are above (in case of moving up) or below (in case of moving down) target y
                if ((movingUp && (thisTopY < otherBottomY || CustomMathf.Approximately(thisTopY, otherBottomY)))
                    || (!movingUp && (thisBottomY > otherTopY || CustomMathf.Approximately(thisBottomY, otherTopY))))
                    componentsInParent.RemoveAt(0);
                else
                    break;
            }

            if (!collision)
                return y;

            ComponentScript targetComponent = componentsInParent[0];

            if (movingUp)
            {
                // find component below which this component will be placed
                // can not simply place this component below colliding component because that can cause collision
                // of this component with component below colliding component
                for (int j = 1; j < componentsInParent.Count; j++)
                {
                    float bottomYAfterPlacement = this.getBottomVsComponentsSameLegsOffset() - this.topVsComponentsSameLegsOffset
                        + targetComponent.GetVsComponentsSameLegsBottomY();
                    float nextTopY = componentsInParent[j].GetVsComponentsSameLegsTopY();

                    if (bottomYAfterPlacement > nextTopY ||
                        CustomMathf.Approximately(bottomYAfterPlacement, nextTopY))
                        break;
                    targetComponent = componentsInParent[j];
                }

                // snap to the bottom of target component
                y = targetComponent.GetVsComponentsSameLegsBottomY() - this.topVsComponentsSameLegsOffset;
            } // moving down
            else
            {
                // find component above which this component will be placed
                // can not simply place this component above colliding component because that can cause collision
                // of this component with component below colliding component
                for (int j = 1; j < componentsInParent.Count; j++)
                {
                    float topYAfterPlacement = this.topVsComponentsSameLegsOffset - this.getBottomVsComponentsSameLegsOffset()
                        + targetComponent.GetVsComponentsSameLegsTopY();
                    float nextBottomY = componentsInParent[j].GetVsComponentsSameLegsBottomY();

                    if (topYAfterPlacement < nextBottomY ||
                        CustomMathf.Approximately(topYAfterPlacement, nextBottomY))
                        break;
                    targetComponent = componentsInParent[j];
                }

                // snap to the top of target component
                y = targetComponent.GetVsComponentsSameLegsTopY() - this.getBottomVsComponentsSameLegsOffset();
            }
            return y;
        }

        private float findPosVsSideLegs(float y, List<MoveableComponentScript> sideComponents, bool movingUp, bool leftSide)
        {
            float thisTopInclBoxOffset;
            float thisTopExclBoxOffset;
            float thisBottomOffset;
            float thisAluCenterOffset;
            if (leftSide)
            {
                thisTopInclBoxOffset = this.topVsComponentsLeftSideInclBoxOffset;
                thisTopExclBoxOffset = this.topVsComponentsLeftSideExclBoxOffset;
                thisBottomOffset = this.bottomVsComponentsLeftSideLegsOffset;
                thisAluCenterOffset = this.aluCenterLeftOffset;
            }
            else
            {
                thisTopInclBoxOffset = this.topVsComponentsRightSideInclBoxOffset;
                thisTopExclBoxOffset = this.topVsComponentsRightSideExclBoxOffset;
                thisBottomOffset = this.bottomVsComponentsRightSideLegsOffset;
                thisAluCenterOffset = this.aluCenterRightOffset;
            }
            float thisTopInclBoxY = thisTopInclBoxOffset + y;
            float thisTopExclBoxY = thisTopExclBoxOffset + y;
            float thisBottomY = thisBottomOffset + y;
            float thisAluCenterY = thisAluCenterOffset + y;

            bool collision = false;
            while (!collision && sideComponents.Count > 0)
            {
                float thisTopY;
                if (sideComponents[0].sideAluBlocksBox)
                    thisTopY = thisTopInclBoxY;
                else
                    thisTopY = thisTopExclBoxY;

                float otherTopY;
                float otherBottomY;
                float otherAluCenterY;
                if (leftSide)
                {
                    // components are on the left side so we care about the right side of the other component
                    otherTopY = sideComponents[0].GetVsComponentsRightSideLegsTopY(this);
                    otherBottomY = sideComponents[0].GetVsComponentsRightSideLegsBottomY();
                    otherAluCenterY = sideComponents[0].GetRightSideAluCenterY();
                }
                else
                {
                    otherTopY = sideComponents[0].GetVsComponentsLeftSideLegsTopY(this);
                    otherBottomY = sideComponents[0].GetVsComponentsLeftSideLegsBottomY();
                    otherAluCenterY = sideComponents[0].GetLeftSideAluCenterY();
                }

                // hitting other component
                if (thisBottomY < otherTopY &&
                    thisTopY > otherBottomY &&
                    !CustomMathf.Approximately(thisBottomY, otherTopY) &&
                    !CustomMathf.Approximately(thisTopY, otherBottomY) &&
                    !CustomMathf.Approximately(thisAluCenterY, otherAluCenterY))
                    collision = true;
                // remove components that are above (in case of moving up) or below (in case of moving down) target y
                if ((movingUp && (thisTopY < otherBottomY || CustomMathf.Approximately(thisTopY, otherBottomY)))
                    || (!movingUp && (thisBottomY > otherTopY || CustomMathf.Approximately(thisBottomY, otherTopY))))
                    sideComponents.RemoveAt(0);
                else
                    break;
            }

            if (!collision)
                return y;

            MoveableComponentScript targetComponent = sideComponents[0];
            int j = 0;
            float targetAluCenterY = 0;
            bool merged = false;

            if (movingUp)
            {
                // find a component below which this component will be placed or with which this component will be merged
                while (j < sideComponents.Count)
                {
                    targetComponent = sideComponents[j];
                    targetAluCenterY = targetComponent.GetSideAluCenterY(!leftSide);
                    float bottomYAfterPlacement = 0;

                    if (thisAluCenterY > targetAluCenterY || CustomMathf.Approximately(thisAluCenterY, targetAluCenterY))
                    {
                        // we are moving up so in case that this side alu is above the target side alu
                        // it may be possible to merge these two components
                        // compute bottom y after placement just to make sure that this component will not collide with
                        // the component below the target component
                        bottomYAfterPlacement = thisBottomOffset - thisAluCenterOffset + targetAluCenterY;
                        if (j > 0)
                        {
                            // also this component may be higher than the target component
                            // so in case there is a component above the target component it is needed to check
                            // that this component will not collide with the component above the target component after placement
                            float topYAfterPlacement;
                            if (sideComponents[j - 1].sideAluBlocksBox)
                                topYAfterPlacement = thisTopInclBoxOffset - thisAluCenterOffset + targetAluCenterY;
                            else
                                topYAfterPlacement = thisTopExclBoxOffset - thisAluCenterOffset + targetAluCenterY;
                            float prevBottomY = sideComponents[j - 1].GetVsComponentsSideLegsBottomY(!leftSide);

                            if (topYAfterPlacement < prevBottomY || CustomMathf.Approximately(topYAfterPlacement, prevBottomY))
                                merged = true;
                        }
                        else
                            merged = true;
                    }
                    else if (!merged)
                    {
                        // cannot be merged with the target component
                        // simply try to place this component below the target component
                        // there may be another component below the target component
                        // so we need to compute this bottom Y after placement (below the target component)
                        // and check that it does not collide with the component below the target component
                        if (targetComponent.sideAluBlocksBox)
                            bottomYAfterPlacement = thisBottomOffset - thisTopInclBoxOffset
                                + targetComponent.GetVsComponentsSideLegsBottomY(!leftSide);
                        else
                            bottomYAfterPlacement = thisBottomOffset - thisTopExclBoxOffset
                                + targetComponent.GetVsComponentsSideLegsBottomY(!leftSide);
                        merged = false;
                    }

                    // there is not any component below the target component, this component can be placed
                    if (j + 1 == sideComponents.Count)
                        break;

                    // this is a component below the target component
                    float nextTopY = sideComponents[j + 1].GetVsComponentsSideLegsTopY(this, !leftSide);
                    if (bottomYAfterPlacement > nextTopY || CustomMathf.Approximately(bottomYAfterPlacement, nextTopY))
                        break;
                    j++;
                }

                // merge with the target component
                if (merged)
                    y = targetAluCenterY - thisAluCenterOffset;
                else // snap to the bottom of the target component
                    y = targetComponent.GetVsComponentsSideLegsBottomY(!leftSide)
                        - (targetComponent.sideAluBlocksBox ? thisTopInclBoxOffset : thisTopExclBoxOffset);
            }
            else
            {
                // moving down
                // find a component above which this component will be placed or with which this component will be merged
                while (j < sideComponents.Count)
                {
                    targetComponent = sideComponents[j];
                    targetAluCenterY = targetComponent.GetSideAluCenterY(!leftSide);
                    float topInclBoxYAfterPlacement = 0;
                    float topExclBoxYAfterPlacement = 0;

                    if (thisAluCenterY < targetAluCenterY || CustomMathf.Approximately(thisAluCenterY, targetAluCenterY))
                    {
                        // we are moving down so in case that this side alu is below the target side alu
                        // it may be possible to merge these two components
                        // compute top y after placement to make sure that this component will not collide with
                        // the component above the target component
                        topInclBoxYAfterPlacement = thisTopInclBoxOffset - thisAluCenterOffset + targetAluCenterY;
                        topExclBoxYAfterPlacement = thisTopExclBoxOffset - thisAluCenterOffset + targetAluCenterY;

                        if (j > 0)
                        {
                            float bottomYAfterPlacement = thisBottomOffset - thisAluCenterOffset + targetAluCenterY;
                            float prevTopY = sideComponents[j - 1].GetVsComponentsSideLegsTopY(this, !leftSide);

                            if (bottomYAfterPlacement > prevTopY || CustomMathf.Approximately(bottomYAfterPlacement, prevTopY))
                                merged = true;
                        }
                        else
                            merged = true;
                    }
                    else if (!merged)
                    {
                        // cannot be merged with the target component
                        // simply try to place this component above the target component
                        // there may be another component above the target component
                        // so we need to compute this top Y after placement (above the target component)
                        // and check that it does not collide with the component above the target component
                        topInclBoxYAfterPlacement = thisTopInclBoxOffset - thisBottomOffset
                            + targetComponent.GetVsComponentsSideLegsTopY(this, !leftSide);
                        topExclBoxYAfterPlacement = thisTopExclBoxOffset - thisBottomOffset
                            + targetComponent.GetVsComponentsSideLegsTopY(this, !leftSide);

                        merged = false;
                    }

                    // there is not any component above the target component, this component can be placed
                    if (j + 1 == sideComponents.Count)
                        break;

                    // this is a component above the target component
                    float nextBottomY = sideComponents[j + 1].GetVsComponentsSideLegsBottomY(!leftSide);
                    float topYAfterPlacement;
                    if (sideComponents[j + 1].sideAluBlocksBox)
                        topYAfterPlacement = topInclBoxYAfterPlacement;
                    else
                        topYAfterPlacement = topExclBoxYAfterPlacement;

                    if (topYAfterPlacement < nextBottomY || CustomMathf.Approximately(topYAfterPlacement, nextBottomY))
                        break;
                    j++;
                }

                // merge with the target component
                if (merged)
                    y = targetAluCenterY - thisAluCenterOffset;
                else // snap to the top of the target component
                    y = targetComponent.GetVsComponentsSideLegsTopY(this, !leftSide) - thisBottomOffset;
            }
            return y;
        }

        protected override float moveInLegs(LegsScript legs, float prefferedY, bool movingUp)
        {
            float topLimit = this.GetVsLegsMaxY(legs);
            float bottomLimit = this.GetVsLegsMinY(legs);

            if (prefferedY > topLimit)
                prefferedY = topLimit;
            else if (prefferedY < bottomLimit)
                prefferedY = bottomLimit;

            return this.findPosInLegs(prefferedY, legs, movingUp);
        }

        protected virtual float findPosInLegs(float y, LegsScript legs, bool movingUp)
        {
            List<ComponentScript> componentsInParent = new List<ComponentScript>();
            componentsInParent.AddRange(legs.GetComponentsInChildren<ComponentScript>());
            componentsInParent.Remove(this);

            List<MoveableComponentScript> leftComponents = new List<MoveableComponentScript>();
            List<MoveableComponentScript> rightComponents = new List<MoveableComponentScript>();

            if (this.sideCollides)
            {
                if (legs.leftLegs != null)
                {
                    leftComponents.AddRange(legs.leftLegs.GetComponentsInChildren<MoveableComponentScript>()
                        .Where(c => c.sideCollides));
                    leftComponents.Remove(this);
                }
                if (legs.rightLegs != null)
                {
                    rightComponents.AddRange(legs.rightLegs.GetComponentsInChildren<MoveableComponentScript>()
                        .Where(c => c.sideCollides));
                    rightComponents.Remove(this);
                }
            }

            if (movingUp)
            {
                componentsInParent = componentsInParent.OrderByDescending(c => c.bottomColliderVsComponents.bounds.min.y).ToList();
                leftComponents = leftComponents.OrderByDescending(c => c.bottomColliderVsComponents.bounds.min.y).ToList();
                rightComponents = rightComponents.OrderByDescending(c => c.bottomColliderVsComponents.bounds.min.y).ToList();
            }
            else
            {
                componentsInParent = componentsInParent.OrderBy(c => c.bottomColliderVsComponents.bounds.min.y).ToList();
                leftComponents = leftComponents.OrderBy(c => c.bottomColliderVsComponents.bounds.min.y).ToList();
                rightComponents = rightComponents.OrderBy(c => c.bottomColliderVsComponents.bounds.min.y).ToList();
            }

            float prevY;
            do
            {
                prevY = y;
                y = this.findPosVsSameLegs(y, componentsInParent, movingUp);
                if (this.sideCollides)
                {
                    y = this.findPosVsSideLegs(y, leftComponents, movingUp, true);
                    y = this.findPosVsSideLegs(y, rightComponents, movingUp, false);
                }
            } while (y != prevY);

            return y;
        }

        protected virtual void computeLegsOffsets(LegsScript legs)
        {
            this.topVsLegsOffset = this.topColliderVsLegs.center.z + this.topColliderVsLegs.size.z / 2;
            this.bottomVsLegsOffset = this.bottomColliderVsLegs.center.z - this.bottomColliderVsLegs.size.z / 2;
        }

        protected override void computeComponentsOffsets()
        {
            base.computeComponentsOffsets();

            if (this.sideCollides)
            {
                this.topVsComponentsLeftSideExclBoxOffset = this.leftAluCollider.center.z + this.leftAluCollider.size.z / 2;
                this.topVsComponentsRightSideExclBoxOffset = this.rightAluCollider.center.z + this.rightAluCollider.size.z / 2;
                /*
                if (this.leftBoxCollider != null)
                    this.topVsComponentsLeftSideInclBoxOffset = this.leftBoxCollider.center.z + this.leftBoxCollider.size.z / 2 - ALU_OFFSET;
                else
                */
                    this.topVsComponentsLeftSideInclBoxOffset = this.topVsComponentsLeftSideExclBoxOffset;
                /*
                if (this.rightBoxCollider != null)
                    this.topVsComponentsRightSideInclBoxOffset = this.rightBoxCollider.center.z + this.rightBoxCollider.size.z / 2 - ALU_OFFSET;
                else
                */
                    this.topVsComponentsRightSideInclBoxOffset = this.topVsComponentsRightSideExclBoxOffset;
                this.bottomVsComponentsLeftSideLegsOffset = this.leftAluCollider.center.z - this.leftAluCollider.size.z / 2;
                this.bottomVsComponentsRightSideLegsOffset = this.rightAluCollider.center.z - this.rightAluCollider.size.z / 2;
                this.aluCenterLeftOffset = this.leftAluCollider.center.z;
                this.aluCenterRightOffset = this.rightAluCollider.center.z;
            }
        }

        public override bool TryPlaceInLegs(LegsScript legs, float preferredY, out Vector3 position,
            bool searchDown = true)
        {
            // out parameter must be set in both cases
            position = Vector3.zero;

            // as this object is not placed yet it does not have computed offsets
            // they are computed in Start() method
            // compute them now
            this.computeLegsOffsets(legs);
            this.computeComponentsOffsets();

            float thisVsLegsMaxY = this.GetVsLegsMaxY(legs);
            float thisVsLegsMinY = this.GetVsLegsMinY(legs);

            if (preferredY > thisVsLegsMaxY)
                preferredY = thisVsLegsMaxY;
            if (preferredY < thisVsLegsMinY)
                preferredY = thisVsLegsMinY;

            float y = this.findPosInLegs(preferredY, legs, searchDown);

            // found a position
            if ((y > thisVsLegsMinY || CustomMathf.Approximately(y, thisVsLegsMinY)) &&
                (y < thisVsLegsMaxY || CustomMathf.Approximately(y, thisVsLegsMaxY)))
            {
                position = new Vector3(legs.transform.position.x, y, legs.transform.position.z);
                return true;
            }

            return false;
        }

        protected override void OnTriggerEnter(Collider collider)
        {
            GameObject collidingObject = collider.gameObject;

            // object is component
            if (collidingObject.layer == 10)
            {
                MoveableComponentScript otherComponent = collidingObject.GetComponentInParent<MoveableComponentScript>();
                if (otherComponent != null)
                {
                    if (!this.sideCollides || !otherComponent.sideCollides)
                        return;
                    if (this.Legs.leftLegs == otherComponent.Legs)
                    {
                        float thisTopY = this.GetVsComponentsLeftSideLegsTopY(otherComponent);
                        float thisBottomY = this.GetVsComponentsLeftSideLegsBottomY();
                        float thisAluCenterY = this.GetLeftSideAluCenterY();
                        float otherTopY = otherComponent.GetVsComponentsRightSideLegsTopY(this);
                        float otherBottomY = otherComponent.GetVsComponentsRightSideLegsBottomY();
                        float otherAluCenterY = otherComponent.GetRightSideAluCenterY();

                        // if this component is either above or bellow or merged with the other component
                        // do not trigger collision
                        if (thisTopY < otherBottomY || CustomMathf.Approximately(thisTopY, otherBottomY) ||
                            thisBottomY > otherTopY || CustomMathf.Approximately(thisBottomY, otherTopY))
                            return;
                        if (this.sideCollides && otherComponent.sideCollides &&
                            CustomMathf.Approximately(thisAluCenterY, otherAluCenterY))
                        {
                            if (this.leftComponent == null)
                            {
                                this.leftComponent = otherComponent;
                                otherComponent.rightComponent = this;
                                if (this.sideAluBlocksBox)
                                    otherComponent.SetRightAluVisibility(false);

                                if (this.leftBoxCollider != null && otherComponent.rightBoxCollider != null)
                                {
                                    if (this.leftBoxCollider.bounds.max.y > otherComponent.rightBoxCollider.bounds.max.y)
                                        otherComponent.SetRightBoxVisibility(false);
                                    else
                                        this.SetLeftBoxVisibility(false);
                                }
                            }
                            return;
                        }
                    }
                    else if (this.Legs.rightLegs == otherComponent.Legs)
                    {
                        float thisTopY = this.GetVsComponentsRightSideLegsTopY(otherComponent);
                        float thisBottomY = this.GetVsComponentsRightSideLegsBottomY();
                        float thisAluCenterY = this.GetRightSideAluCenterY();
                        float otherTopY = otherComponent.GetVsComponentsLeftSideLegsTopY(this);
                        float otherBottomY = otherComponent.GetVsComponentsLeftSideLegsBottomY();
                        float otherAluCenterY = otherComponent.GetLeftSideAluCenterY();

                        // if this component is either above or bellow or merged with the other component
                        // do not trigger collision
                        if (thisTopY < otherBottomY || CustomMathf.Approximately(thisTopY, otherBottomY) ||
                            thisBottomY > otherTopY || CustomMathf.Approximately(thisBottomY, otherTopY))
                            return;
                        if (this.sideCollides && otherComponent.sideCollides &&
                            CustomMathf.Approximately(thisAluCenterY, otherAluCenterY))
                        {
                            if (this.rightComponent == null)
                            {
                                this.rightComponent = otherComponent;
                                otherComponent.leftComponent = this;
                                if (this.sideAluBlocksBox)
                                    otherComponent.SetLeftAluVisibility(false);

                                if (this.rightBoxCollider != null && otherComponent.leftBoxCollider != null)
                                {
                                    if (this.rightBoxCollider.bounds.max.y > otherComponent.leftBoxCollider.bounds.max.y)
                                        otherComponent.SetLeftBoxVisibility(false);
                                    else
                                        this.SetRightBoxVisibility(false);
                                }
                            }
                            return;
                        }
                    }
                }
            }

            base.OnTriggerEnter(collider);
        }

        protected override void OnTriggerExit(Collider collider)
        {
            GameObject collidingObject = collider.gameObject;
            MoveableComponentScript otherComponent = collidingObject.GetComponentInParent<MoveableComponentScript>();

            if (otherComponent != null)
            {
                if (this.leftComponent == otherComponent)
                {
                    float thisAluCenterY = this.GetLeftSideAluCenterY();
                    float otherAluCenterY = otherComponent.GetRightSideAluCenterY();

                    if (!CustomMathf.Approximately(thisAluCenterY, otherAluCenterY))
                    {
                        otherComponent.SetRightBoxVisibility(true);
                        otherComponent.SetRightAluVisibility(true);
                        this.SetLeftBoxVisibility(true);
                        this.SetLeftAluVisibility(true);
                        this.leftComponent.rightComponent = null;
                        this.leftComponent = null;
                    }
                }
                else if (this.rightComponent == otherComponent)
                {
                    float thisAluCenterY = this.GetRightSideAluCenterY();
                    float otherAluCenterY = otherComponent.GetLeftSideAluCenterY();

                    if (!CustomMathf.Approximately(thisAluCenterY, otherAluCenterY))
                    {
                        otherComponent.SetLeftBoxVisibility(true);
                        otherComponent.SetLeftAluVisibility(true);
                        this.SetRightBoxVisibility(true);
                        this.SetRightAluVisibility(true);
                        this.rightComponent.leftComponent = null;
                        this.rightComponent = null;
                    }
                }
            }
            base.OnTriggerExit(collider);
        }
    }
}
