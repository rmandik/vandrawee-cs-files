﻿using Assets.Scripts.vandrawee.LegScripts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Assets.Scripts.vandrawee.ComponentScripts
{
    public class MultiboxComponentScript : BottomComponentScript
    {
        public override void SetLeftAluVisibility(bool visible)
        {
            // do nothing
        }

        public override void SetRightAluVisibility(bool visible)
        {
            // do nothing
        }

        public override float GetVsLegsMaxY(LegsScript legs)
        {
            return legs.GetBottomOuterMaxY() - this.topVsLegsOffset;
        }

        public override float GetVsLegsMinY(LegsScript legs)
        {
            return legs.GetBottomOuterMinY() - this.bottomVsLegsOffset;
        }
    }
}
