﻿using Assets.Scripts.Common;
using Assets.Scripts.Common.Model;
using Assets.Scripts.Common.Utility;
using Assets.Scripts.vandrawee.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Assets.Scripts.vandrawee.ComponentScripts
{
    public class ComponentExtensionScript : PlacedObjectScript, IComponentWithDimensions
    {
        [SerializeField]
        private BoxCollider bottomColliderVsComponent;

        [SerializeField]
        private Collider topDimension;

        [SerializeField]
        private Collider bottomDimension;

        public ComponentScript Component { get; private set; }

        private float topDimensionOffset;

        private float bottomDimensionOffset;

        public float BottomVsComponentsSameLegsOffset { get; set; }

        private Dictionary<GameObject, uint> collidingObjects = new Dictionary<GameObject, uint>();

        protected override void Start()
        {
            base.Start();
            this.topDimensionOffset = this.topDimension.bounds.max.y - this.transform.position.y;
            this.bottomDimensionOffset = this.bottomDimension.bounds.min.y - this.transform.position.y;
            this.BottomVsComponentsSameLegsOffset = this.bottomColliderVsComponent.bounds.min.y - this.Component.transform.position.y;

            this.Component.Legs.RedrawDimensions();
        }

        public override void prepareForDestroy()
        {
            this.transform.parent = null;
            this.Component.Legs.RedrawDimensions();
        }

        public PlacedObject TryPlace(ComponentScript component, VanDraweeObject componentInfo)
        {
            if (component.Extension != null)
                return null;

            bool collides = false;
            float thisTopY = component.GetVsComponentsSameLegsTopY();
            this.BottomVsComponentsSameLegsOffset = this.bottomColliderVsComponent.center.z
                + this.bottomColliderVsComponent.size.z / 2;
            float thisBottomY = component.transform.position.y + this.BottomVsComponentsSameLegsOffset;

            List<ComponentScript> components = component.Legs
                .GetComponentsInChildren<ComponentScript>().ToList();
            components.Remove(component);

            foreach (ComponentScript placedComponent in components)
            {
                float otherTopY = placedComponent.GetVsComponentsSameLegsTopY();
                float otherBottomY = placedComponent.GetVsComponentsSameLegsBottomY();

                // hitting other component
                if (thisBottomY < otherTopY &&
                    thisTopY > otherBottomY &&
                    !CustomMathf.Approximately(thisBottomY, otherTopY) &&
                    !CustomMathf.Approximately(thisTopY, otherBottomY))
                {
                    collides = true;
                    break;
                }
            }

            if (!collides)
            {
                GameObject instance = Instantiate(this.gameObject, component.transform);
                PlacedObject ret = new PlacedObject(instance.GetComponent<PlacedObjectScript>(), componentInfo);

                ComponentExtensionScript extensionScript =
                    instance.GetComponent<ComponentExtensionScript>();
                extensionScript.Component = component;
                component.Extension = extensionScript;

                ret.Parent = component.PlacedObj;
                component.PlacedObj.Children.Add(ret);
                return ret;
            }
            return null;
        }

        private void OnTriggerEnter(Collider collider)
        {
            GameObject collidingObject = collider.gameObject;
            ComponentScript component = collidingObject.GetComponentInParent<ComponentScript>();

            if (component == this.Component)
                return;

            if (this.collidingObjects.ContainsKey(collidingObject))
                this.collidingObjects[collidingObject]++;
            else
            {
                this.collidingObjects.Add(collidingObject, 1);

                if (this.collidingObjects.Count == 1)
                    this.MakeRed();
            }
        }

        protected virtual void OnTriggerExit(Collider collider)
        {
            GameObject collidingObject = collider.gameObject;

            if (this.collidingObjects.ContainsKey(collidingObject))
            {
                this.collidingObjects[collidingObject]--;

                if (this.collidingObjects[collidingObject] == 0)
                {
                    this.collidingObjects.Remove(collidingObject);

                    if (this.collidingObjects.Count == 0)
                        this.UnmakeRed();
                }
            }
        }

        public float GetTopDimension()
        {
            return this.topDimensionOffset + this.transform.position.y;
        }

        public float GetBottomDimension()
        {
            return this.bottomDimensionOffset + this.transform.position.y;
        }
    }
}
