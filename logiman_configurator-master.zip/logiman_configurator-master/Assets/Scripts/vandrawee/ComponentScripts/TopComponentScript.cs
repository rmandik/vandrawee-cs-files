﻿using Assets.Scripts.Common.Model;
using Assets.Scripts.Common.Utility;
using Assets.Scripts.vandrawee.LegScripts;
using Assets.Scripts.vandrawee.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Assets.Scripts.vandrawee.ComponentScripts
{
    public class TopComponentScript : MoveableComponentScript
    {
        private bool mergedWithLegs = false;

        protected override void Start()
        {
            base.Start();

            if (this.transform.position.y < this.GetVsLegsMinY(this.Legs))
            {
                this.SetLeftAluVisibility(false);
                this.SetRightAluVisibility(false);
                this.mergedWithLegs = true;
            }
        }

        public override void SetLeftAluVisibility(bool visible)
        {
            // do not make visible if still merged with legs
            if (visible && this.mergedWithLegs)
                return;
            base.SetLeftAluVisibility(visible);
        }

        public override void SetRightAluVisibility(bool visible)
        {
            // do not make visible if still merged with legs
            if (visible && this.mergedWithLegs)
                return;
            base.SetRightAluVisibility(visible);
        }

        protected override float moveInLegs(LegsScript legs, float prefferedY, bool movingUp)
        {
            float topLimit = this.GetVsLegsMaxY(legs);
            float bottomLimit = this.GetVsLegsMinY(legs);
            float yAfterMergeWithLegs = legs.leftLeg.GetSplitterAluCenterY() - this.aluCenterLeftOffset;

            if (prefferedY > topLimit)
                prefferedY = topLimit;
            else if (prefferedY < yAfterMergeWithLegs)
                prefferedY = yAfterMergeWithLegs;
            else if (prefferedY < bottomLimit)
                prefferedY = bottomLimit;

            float y = this.findPosInLegs(prefferedY, legs, movingUp);

            if (CustomMathf.Approximately(y, yAfterMergeWithLegs))
            {
                this.SetLeftAluVisibility(false);
                this.SetRightAluVisibility(false);
                this.mergedWithLegs = true;
                return yAfterMergeWithLegs;
            }

            if (prefferedY < bottomLimit)
                prefferedY = bottomLimit;

            y = this.findPosInLegs(prefferedY, legs, movingUp);

            // we know that this component will fit in these legs
            // so that if we have not found any suitable position it should be merged with legs
            if ((y > topLimit && !CustomMathf.Approximately(y, topLimit) ||
                (y < bottomLimit && !CustomMathf.Approximately(y, bottomLimit))))
            {
                this.SetLeftAluVisibility(false);
                this.SetRightAluVisibility(false);
                this.mergedWithLegs = true;
                return yAfterMergeWithLegs;
            }

            if (this.mergedWithLegs)
            {
                // mergedWithLegs must be set first
                this.mergedWithLegs = false;

                this.SetLeftAluVisibility(true);
                this.SetRightAluVisibility(true);
            }
            return y;
        }

        public override bool TryPlaceInLegs(LegsScript legs, float preferredY, out Vector3 position,
            bool searchDown = true)
        {
            // out parameter must be set anyway
            position = Vector3.zero;

            if (!legs.HasTopArea())
            {
                position = Vector3.zero;
                return false;
            }

            // as this object is not placed yet it does not have computed offsets
            // they are computed in Start() method
            // compute them now
            this.computeLegsOffsets(legs);
            this.computeComponentsOffsets();
            float yAfterMergeWithLegs = legs.leftLeg.GetSplitterAluCenterY() - this.aluCenterLeftOffset;

            if (CustomMathf.Approximately(yAfterMergeWithLegs, preferredY))
                if (CustomMathf.Approximately(this.findPosInLegs(yAfterMergeWithLegs, legs, searchDown), yAfterMergeWithLegs))
                {
                    position = new Vector3(legs.transform.position.x, yAfterMergeWithLegs, legs.transform.position.z);
                    return true;
                }

            float thisVsLegsMaxY = this.GetVsLegsMaxY(legs);
            float thisVsLegsMinY = this.GetVsLegsMinY(legs);

            if (preferredY > thisVsLegsMaxY)
                preferredY = thisVsLegsMaxY;
            if (preferredY < thisVsLegsMinY)
                preferredY = thisVsLegsMinY;

            float y = this.findPosInLegs(preferredY, legs, searchDown);

            // found a position
            if ((y > thisVsLegsMinY || CustomMathf.Approximately(y, thisVsLegsMinY)) &&
                (y < thisVsLegsMaxY || CustomMathf.Approximately(y, thisVsLegsMaxY)))
            {
                position = new Vector3(legs.transform.position.x, y, legs.transform.position.z);
                return true;
            }

            // otherwise try to merge with legs
            preferredY = yAfterMergeWithLegs;
            y = this.findPosInLegs(preferredY, legs, searchDown);

            if ((y < thisVsLegsMaxY || CustomMathf.Approximately(y, thisVsLegsMaxY))
                && CustomMathf.Approximately(y, preferredY))
            {
                position = new Vector3(legs.transform.position.x, y, legs.transform.position.z);
                return true;
            }

            return false;
        }

        public override float GetVsLegsMaxY(LegsScript legs)
        {
            return legs.GetTopMaxY() - this.topVsLegsOffset;
        }

        public override float GetVsLegsMinY(LegsScript legs)
        {
            return legs.GetTopMinY() - this.bottomVsLegsOffset;
        }

        public override bool ExportDrillingDimensions()
        {
            return !this.mergedWithLegs;
        }
    }
}
