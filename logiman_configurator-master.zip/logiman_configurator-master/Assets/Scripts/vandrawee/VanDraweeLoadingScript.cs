﻿using Assets.Scripts.Common;
using Assets.Scripts.Common.Utility;
using Assets.Scripts.vandrawee.Model;
using Cysharp.Threading.Tasks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.UI;

namespace Assets.Scripts.vandrawee
{
    public class VanDraweeLoadingScript : LoadingScript
    {
        public GameObject tutorial;

        public Transform plane;

        async UniTaskVoid Awake()
        {
            StaticData.api = this.CreateAPI();

            await this.loadAssets();

            StaticData.components.AddRange(await StaticData.api.GetComponents());
            VanDraweeComponent[] components = StaticData.components.Select(c => c as VanDraweeObject)
                .Where(c => c.IsComponent()).Select(c => c as VanDraweeComponent).ToArray();

            foreach (VanDraweeComponent component in components)
                StaticData.components.AddRange(component.extensions);

            ModelHelperScript modelHelper = GameObject.Find("modelHelper").GetComponent<ModelHelperScript>();
            Transform cameraTarget = this.instantiatePrerequisities();
            modelHelper.origin = cameraTarget;

            if (cameraTarget != null)
                Camera.main.GetComponent<CameraOrbitScript>().FocusOnTarget(cameraTarget.transform, 2.1f);

            // let all scripts attach to the car run Start()
            await UniTask.Yield();

            // not loading from URL
            if (VanDraweeStaticData.model.Length == 0)
            {
                /*
                if (!PlayerPrefs.HasKey("TutorialSkip"))
                    this.tutorial.SetActive(true);
                */
            }
            else
                await modelHelper.LoadModel(VanDraweeStaticData.model);

            this.LoadingScreen.SetActive(false);
        }

        protected override API CreateAPI()
        {
            if (Application.platform == RuntimePlatform.WebGLPlayer)
                return new VanDraweeAPI(JsUtility.GetLocationProtocol() + "//" + JsUtility.GetLocationHostname() + "/api/");
            else if (Application.platform == RuntimePlatform.WindowsEditor)
                return new VanDraweeAPI("https://test.vandrawee.cz/api/");
            return null;
        }

        protected override async UniTask loadAssets()
        {
            // load components
            StaticData.assets.AddRange(await this.loadAssetsFromBundle("vandrawee"));
            // load legs
            StaticData.assets.AddRange(await this.loadAssetsFromBundle(VanDraweeStaticData.legsBundle.ToLower()));
            // load car
            StaticData.assets.AddRange(await this.loadAssetsFromBundle(VanDraweeStaticData.carId.ToLower()));
        }

        protected override Transform instantiatePrerequisities()
        {
            (StaticData.api as VanDraweeAPI).UploadNewVisit().Forget();
            GameObject car = Instantiate(StaticData.assets.First(a => a.name == VanDraweeStaticData.carId)) as GameObject;
            car.transform.position = plane.position + new Vector3(0, 0.3f, 0);
            VanDraweeStaticData.car = car.GetComponent<CarScript>();

            GameObject.Find("carModelText").GetComponent<Text>().text = VanDraweeStaticData.carModelName;

            if (car != null)
                return car.transform;
            else
                return null;
        }
    }
}
