﻿using Assets.Scripts.Common;
using Assets.Scripts.Common.Model;
using Assets.Scripts.vandrawee.Model;
using Cysharp.Threading.Tasks;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using UnityEngine.Networking;

namespace Assets.Scripts.vandrawee
{
    public class VanDraweeAPI : API
    {
        public VanDraweeAPI(string url) : base(url) { }

        public override async UniTask<Common.Model.Object[]> GetComponents()
        {
            List<Common.Model.Object> ret = new List<Common.Model.Object>();

            UnityWebRequest request = UnityWebRequest.Get(this.url + "getComponents.php");
            await request.SendWebRequest();

            if (request.isNetworkError || request.isHttpError)
                throw new Exception(request.error);
            ret.AddRange(JsonConvert.DeserializeObject<VanDraweeComponent[]>(request.downloadHandler.text));

            request = UnityWebRequest.Get(this.url + "getLegs.php?car=" + VanDraweeStaticData.carId);
            await request.SendWebRequest();

            if (request.isNetworkError || request.isHttpError)
                throw new Exception(request.error);
            ret.AddRange(JsonConvert.DeserializeObject<VanDraweeLegs[]>(request.downloadHandler.text));

            return ret.ToArray();
        }

        public override async UniTask<Guid> UploadModel(PlacedObject[] components)
        {
            Dictionary<string, string> postBody = new Dictionary<string, string>();
            postBody["car"] = VanDraweeStaticData.carId;
            postBody["data"] = JsonConvert.SerializeObject(components);

            UnityWebRequest request = UnityWebRequest.Post(this.url + "uploadModel.php", postBody);
            await request.SendWebRequest();

            if (request.isNetworkError || request.isHttpError)
                throw new Exception(request.error);

            string uuid = JsonConvert.DeserializeObject<string>(request.downloadHandler.text);
            return Guid.Parse(uuid);
        }

        public override async UniTask<StoredObject[]> GetModel(Guid uuid)
        {
            UnityWebRequest request = UnityWebRequest.Get(this.url + "getModel.php?uuid=" + uuid.ToString());
            await request.SendWebRequest();

            if (request.isNetworkError || request.isHttpError)
                throw new Exception(request.error);

            StoredModel storedModel = JsonConvert.DeserializeObject<StoredModel>(request.downloadHandler.text);
            VanDraweeStaticData.carId = storedModel.carId;

            return JsonConvert.DeserializeObject<StoredObject[]>(storedModel.data);
        }

        public async UniTask<Manufacturer[]> GetCars()
        {
            UnityWebRequest request = UnityWebRequest.Get(this.url + "getCars.php");
            await request.SendWebRequest();

            if (request.isNetworkError || request.isHttpError)
                throw new Exception(request.error);

            return JsonConvert.DeserializeObject<Manufacturer[]>(request.downloadHandler.text);
        }

        public IEnumerator UploadFBX(string fbxName, string fbxString, string csvString,
            IProgress<float> progress = null)
        {
            List<IMultipartFormSection> formData = new List<IMultipartFormSection>();
            formData.Add(new MultipartFormDataSection("fbxName", fbxName));
            formData.Add(new MultipartFormDataSection("fbxString", fbxString));
            formData.Add(new MultipartFormDataSection("csvString", csvString));

            using (UnityWebRequest uwr = UnityWebRequest.Post(this.url + "uploadFBX.php", formData))
            {
                var request = uwr.SendWebRequest();

                while (!request.isDone)
                {
                    if (progress != null)
                        progress.Report(uwr.uploadProgress);
                    yield return null;
                }

                if (uwr.isNetworkError || uwr.isHttpError)
                    throw new Exception(uwr.error);
            }
        }

        public async UniTask UploadNewVisit()
        {
            var json = JsonUtility.ToJson(new StatisticsData()
            {
                name = "visit",
                count = 1
            });

            UnityWebRequest request = UnityWebRequest.Post(this.url + "SaveNewVisit.php", json);
            byte[] payload = new UTF8Encoding().GetBytes(json);
            request.uploadHandler = new UploadHandlerRaw(payload);
            request.downloadHandler = new DownloadHandlerBuffer();
            request.SetRequestHeader("Content-Type", "application/json");
            await request.SendWebRequest();

            if (request.isNetworkError || request.isHttpError)
                throw new Exception(request.error);
        }

        public async UniTask UploadStatistics(StatisticsData[] data)
        {
            string json = "{\"dataToSend\": [";
            foreach (StatisticsData d in data)
            {
                var dataJson = JsonUtility.ToJson(d);
                json += dataJson + ",";
            }

            json = json.Remove(json.Length - 1);
            json += "]}";

            UnityWebRequest request = UnityWebRequest.Post(this.url + "SaveStatisticsData.php", json);
            byte[] payload = new UTF8Encoding().GetBytes(json);
            request.uploadHandler = new UploadHandlerRaw(payload);
            request.downloadHandler = new DownloadHandlerBuffer();
            request.SetRequestHeader("Content-Type", "application/json");
            await request.SendWebRequest();

            if (request.isNetworkError || request.isHttpError)
                throw new Exception(request.error);
        }
    }
}
