﻿using Assets.Scripts.Common;
using Assets.Scripts.Common.Model;
using Assets.Scripts.vandrawee.ComponentScripts;
using Assets.Scripts.vandrawee.LegScripts;
using Assets.Scripts.vandrawee.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Assets.Scripts.vandrawee
{
    public class PlaceVanDraweeScript : PlaceScript
    {
        public override PlacedObject Place(Common.Model.Object component, IEnumerable<PlacedObject> placedComponents, Transform origin)
        {
            VanDraweeObject vanDraweeComponent = component as VanDraweeObject;
            VanDraweeModelHelperScript modelHelperScript = GameObject.FindObjectOfType<VanDraweeModelHelperScript>();

            return this.GetComponent<ComponentScript>().TryPlace(
                modelHelperScript.selectedLegs.PlacedObjScript as LegsScript, float.MaxValue, component as VanDraweeObject);
        }
    }
}
