﻿using Assets.Scripts.vandrawee.Model;
using Cysharp.Threading.Tasks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Assets.Scripts.vandrawee
{
    public class StatisticsScript : MonoBehaviour
    {
        private float lastTimeSent;

        private Dictionary<string, StatisticsData> dataToSend = new Dictionary<string, StatisticsData>();

        async UniTaskVoid FixedUpdate()
        {
            var seconds = Time.time - (Time.time % 1f);

            // Kazdych 10 sekund posleme data na server
            if (seconds != 0f && lastTimeSent != seconds && seconds % 10f == 0f)
            {
                lastTimeSent = seconds;
                VanDraweeAPI api = StaticData.api as VanDraweeAPI;

                if (api != null && this.dataToSend.Count > 0)
                {
                    try
                    {
                        await api.UploadStatistics(this.dataToSend.Values.ToArray());
                        this.dataToSend.Clear();
                    }
                    catch (Exception ex) { }
                }
            }
        }

        public void AddData(string name, string category)
        {
            if (this.dataToSend.ContainsKey(name))
                this.dataToSend[name].count++;
            else
                this.dataToSend.Add(name, new StatisticsData()
                {
                    type = category,
                    name = name,
                    count = 1
                });
        }
    }
}
