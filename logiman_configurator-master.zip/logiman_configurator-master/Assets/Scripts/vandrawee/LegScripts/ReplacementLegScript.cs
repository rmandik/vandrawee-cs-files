﻿using Assets.Scripts.Common.Model;
using Assets.Scripts.vandrawee.ComponentScripts;
using Assets.Scripts.vandrawee.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Assets.Scripts.vandrawee.LegScripts
{
    public abstract class ReplacementLegScript : LegScript
    {
        [SerializeField]
        protected Collider backBottomAluCollider;

        [SerializeField]
        protected Collider backMiddleAluCollider;

        public NormalLegScript replacementOf = null;

        public override float GetBottomOuterMinY()
        {
            return this.backMiddleAluCollider.bounds.min.y;
        }

        public override float GetBottomOuterMaxY()
        {
            return this.backMiddleAluCollider.bounds.max.y;
        }

        public override float GetBottomInnerMinY()
        {
            return this.backMiddleAluCollider.bounds.min.y;
        }

        protected override void exportBackAluDrillingDimensions(StringBuilder sb, uint num,
            List<ComponentScript> components)
        {
            this.exportAluDrillingDimensions(sb, num, components, this.backBottomAluCollider);
            this.exportAluDrillingDimensions(sb, num, components, this.backMiddleAluCollider);
        }

        public override void SetAsCommonLeg(LegScript otherLeg)
        {
            base.SetAsCommonLeg(otherLeg);

            this.legs.AddRange(otherLeg.legs);
            this.replacementOf.legs.AddRange(otherLeg.legs);
        }

        protected override void OnTriggerEnter(Collider collider)
        {
            GameObject collidingObject = collider.gameObject;

            // do not trigger collision with this childs or with replacement leg
            if (this.beingDestroyed || collidingObject.transform.IsChildOf(this.transform))
                return;

            VanDraweeModelHelperScript modelHelperScript =
                GameObject.Find("modelHelper").GetComponent<VanDraweeModelHelperScript>();

            // collision with legs
            if (collidingObject.layer == 9)
            {
                LegScript collidingLeg = collidingObject.GetComponentInParent<LegScript>();
                if (collidingLeg == null)
                    base.OnTriggerEnter(collider);

                if (collidingLeg.legs.Intersect(this.legs).Count() == 0)
                {
                    collidingLeg.SetAsCommonLeg(this);
                    this.prepareForDestroy();
                    this.replacementOf.prepareForDestroy();
                    Destroy(this.gameObject);
                    Destroy(this.replacementOf.gameObject);
                    modelHelperScript.SubstractFromPrice(this.GetPrice());
                }
            }
            else
                base.OnTriggerEnter(collider);
        }

        public override void removeFromLegs(LegsScript legs)
        {
            base.removeFromLegs(legs);
            this.replacementOf.removeFromLegs(legs);
        }

        public override bool IsBottomLimitingPlywood()
        {
            return false;
        }
    }
}
