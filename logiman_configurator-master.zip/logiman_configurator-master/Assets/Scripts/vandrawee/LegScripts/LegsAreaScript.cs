﻿using Assets.Scripts.Common.Model;
using Assets.Scripts.vandrawee.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Assets.Scripts.vandrawee.LegScripts
{
    public class LegsAreaScript : MonoBehaviour
    {
        private const float RIGHT_SIDE_EXTENSION = 0.2f;

        public float length;

        public bool areaOnLeft { get; private set; }

        // legs placed in this area from left to right
        private List<LegsScript> legs = new List<LegsScript>();

        public ReadOnlyCollection<LegsScript> Legs { get { return this.legs.AsReadOnly(); } }

        private Bounds bounds;

        void Start()
        {
            this.bounds = this.GetComponent<BoxCollider>().bounds;
            this.areaOnLeft = this.bounds.center.x < 0;

            if (!this.areaOnLeft)
            {
                this.bounds.Expand(new Vector3(0, 0, RIGHT_SIDE_EXTENSION ));
                this.bounds.center = new Vector3(this.bounds.center.x, this.bounds.center.y,
                    this.bounds.center.z + RIGHT_SIDE_EXTENSION / 2);
            }
            this.length = this.bounds.size.z;
        }

        public void DragLegs(float deltaZ)
        {
            foreach (LegsScript l in this.legs)
            {
                float length = (l.PlacedObj.Obj as VanDraweeLegs).size / 1000f;
                if (l.transform.position.z + deltaZ + length / 2 > this.bounds.max.z)
                    deltaZ = this.bounds.max.z - l.transform.position.z - length / 2;
                else if (l.transform.position.z + deltaZ - length / 2 < this.bounds.min.z)
                    deltaZ = this.bounds.min.z - l.transform.position.z + length / 2;
            }

            Vector3 movement = new Vector3(0, 0, deltaZ);

            foreach (LegsScript l in legs)
                l.transform.position += movement;
        }

        public PlacedObject TryPlace(LegsScript legs, float prefferedZ, VanDraweeLegs legsInfo)
        {
            float legsLength = legsInfo.size / 1000f;

            // legs do not fit in this area
            if (legsLength > this.length && !Mathf.Approximately(legsLength, this.length))
                return null;

            float maxZ = this.bounds.max.z - legsLength / 2;
            float minZ = this.bounds.min.z + legsLength / 2;

            if (prefferedZ > maxZ)
                prefferedZ = maxZ;
            else if (prefferedZ < minZ)
                prefferedZ = minZ;

            float theseLegsHigherZ = prefferedZ + legsLength / 2;
            float theseLegsLowerZ = prefferedZ - legsLength / 2;

            foreach (LegsScript l in this.Legs.OrderByDescending(l => l.transform.position.z))
            {
                float otherLegsHigherZ = l.transform.position.z + l.Length / 2;
                float otherLegsLowerZ = l.transform.position.z - l.Length / 2;
                if (theseLegsLowerZ < otherLegsHigherZ - LegsScript.ALU_SIZE &&
                    theseLegsHigherZ > otherLegsLowerZ + LegsScript.ALU_SIZE &&
                    !Mathf.Approximately(theseLegsLowerZ, otherLegsHigherZ - LegsScript.ALU_SIZE) &&
                    !Mathf.Approximately(theseLegsHigherZ, otherLegsLowerZ - LegsScript.ALU_SIZE))
                {
                    // collision, move these legs towards lower z
                    prefferedZ = l.transform.position.z - l.Length / 2 - legsLength / 2
                        + LegsScript.ALU_SIZE;
                    theseLegsHigherZ = prefferedZ + legsLength / 2;
                    theseLegsLowerZ = prefferedZ - legsLength / 2;
                }
            }

            if ((prefferedZ < minZ && !Mathf.Approximately(prefferedZ, minZ)) ||
                (prefferedZ > maxZ && !Mathf.Approximately(prefferedZ, maxZ)))
                return null;

            float legsXOffset = legs.computeDepth() / 2 + this.bounds.size.x / 2 + LegsScript.DEPTH_OFFSET;
            Quaternion rotation = this.transform.rotation;

            if (!this.areaOnLeft)
            {
                legsXOffset *= -1;
                rotation *= Quaternion.Euler(0, 0, 180);
            }

            Vector3 position = new Vector3(
                this.bounds.center.x + legsXOffset,
                VanDraweeStaticData.car.transform.position.y + LegsScript.Y_OFFSET,
                prefferedZ);

            PlacedObject ret = legs.createInstance(position, rotation, this.transform, legsInfo);
            this.legs.Add(ret.PlacedObjScript as LegsScript);
            return ret;
        }

        public PlacedObject TryPlaceNextTo(LegsScript target, LegsScript nextTo, Transform car, VanDraweeLegs legsInfo)
        {
            Vector3 position;
            Quaternion rotation;
            bool positionFound;
            PlacedObject ret = null;

            if (!nextTo.IsMergedOnLeft())
            {
                if (this.areaOnLeft)
                    positionFound = this.tryPlaceNextToLowerZ(target, nextTo, car, legsInfo,
                        out position, out rotation);
                else
                    positionFound = this.tryPlaceNextToHigherZ(target, nextTo, car, legsInfo,
                        out position, out rotation);

                if (positionFound)
                {
                    ret = target.createInstance(position, rotation, this.transform, legsInfo);
                    int index = this.legs.IndexOf(nextTo);
                    this.legs.Insert(index, ret.PlacedObjScript as LegsScript);
                }
            }

            if (ret == null && !nextTo.IsMergedOnRight())
            {
                if (this.areaOnLeft)
                    positionFound = this.tryPlaceNextToHigherZ(target, nextTo, car, legsInfo,
                        out position, out rotation);
                else
                    positionFound = this.tryPlaceNextToLowerZ(target, nextTo, car, legsInfo,
                        out position, out rotation);

                if (positionFound)
                {
                    ret = target.createInstance(position, rotation, this.transform, legsInfo);
                    int index = this.legs.IndexOf(nextTo);
                    this.legs.Insert(index + 1, ret.PlacedObjScript as LegsScript);
                }
            }

            return ret;
        }

        public void MoveLegsNextToLeft(LegsScript target)
        {
            List<LegsScript> legsOnLeft = new List<LegsScript>();

            LegsScript l = target;
            while (l.leftLegs != null)
            {
                legsOnLeft.Add(l.leftLegs);
                l = l.leftLegs;
            }

            Vector3 position;
            Quaternion dummyRotation;
            CarScript car = VanDraweeStaticData.car;

            if (this.areaOnLeft)
                this.tryPlaceNextToLowerZ(target.leftLegs, target, car.transform,
                    target.leftLegs.PlacedObj.Obj as VanDraweeLegs, out position, out dummyRotation);
            else
                this.tryPlaceNextToHigherZ(target.leftLegs, target, car.transform,
                    target.leftLegs.PlacedObj.Obj as VanDraweeLegs, out position, out dummyRotation);
            float deltaZ = position.z - target.leftLegs.transform.position.z;

            foreach (LegsScript legs in legsOnLeft)
                legs.transform.position = new Vector3(legs.transform.position.x,
                    legs.transform.position.y, legs.transform.position.z + deltaZ);
        }

        public void MoveLegsNextToRight(LegsScript target)
        {
            List<LegsScript> legsOnRight = new List<LegsScript>();

            LegsScript l = target;
            while (l.rightLegs != null)
            {
                legsOnRight.Add(l.rightLegs);
                l = l.rightLegs;
            }

            Vector3 position;
            Quaternion dummyRotation;

            if (this.areaOnLeft)
                this.tryPlaceNextToLowerZ(target.leftLegs, target, null,
                    target.leftLegs.PlacedObj.Obj as VanDraweeLegs, out position, out dummyRotation);
            else
                this.tryPlaceNextToHigherZ(target.leftLegs, target, null,
                    target.leftLegs.PlacedObj.Obj as VanDraweeLegs, out position, out dummyRotation);
            float deltaZ = position.z - target.leftLegs.transform.position.z;

            foreach (LegsScript legs in legsOnRight)
                legs.transform.position = new Vector3(legs.transform.position.x,
                    legs.transform.position.y, legs.transform.position.z + deltaZ);
        }

        public void RemoveLegs(LegsScript legs)
        {
            this.legs.Remove(legs);
        }

        private bool tryPlaceNextToLowerZ(LegsScript target, LegsScript nextTo, Transform car,
            VanDraweeLegs legsInfo, out Vector3 position, out Quaternion rotation)
        {
            float legsXOffset = target.computeDepth() / 2 + this.bounds.size.x / 2 + LegsScript.DEPTH_OFFSET;
            rotation = this.transform.rotation;

            if (!this.areaOnLeft)
            {
                legsXOffset *= -1;
                rotation *= Quaternion.Euler(0, 0, 180);
            }

            float targetLength = legsInfo.size / 1000f;
            float nextToLength = nextTo.Length;

            position = new Vector3(
                this.bounds.center.x + legsXOffset,
                car.transform.position.y + LegsScript.Y_OFFSET,
                nextTo.transform.position.z - nextToLength / 2 - targetLength / 2 + LegsScript.ALU_SIZE);

            if (position.z - targetLength / 2 > this.bounds.min.z ||
                Mathf.Approximately(position.z - targetLength / 2, this.bounds.min.z))
                return true;
            return false;
        }

        private bool tryPlaceNextToHigherZ(LegsScript target, LegsScript nextTo, Transform car,
            VanDraweeLegs legsInfo, out Vector3 position, out Quaternion rotation)
        {
            float legsXOffset = target.computeDepth() / 2 + this.bounds.size.x / 2 + LegsScript.DEPTH_OFFSET;
            rotation = this.transform.rotation;

            if (!this.areaOnLeft)
            {
                legsXOffset *= -1;
                rotation *= Quaternion.Euler(0, 0, 180);
            }

            float targetLength = legsInfo.size / 1000f;
            float nextToLength = nextTo.Length;

            position = new Vector3(
                this.bounds.center.x + legsXOffset,
                car.transform.position.y + LegsScript.Y_OFFSET,
                nextTo.transform.position.z + nextToLength / 2 + targetLength / 2 - LegsScript.ALU_SIZE);

            if (position.z + targetLength / 2 < this.bounds.max.z ||
                Mathf.Approximately(position.z + targetLength / 2, this.bounds.max.z))
                return true;
            return false;
        }
    }
}
