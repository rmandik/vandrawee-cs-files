﻿using Assets.Scripts.Common;
using Assets.Scripts.Common.Model;
using Assets.Scripts.Common.Utility;
using Assets.Scripts.vandrawee.ComponentScripts;
using Assets.Scripts.vandrawee.Model;
using Lean.Localization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Assets.Scripts.vandrawee.LegScripts
{
    public class LegsScript : PlacedObjectScript, IBeginDragHandler, IDragHandler
    {
        public LegScript leftLeg;

        public LegScript rightLeg;

        public LegsScript leftLegs;

        public LegsScript rightLegs;

        public float Length
        {
            get
            {
                return (this.PlacedObj.Obj as VanDraweeLegs).size / 1000f;
            }
        }

        public LegsAreaScript LegsArea { get; private set; } = null;

        private GameObject dimensions;

        private GameObject hoverBox;

        private GameObject closeLegs;

        public const float DEPTH_OFFSET = 0.05f;

        public const float Y_OFFSET = 0.04f;

        public const float ALU_SIZE = 0.045f;

        private Vector3 dragOffset;

        public override void prepareForDestroy()
        {
            VanDraweeModelHelperScript modelHelperScript =
                GameObject.Find("modelHelper").GetComponent<VanDraweeModelHelperScript>();

            this.LegsArea.RemoveLegs(this);

            bool leftShared = this.leftLeg.IsShared();
            bool rightShared = this.rightLeg.IsShared();

            if (leftShared)
            {
                this.leftLegs.rightLegs = this.rightLegs;
                this.leftLeg.removeFromLegs(this);
                modelHelperScript.AddToPrice(this.leftLeg.GetPrice());
            }
            else
            {
                this.leftLeg.prepareForDestroy();
                if (this.leftLeg is ReplacementLegScript)
                    (this.leftLeg as ReplacementLegScript).replacementOf.prepareForDestroy();
            }
            if (rightShared)
            {
                this.rightLegs.leftLegs = this.leftLegs;
                this.rightLeg.removeFromLegs(this);
                modelHelperScript.AddToPrice(this.rightLeg.GetPrice());
            }
            else
            {
                this.rightLeg.prepareForDestroy();
                if (this.rightLeg is ReplacementLegScript)
                    (this.rightLeg as ReplacementLegScript).replacementOf.prepareForDestroy();
            }
            if (leftShared && rightShared)
            {
                // move legs to fill space between legs on the left and on the right of this
                this.LegsArea.MoveLegsNextToLeft(this.rightLegs);
            }
        }

        public override Tuple<decimal, decimal> GetPrice()
        {
            Tuple<decimal, decimal> leftPrice = this.leftLeg.GetPrice();
            Tuple<decimal, decimal> rightPrice = this.rightLeg.GetPrice();

            return new Tuple<decimal, decimal>(leftPrice.Item1 + rightPrice.Item1, leftPrice.Item2 + rightPrice.Item2);
        }

        private Vector3 getMouseInWorldPosition(Vector2 mousePosition)
        {
            Vector3 point = mousePosition;
            point.z = Camera.main.WorldToScreenPoint(this.transform.position).z;

            return Camera.main.ScreenToWorldPoint(point);
        }

        public void OnBeginDrag(PointerEventData eventData)
        {
            if (eventData.button != PointerEventData.InputButton.Left)
                return;
            this.dragOffset = this.transform.position - this.getMouseInWorldPosition(eventData.position);
        }

        public void OnDrag(PointerEventData eventData)
        {
            if (eventData.button != PointerEventData.InputButton.Left)
                return;

            float deltaZ = this.getMouseInWorldPosition(eventData.position).z + this.dragOffset.z - this.transform.position.z;
            this.LegsArea.DragLegs(deltaZ);
        }

        protected override void Start()
        {
            this.LegsArea = this.GetComponentInParent<LegsAreaScript>();

            Bounds boundingBox = GameObjectUtility.GetRenderersBoundingBox(this.gameObject);

            this.hoverBox = Instantiate(Resources.Load("LegsBox")) as GameObject;
            this.hoverBox.transform.parent = this.transform;
            this.hoverBox.transform.position = boundingBox.center;
            this.hoverBox.transform.rotation = this.transform.rotation * Quaternion.Euler(0, -90, -90);
            this.hoverBox.transform.localScale = boundingBox.size + new Vector3(0.001f, 0.001f, 0.001f);
            this.hoverBox.AddComponent<BoxCollider>();

            LegsHoverBoxScript legsHoverBox = this.hoverBox.GetComponent<LegsHoverBoxScript>();
            legsHoverBox.legs = this;
            legsHoverBox.text.transform.position = new Vector3(
                this.hoverBox.transform.position.x + (boundingBox.extents.x + 0.02f) * -this.transform.up.x,
                this.hoverBox.transform.position.y, this.hoverBox.transform.position.z);

            this.dimensions = new GameObject("dimensions");
            this.dimensions.transform.parent = this.transform;
            this.dimensions.transform.rotation = this.transform.rotation;
            this.dimensions.transform.position = boundingBox.center +
                (boundingBox.extents.x + 0.015f) * -this.transform.up;
        }

        public void SelectLegs()
        {
            VanDraweeModelHelperScript modelHelperScript =
                GameObject.Find("modelHelper").GetComponent<VanDraweeModelHelperScript>();
            Bounds boundingBox = GameObjectUtility.GetRenderersBoundingBox(this.gameObject);

            this.closeLegs = Instantiate(Resources.Load("CloseLegsButton")) as GameObject;
            this.closeLegs.transform.parent = this.transform;
            this.closeLegs.transform.rotation = this.transform.rotation * Quaternion.Euler(-90, -90, -90);
            this.closeLegs.transform.position = boundingBox.center + boundingBox.extents.y * this.transform.forward +
                (boundingBox.extents.x + 0.015f) * -this.transform.up;
            this.closeLegs.GetComponentInChildren<Button>().onClick.AddListener(modelHelperScript.ExitComponentsMode);
        }

        public void UnselectLegs()
        {
            Destroy(this.closeLegs);
        }

        public override void MakeRed()
        {
            this.leftLeg.MakeRed();
            this.rightLeg.MakeRed();
        }

        public override void UnmakeRed()
        {
            this.leftLeg.UnmakeRed();
            this.rightLeg.UnmakeRed();
        }

        public float GetTopMaxY()
        {
            float left = this.leftLeg.GetTopMaxY();
            float right = this.rightLeg.GetTopMaxY();
            return left < right ? left : right;
        }

        public float GetTopMinY()
        {
            float left = this.leftLeg.GetTopMinY();
            float right = this.rightLeg.GetTopMinY();
            return left > right ? left : right;
        }

        public float GetBottomInnerMaxY()
        {
            float left = this.leftLeg.GetBottomInnerMaxY();
            float right = this.rightLeg.GetBottomInnerMaxY();
            return left < right ? left : right;
        }

        public float GetBottomInnerMinY()
        {
            float left = this.leftLeg.GetBottomInnerMinY();
            float right = this.rightLeg.GetBottomInnerMinY();
            return left > right ? left : right;
        }

        public float GetBottomOuterMaxY()
        {
            float left = this.leftLeg.GetBottomOuterMaxY();
            float right = this.rightLeg.GetBottomOuterMaxY();
            return left < right ? left : right;
        }

        public float GetBottomOuterMinY()
        {
            float left = this.leftLeg.GetBottomOuterMinY();
            float right = this.rightLeg.GetBottomOuterMinY();
            return left > right ? left : right;
        }

        public float GetFloorY()
        {
            float left = this.leftLeg.GetFloorY();
            float right = this.rightLeg.GetFloorY();
            return left > right ? left : right;
        }

        public bool HasTopArea()
        {
            return this.leftLeg.HasTopArea() &&
                this.rightLeg.HasTopArea();
        }

        public bool IsMergedOnRight()
        {
            return this.rightLeg.IsShared();
        }

        public bool IsMergedOnLeft()
        {
            return this.leftLeg.IsShared();
        }

        public override void Highlight()
        {
            base.Highlight();
            // left or right leg does not need to be child of this GameObject
            this.leftLeg.Highlight();
            this.rightLeg.Highlight();
        }

        public override void Unhighlight()
        {
            base.Unhighlight();
            this.leftLeg.Unhighlight();
            this.rightLeg.Unhighlight();
        }

        public override void MakeSemitransparent()
        {
            base.MakeSemitransparent();
            this.leftLeg.MakeSemitransparent();
            this.rightLeg.MakeSemitransparent();

            foreach (ComponentScript component in this.GetComponentsInChildren<ComponentScript>())
                component.MakeSemitransparent();
        }

        public override void UnmakeSemitransparent()
        {
            base.UnmakeSemitransparent();
            this.leftLeg.UnmakeSemitransparent();
            this.rightLeg.UnmakeSemitransparent();

            foreach (ComponentScript component in this.GetComponentsInChildren<ComponentScript>())
                component.UnmakeSemitransparent();
        }

        public bool IsBottomLimitingPlywood()
        {
            return this.leftLeg.IsBottomLimitingPlywood() &&
                this.rightLeg.IsBottomLimitingPlywood();
        }

        public float GetMinZ()
        {
            BoxCollider[] colliders = this.GetComponentsInChildren<BoxCollider>();
            return colliders.Min(c => c.bounds.min.z);
        }

        public float GetMaxZ()
        {
            BoxCollider[] colliders = this.GetComponentsInChildren<BoxCollider>();
            return colliders.Max(c => c.bounds.max.z);
        }

        public PlacedObject createInstance(Vector3 position, Quaternion rotation, Transform parent, VanDraweeLegs info)
        {
            GameObject instance = Instantiate(this.gameObject, position, rotation, parent);
            LegsScript legs = instance.GetComponent<LegsScript>();

            legs.leftLeg.PlacedObj = new PlacedObject(legs.leftLeg, info.singleLeg);
            legs.rightLeg.PlacedObj = new PlacedObject(legs.rightLeg, info.singleLeg);
            PlacedObject ret = new PlacedObject(legs, info);
            return ret;
        }

        public ComponentScript[] GetComponents()
        {
            return this.GetComponentsInChildren<ComponentScript>();
        }

        public float computeDepth()
        {
            BoxCollider[] colliders = this.GetComponentsInChildren<BoxCollider>();
            float frontOffset = colliders.Where(c => c.name.Contains("45x"))
                .Max(c => c.center.y + c.size.y / 2 + c.transform.position.y);
            float backOffset = colliders.Where(c => c.name.Contains("45x"))
                .Min(c => c.center.y - c.size.y / 2 + c.transform.position.y);
            return Mathf.Abs(frontOffset - backOffset);
        }

        public void RedrawDimensions()
        {
            // remove old line renderers
            foreach (Transform line in this.dimensions.transform)
                Destroy(line.gameObject);

            IComponentWithDimensions[] components = this.GetComponentsInChildren<PlacedObjectScript>()
                .OfType<IComponentWithDimensions>().OrderBy(c => c.GetBottomDimension()).ToArray();

            // draw dimension between floor and bottom most component
            if (components.Length > 0)
            {
                float bottomMostDimension = components[0].GetBottomDimension();
                float floor = this.GetFloorY();

                // bottom most component is not on the floor
                if (!CustomMathf.Approximately(bottomMostDimension, floor))
                {
                    Vector3 start = Vector3.zero;
                    start.y = floor;

                    Vector3 end = Vector3.zero;
                    end.y = bottomMostDimension;

                    this.drawDimension(start, end);
                }
            }

            for (int i = 0; i < components.Length - 1; i++)
            {
                Vector3 start = Vector3.zero;
                start.y = components[i].GetTopDimension();

                Vector3 end = Vector3.zero;
                end.y = components[i + 1].GetBottomDimension();

                this.drawDimension(start, end);
            }
        }

        private void drawDimension(Vector3 start, Vector3 end)
        {
            // do not show 0 mm dimensions
            if (Mathf.RoundToInt((start.y - end.y) * 1000) == 0)
                return;

            GameObject line = new GameObject("dimension");
            line.AddComponent<DoNotExportFlagScript>();
            line.tag = "doNotHighlight";
            line.transform.position = this.dimensions.transform.position;
            line.transform.rotation = this.dimensions.transform.rotation * Quaternion.Euler(-90, 180, 0);
            line.transform.parent = this.dimensions.transform;

            start.y -= line.transform.position.y;
            end.y -= line.transform.position.y;

            LineRenderer lineRenderer = line.AddComponent<LineRenderer>();
            lineRenderer.material = new Material(Shader.Find("Sprites/Default"));
            lineRenderer.material.color = Color.red;
            lineRenderer.widthMultiplier = 0.01f;
            lineRenderer.useWorldSpace = false;

            lineRenderer.alignment = LineAlignment.TransformZ;
            lineRenderer.SetPosition(0, start);
            lineRenderer.SetPosition(1, end);

            GameObject text = Instantiate(Resources.Load("DimensionText")) as GameObject;
            text.tag = "doNotHighlight";
            text.transform.parent = line.transform;
            text.transform.position =
                new Vector3(line.transform.position.x,
                (start.y + end.y) / 2 + line.transform.position.y,
                line.transform.position.z + 0.08f);
            text.transform.rotation = line.transform.rotation;

            TMPro.TextMeshPro textMesh = text.GetComponent<TMPro.TextMeshPro>();
            textMesh.text = Mathf.RoundToInt(Mathf.Abs(start.y - end.y) * 1000).ToString() + " mm";
        }
    }
}
