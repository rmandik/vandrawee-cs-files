﻿using Assets.Scripts.Common;
using Assets.Scripts.Common.Model;
using Assets.Scripts.vandrawee.ComponentScripts;
using Assets.Scripts.vandrawee.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.EventSystems;

namespace Assets.Scripts.vandrawee.LegScripts
{
    public abstract class LegScript : PlacedObjectScript
    {
        [SerializeField]
        protected Collider bottomBoxCollider;

        [SerializeField]
        protected Collider frontAluCollider;

        [SerializeField]
        protected Collider bottomHorizontalAluCollider;

        [SerializeField]
        protected Collider topHorizontalAluCollider;

        // this leg can be part of one or two legs (in case of common leg)
        public List<LegsScript> legs = new List<LegsScript>();

        public bool beingDestroyed { get; protected set; } = false;

        private Dictionary<GameObject, uint> collidingObjects = new Dictionary<GameObject, uint>();

        public override void prepareForDestroy()
        {
            this.beingDestroyed = true;
        }

        protected virtual void OnTriggerEnter(Collider collider)
        {
            GameObject collidingObject = collider.gameObject;

            // do not trigger collision with this children
            if (this.beingDestroyed || collidingObject.transform.IsChildOf(this.transform))
                return;

            if (this.collidingObjects.ContainsKey(collidingObject))
            {
                this.collidingObjects[collidingObject]++;
                return;
            }
            else
                this.collidingObjects.Add(collidingObject, 1);

            if (this.collidingObjects.Count != 1)
                return;

            this.MakeRed();
        }

        // other leg is either normal leg (if replacement leg is not instantiated)
        // or replacement leg
        // other leg will be destroyed
        public virtual void SetAsCommonLeg(LegScript otherLeg)
        {
            LegsScript thisLegs = this.legs.First();
            LegsScript otherLegs = otherLeg.legs.First();

            if (otherLegs.leftLeg == otherLeg)
            {
                otherLegs.leftLeg = this;
                otherLegs.leftLegs = thisLegs;
                thisLegs.rightLegs = otherLegs;
            }
            else if (otherLegs.rightLeg == otherLeg)
            {
                otherLegs.rightLeg = this;
                otherLegs.rightLegs = thisLegs;
                thisLegs.leftLegs = otherLegs;
            }

            if (otherLeg.IsHighlighted)
                this.Highlight();

        }

        protected virtual void OnTriggerExit(Collider collider)
        {
            GameObject collidingObject = collider.gameObject;

            if (this.collidingObjects.ContainsKey(collidingObject))
            {
                this.collidingObjects[collidingObject]--;

                if (this.collidingObjects[collidingObject] == 0)
                {
                    this.collidingObjects.Remove(collidingObject);

                    if (this.collidingObjects.Count == 0)
                        this.UnmakeRed();
                }
            }
        }

        public bool IsShared()
        {
            return this.legs.Count == 2;
        }

        public virtual void removeFromLegs(LegsScript legs)
        {
            this.legs.Remove(legs);

            if (this.legs.Count > 0)
            {
                if (this.transform.IsChildOf(legs.transform))
                    this.transform.parent = this.legs.First().transform;
            }
        }

        public abstract bool HasTopArea();

        public abstract float GetSplitterAluCenterY();

        public abstract bool IsBottomLimitingPlywood();

        public abstract float GetBottomOuterMaxY();

        public abstract float GetBottomOuterMinY();

        public abstract float GetBottomInnerMinY();

        public virtual float GetFloorY()
        {
            return this.frontAluCollider.bounds.min.y;
        }

        public virtual float GetMinZ()
        {
            BoxCollider[] colliders = this.GetComponentsInChildren<BoxCollider>();
            return colliders.Min(c => c.bounds.min.z);
        }

        public virtual float GetMaxZ()
        {
            BoxCollider[] colliders = this.GetComponentsInChildren<BoxCollider>();
            return colliders.Max(c => c.bounds.max.z);
        }

        public abstract float GetBottomInnerMaxY();

        public abstract float GetTopMaxY();

        public abstract float GetTopMinY();

        protected void exportAluDrillingDimensions(StringBuilder sb, uint num,
            List<ComponentScript> components, Collider alu)
        {
            // assuming components are ordered from the bottom to the top
            float aluMinY = alu.bounds.min.y;
            float aluMaxY = alu.bounds.max.y;
            int aluSize = Mathf.RoundToInt(alu.bounds.size.y * 1000);
            sb.Append(String.Format("{0}.noha_{1}", num, aluSize));

            float bottomHorizontalAluCenterY = this.bottomHorizontalAluCollider.bounds.center.y;
            float topHorizontalAluCenterY = this.topHorizontalAluCollider.bounds.center.y;

            if (bottomHorizontalAluCenterY >= aluMinY &&
                bottomHorizontalAluCenterY <= aluMaxY)
                sb.Append(String.Format("_C{0}", Mathf.FloorToInt((bottomHorizontalAluCenterY - aluMinY) * 1000)));

            List<ComponentScript> frontDrillingComponents = components
                .Where(c => c.frontDrillingDimension != null).ToList();

            foreach (ComponentScript component in frontDrillingComponents)
            {
                float y = component.frontDrillingDimension.bounds.center.y;
                // no need to care about equality as it should not occur
                if (y > aluMinY)
                {
                    if (y < aluMaxY)
                        sb.Append(String.Format("_C{0}", Mathf.FloorToInt((y - aluMinY) * 1000)));
                    else
                        break;
                }
            }

            if (topHorizontalAluCenterY >= aluMinY &&
                topHorizontalAluCenterY <= aluMaxY)
                sb.Append(String.Format("_C{0}", Mathf.FloorToInt((topHorizontalAluCenterY - aluMinY) * 1000)));

            List<ComponentScript> sideDrillingComponents = components
                .Where(c => c.sideDrillingDimension != null).ToList();

            foreach (ComponentScript component in sideDrillingComponents)
            {
                float y = component.sideDrillingDimension.bounds.center.y;
                if (y > aluMinY)
                {
                    if (y < aluMaxY)
                        sb.Append(String.Format("_B{0}", Mathf.FloorToInt((y - aluMinY) * 1000)));
                    else
                        break;
                }
            }
            sb.Append("\n");
        }

        protected abstract void exportBackAluDrillingDimensions(StringBuilder sb, uint num,
            List<ComponentScript> components);

        public void ExportDrillingDimensions(StringBuilder sb, uint num)
        {
            List<ComponentScript> components = new List<ComponentScript>();
            foreach (LegsScript legs in this.legs)
                components.AddRange(legs.GetComponents().Where(c => c.ExportDrillingDimensions()));

            components = components.OrderBy(c => c.transform.position.y).ToList();

            this.exportAluDrillingDimensions(sb, num, components, this.frontAluCollider);
            this.exportBackAluDrillingDimensions(sb, num + 1, components);
        }
    }
}
