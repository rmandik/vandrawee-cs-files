﻿using Assets.Scripts.Common.Model;
using Assets.Scripts.Common.Utility;
using Assets.Scripts.vandrawee.ComponentScripts;
using Assets.Scripts.vandrawee.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Assets.Scripts.vandrawee.LegScripts
{
    public abstract class NormalLegScript : LegScript
    {
        [SerializeField]
        protected Collider backBottomAluCollider;

        public bool replacementInstatiated { get; private set; } = false;

        public ReplacementLegScript replacementLeg = null;

        private Dictionary<GameObject, uint> collidingCarObjects = new Dictionary<GameObject, uint>();

        public override bool IsBottomLimitingPlywood()
        {
            return true;
        }

        public override float GetBottomOuterMinY()
        {
            return this.backBottomAluCollider.bounds.min.y;
        }

        public override float GetBottomOuterMaxY()
        {
            return this.backBottomAluCollider.bounds.max.y;
        }

        public override float GetBottomInnerMinY()
        {
            return this.bottomBoxCollider.bounds.max.y;
        }

        protected override void exportBackAluDrillingDimensions(StringBuilder sb, uint num,
            List<ComponentScript> components)
        {
            this.exportAluDrillingDimensions(sb, num, components, this.backBottomAluCollider);
        }

        public override void SetAsCommonLeg(LegScript otherLeg)
        {
            if (this.replacementInstatiated)
                this.replacementLeg.SetAsCommonLeg(otherLeg);
            else
            {
                base.SetAsCommonLeg(otherLeg);
                this.legs.AddRange(otherLeg.legs);
            }
        }

        protected override void OnTriggerEnter(Collider collider)
        {
            GameObject collidingObject = collider.gameObject;

            // do not trigger collision with this childs or with replacement leg
            if (this.beingDestroyed || collidingObject.transform.IsChildOf(this.transform)
                || (this.replacementLeg != null && collidingObject.transform.IsChildOf(this.replacementLeg.transform)))
                return;

            VanDraweeModelHelperScript modelHelperScript =
                GameObject.Find("modelHelper").GetComponent<VanDraweeModelHelperScript>();

            // collision with legs
            if (collidingObject.layer == 9)
            {
                LegScript collidingLeg = collidingObject.GetComponentInParent<LegScript>();
                if (collidingLeg == null)
                    base.OnTriggerEnter(collider);

                if (collidingLeg.legs.Intersect(this.legs).Count() == 0)
                {
                    if (this.replacementInstatiated)
                    {
                        collidingLeg.SetAsCommonLeg(this.replacementLeg);
                        this.prepareForDestroy();
                        this.replacementLeg.prepareForDestroy();
                        Destroy(this.gameObject);
                        Destroy(this.replacementLeg.gameObject);
                        modelHelperScript.SubstractFromPrice(this.replacementLeg.GetPrice());
                    }
                    else
                    {
                        collidingLeg.SetAsCommonLeg(this);
                        this.prepareForDestroy();
                        Destroy(this.gameObject);
                        modelHelperScript.SubstractFromPrice(this.GetPrice());
                    }
                }
            }
            else if (collidingObject.layer == 8)
            {
                // collision with car
                // replace this leg with replacement leg
                VanDraweeLegs legsComponent = this.legs.First().PlacedObj.Obj as VanDraweeLegs;

                // replacement leg does not exist, highlight collision red
                if (legsComponent.replacementLeg == null)
                    base.OnTriggerEnter(collider);

                GameObject replacementObject = StaticData.assets.FirstOrDefault(
                    a => a.name == legsComponent.replacementLeg.unityId) as GameObject;

                // replacement leg asset does not exist, hightlight collision red
                if (replacementObject == null)
                    base.OnTriggerEnter(collider);

                if (this.collidingCarObjects.ContainsKey(collidingObject))
                {
                    this.collidingCarObjects[collidingObject]++;
                    return;
                }
                else
                    this.collidingCarObjects.Add(collidingObject, 1);

                if (this.collidingCarObjects.Count != 1)
                    return;

                GameObject replacementLeg = Instantiate(replacementObject, this.transform.position,
                    this.transform.rotation, this.transform.parent);

                this.replacementLeg = replacementLeg.GetComponent<ReplacementLegScript>();
                this.replacementLeg.replacementOf = this;
                this.replacementLeg.legs.AddRange(this.legs);
                this.replacementLeg.PlacedObj = new PlacedObject(this.replacementLeg, legsComponent.replacementLeg);
                this.replacementInstatiated = true;

                modelHelperScript.SubstractFromPrice(this.GetPrice());
                modelHelperScript.AddToPrice(this.replacementLeg.GetPrice());

                foreach (LegsScript legs in this.legs)
                {
                    if (legs.leftLeg == this)
                        legs.leftLeg = this.replacementLeg;
                    else
                        legs.rightLeg = this.replacementLeg;

                    // delete components that will not fit into replacement leg
                    ComponentScript[] components = legs.GetComponentsInChildren<ComponentScript>();
                    Vector3 position;

                    foreach (ComponentScript component in components.OrderBy(c => c.transform.position.y))
                    {
                        if (component.TryPlaceInLegs(legs, component.transform.position.y, out position, false))
                            component.transform.position = position;
                        else
                            modelHelperScript.RemoveComponent(component.PlacedObj);
                    }

                    if (legs.IsHighlighted)
                    {
                        this.Unhighlight();
                        this.replacementLeg.Highlight();
                    }

                    legs.RedrawDimensions();
                }

                foreach (Renderer renderer in this.GetComponentsInChildren<Renderer>())
                    renderer.enabled = false;
                foreach (MeshFilter mesh in this.GetComponentsInChildren<MeshFilter>())
                    mesh.gameObject.AddComponent<DoNotExportFlagScript>();
            }
            else
                base.OnTriggerEnter(collider);
        }

        protected override void OnTriggerExit(Collider collider)
        {
            GameObject collidingObject = collider.gameObject;

            if (this.beingDestroyed)
                return;

            // collision with legs
            if (collidingObject.layer == 9)
                base.OnTriggerExit(collider);
            else if (collidingObject.layer == 8)
            {
                if (this.collidingCarObjects.ContainsKey(collidingObject))
                {
                    this.collidingCarObjects[collidingObject]--;

                    if (this.collidingCarObjects[collidingObject] == 0)
                    {
                        this.collidingCarObjects.Remove(collidingObject);

                        if (this.collidingCarObjects.Count == 0)
                        {
                            if (this.replacementLeg != null)
                            {
                                VanDraweeModelHelperScript modelHelperScript =
                                    GameObject.Find("modelHelper").GetComponent<VanDraweeModelHelperScript>();

                                modelHelperScript.SubstractFromPrice(this.replacementLeg.GetPrice());
                                modelHelperScript.AddToPrice(this.GetPrice());

                                foreach (LegsScript legs in this.legs)
                                {
                                    if (legs.leftLeg == this.replacementLeg)
                                        legs.leftLeg = this;
                                    else
                                        legs.rightLeg = this;

                                    if (legs.IsHighlighted)
                                        this.Highlight();
                                }

                                foreach (Renderer renderer in this.GetComponentsInChildren<Renderer>())
                                    renderer.enabled = true;
                                foreach (MeshFilter mesh in this.GetComponentsInChildren<MeshFilter>())
                                    Destroy(mesh.GetComponent<DoNotExportFlagScript>());

                                this.replacementLeg.prepareForDestroy();
                                Destroy(this.replacementLeg.gameObject);
                                this.replacementInstatiated = false;
                                // must leave this.replacementLeg set because it can fire collision even while being destroyed
                            }
                        }
                    }
                }
            }
        }
    }
}
