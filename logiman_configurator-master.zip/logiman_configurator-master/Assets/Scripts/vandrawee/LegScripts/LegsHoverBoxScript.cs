﻿using Assets.Scripts.Common;
using Assets.Scripts.Common.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.EventSystems;

namespace Assets.Scripts.vandrawee.LegScripts
{
    public class LegsHoverBoxScript : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
    {
        public MeshRenderer meshRenderer;

        public Transform text;

        public Renderer textRenderer;

        public LegsScript legs;

        private VanDraweeModelHelperScript modelHelperScript;

        void Start()
        {
            this.modelHelperScript = GameObject.FindObjectOfType<VanDraweeModelHelperScript>();
            this.modelHelperScript.modeChanged += ModelHelperScript_modeChanged;
        }

        private void ModelHelperScript_modeChanged(object sender, EventArgs e)
        {
            if (this.modelHelperScript.mode == ConfiguratorMode.Components)
            {
                this.gameObject.SetActive(false);
                this.meshRenderer.enabled = false;
                this.textRenderer.enabled = false;
            }
            else
                this.gameObject.SetActive(true);
        }

        void OnDestroy()
        {
            this.modelHelperScript.modeChanged -= ModelHelperScript_modeChanged;
        }

        public void OnPointerEnter(PointerEventData eventData)
        {
            if (this.modelHelperScript.mode != ConfiguratorMode.Components)
            {
                this.meshRenderer.enabled = true;
                this.textRenderer.enabled = true;
            }
        }

        public void OnPointerExit(PointerEventData eventData)
        {
            this.meshRenderer.enabled = false;
            this.textRenderer.enabled = false;
        }
    }
}
