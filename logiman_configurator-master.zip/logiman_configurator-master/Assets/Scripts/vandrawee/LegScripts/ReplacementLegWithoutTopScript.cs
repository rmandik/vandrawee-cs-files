﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Assets.Scripts.vandrawee.LegScripts
{
    public class ReplacementLegWithoutTopScript : ReplacementLegScript
    {
        public override bool HasTopArea()
        {
            return false;
        }

        public override float GetBottomInnerMaxY()
        {
            return this.backMiddleAluCollider.bounds.max.y;
        }

        public override float GetTopMaxY()
        {
            throw new NotImplementedException();
        }

        public override float GetTopMinY()
        {
            throw new NotImplementedException();
        }

        public override float GetSplitterAluCenterY()
        {
            throw new NotImplementedException();
        }
    }
}
