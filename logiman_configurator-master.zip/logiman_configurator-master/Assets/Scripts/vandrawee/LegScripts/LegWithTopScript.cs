﻿using Assets.Scripts.vandrawee.ComponentScripts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Assets.Scripts.vandrawee.LegScripts
{
    public class LegWithTopScript : NormalLegScript
    {
        [SerializeField]
        protected Collider backTopAluCollider;

        [SerializeField]
        protected Collider splitterAluCollider;

        public override float GetSplitterAluCenterY()
        {
            return this.splitterAluCollider.bounds.center.y;
        }

        public override bool HasTopArea()
        {
            return true;
        }

        public override float GetBottomInnerMaxY()
        {
            return this.splitterAluCollider.bounds.min.y;
        }

        public override float GetTopMaxY()
        {
            return this.backTopAluCollider.bounds.max.y;
        }

        public override float GetTopMinY()
        {
            return this.splitterAluCollider.bounds.max.y;
        }

        protected override void exportBackAluDrillingDimensions(StringBuilder sb, uint num,
            List<ComponentScript> components)
        {
            base.exportBackAluDrillingDimensions(sb, num, components);
            this.exportAluDrillingDimensions(sb, num, components, this.backTopAluCollider);
        }
    }
}
