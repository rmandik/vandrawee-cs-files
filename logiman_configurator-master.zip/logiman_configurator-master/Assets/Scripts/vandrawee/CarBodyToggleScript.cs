﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Assets.Scripts.vandrawee
{
    public class CarBodyToggleScript : MonoBehaviour
    {
        public void OnToggle(bool set)
        {
            VanDraweeStaticData.car.SetBodyRendererEnabled(!set);
        }
    }
}
