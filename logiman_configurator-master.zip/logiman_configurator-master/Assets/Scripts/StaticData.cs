﻿using Assets.Scripts.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Assets.Scripts
{
    public static class StaticData
    {
        public static API api = null;

        public static List<UnityEngine.Object> assets = new List<UnityEngine.Object>();

        public static List<Common.Model.Object> components = new List<Common.Model.Object>();

        public static Dictionary<string, Texture2D> componentTextures = new Dictionary<string, Texture2D>();
    }
}
