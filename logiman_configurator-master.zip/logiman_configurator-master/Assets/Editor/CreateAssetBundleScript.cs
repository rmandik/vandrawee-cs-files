﻿using UnityEditor;
using UnityEngine;
using System.IO;
using System.Security.Cryptography;
using System;
using System.Text;

public class CreateAssetBundleScript
{
    [MenuItem("Assets/Build AssetBundle")]
    static void BuildAssetBundle()
    {
        string assetBundlesDirectory = "Assets/StreamingAssets";

        if (!Directory.Exists(Application.streamingAssetsPath))
            Directory.CreateDirectory(assetBundlesDirectory);

        BuildPipeline.BuildAssetBundles(assetBundlesDirectory, BuildAssetBundleOptions.ForceRebuildAssetBundle, EditorUserBuildSettings.activeBuildTarget);

        foreach (string assetBundleName in AssetDatabase.GetAllAssetBundleNames())
            encryptBundle(assetBundleName);
    }
    public static string ByteArrayToString(byte[] ba)
    {
        StringBuilder hex = new StringBuilder(ba.Length * 2);
        foreach (byte b in ba)
            hex.AppendFormat("{0:x2}", b);
        return hex.ToString();
    }

    // encrypt target assetbundle
    // encrypts asset bundle file using AES256-CBC with predefined key and generated IV
    // original file is deleted
    // generated IV is written into .manifest file
    private static void encryptBundle(string name)
    {
        string path = Path.Combine(Application.streamingAssetsPath, name);
        string generatedIV = String.Empty;

        using (FileStream inStream = new FileStream(path, FileMode.Open))
        using (FileStream outStream = new FileStream(path + ".assetbundle", FileMode.Create))
        {

            using (AesManaged aes = new AesManaged())
            {
                aes.Mode = CipherMode.CBC;
                aes.KeySize = 256;
                aes.BlockSize = 128;
                aes.GenerateIV();
                aes.Key = Convert.FromBase64String("utheQblwP2hYsTe06IkORwRZrwZZ+XYPGGdOEfM2vs0=");
                aes.GenerateIV();
                aes.Padding = PaddingMode.PKCS7;

                generatedIV = Convert.ToBase64String(aes.IV);

                ICryptoTransform encryptor = aes.CreateEncryptor();

                using (CryptoStream cryptoStream = new CryptoStream(outStream, encryptor, CryptoStreamMode.Write))
                {
                    int data;
                    while ((data = inStream.ReadByte()) != -1)
                        cryptoStream.WriteByte((byte)data);
                }
            }
        }

        File.Delete(path);

        using (FileStream manifestFileStream = new FileStream(path + ".manifest", FileMode.Append))
        using (StreamWriter sw = new StreamWriter(manifestFileStream))
        {
            sw.WriteLine("IV: " + generatedIV);
        }
    }
}
