﻿namespace Com.TheFallenGames.OSA.Core.SubComponents
{
	internal enum AllowContentOutsideBoundsMode
	{
		DO_NOT_ALLOW,
		ALLOW_IF_OUTSIDE_AMOUNT_SHRINKS,
		ALLOW
	}
}
