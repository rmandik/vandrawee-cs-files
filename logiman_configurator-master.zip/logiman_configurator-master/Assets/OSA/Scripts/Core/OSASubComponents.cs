﻿
namespace Com.TheFallenGames.OSA.Core
{
	[System.Obsolete("Everything inside this class was moved to the Core.SubComponents namespace", true)]
	internal class SubComponentss
	{}
}
