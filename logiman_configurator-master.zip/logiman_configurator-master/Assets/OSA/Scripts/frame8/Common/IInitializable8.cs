using System;

namespace frame8.Logic.Core.Interfaces
{
	public interface IInitializable8
	{
		void Init();
	}
}

